"""Valida um story.json antes de gastar TTS/render e mostra métricas do roteiro.

Uso:  python scripts/story_check.py story.json
"""

import sys
from collections import Counter
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from story_lib import estimate_seconds, load_story, validate, words_of  # noqa: E402

sys.stdout.reconfigure(encoding="utf-8")
story = load_story(sys.argv[1])
errors, warns = validate(story)
shots = story.get("shots", [])
lines = [s["line"] for s in shots if s.get("line")]
words = sum(len(words_of(l["text"])) for l in lines)
by = Counter(l["by"] for l in lines)
exprs = Counter([a.get("expr", "neutral") for s in shots for a in s.get("actors", [])] + [k["expr"] for s in shots for a in s.get("actors", []) for k in a.get("keys", []) if "expr" in k])
poses = Counter([a.get("pose", "idle") for s in shots for a in s.get("actors", [])] + [k["pose"] for s in shots for a in s.get("actors", []) for k in a.get("keys", []) if "pose" in k])
cams = Counter([s["camera"]["type"] for s in shots if s.get("camera")] + [c["camera"]["type"] for s in shots for c in s.get("cuts", [])])
framings = len(cams and list(cams.elements()))
est = estimate_seconds(story)
print(f"título: {story.get('title')}\nplanos: {len(shots)} | enquadramentos: {framings} | falas: {len(lines)} | palavras: {words}")
print(f"duração estimada: {est:.1f}s (alvo {story.get('target_seconds', '-')}) | ~{est / max(1, framings):.2f}s por enquadramento")
print("falas por voz:", dict(by))
print("expressões:", dict(exprs))
print("poses:", dict(poses))
print("câmeras:", dict(cams))
if len(set(exprs)) < 6:
    warns.append("menos de 6 expressões diferentes — a referência pede caretas variadas")
if est / max(1, framings) > 2.4:
    warns.append("ritmo lento: adicione cortes internos (cuts) para ~1,5–2,2 s por enquadramento")
for w in warns:
    print("aviso:", w)
for e in errors:
    print("ERRO:", e)
print("OK" if not errors else f"{len(errors)} erro(s)")
sys.exit(1 if errors else 0)
