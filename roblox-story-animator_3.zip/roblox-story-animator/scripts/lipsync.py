"""Extrai o envelope de abertura de boca (0–1, um valor por frame) de cada fala já preparada.

Lê src/data/vo.json + public/audio/vo/<id>.wav (saídas do prepare_vo.py) e grava src/data/lipsync.json.
A boca abre nas sílabas e fecha nas pausas: RMS por frame, normalizado pelo pico da fala,
com ataque rápido e soltura curta, e realce das variações (sílabas) para a boca "bater".

Uso (na raiz do projeto):  python scripts/lipsync.py [--fps 30]
"""

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import soundfile as sf

ROOT = Path.cwd()


def envelope(x, sr, fps):
    hop = sr / fps
    n = int(np.ceil(len(x) / hop))
    rms = np.array([np.sqrt(np.mean(x[int(i * hop): int((i + 1) * hop)] ** 2) + 1e-12) for i in range(n)])
    db = 20 * np.log10(rms)
    top = np.percentile(db, 95)
    v = np.clip((db - (top - 24)) / 24, 0, 1) ** 1.9
    # realça sílabas: subtrai parte da média lenta
    slow = np.convolve(v, np.ones(5) / 5, mode="same")
    v = np.clip(v + 0.9 * (v - slow), 0, 1)
    out, cur = [], 0.0
    for val in v:
        cur = val if val > cur else cur * 0.35 + val * 0.65
        out.append(0.0 if cur < 0.12 else round(float(min(0.95, cur)), 2))
    return out


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    p = argparse.ArgumentParser()
    p.add_argument("--fps", type=int, default=30)
    args = p.parse_args()
    vo = json.loads((ROOT / "src" / "data" / "vo.json").read_text(encoding="utf-8"))
    res = {}
    for key in vo:
        x, sr = sf.read(ROOT / "public" / "audio" / "vo" / f"{key}.wav")
        if x.ndim > 1:
            x = x.mean(axis=1)
        res[key] = envelope(x, sr, args.fps)
        opened = sum(1 for v in res[key] if v > 0) / max(1, len(res[key]))
        print(f"{key}: {len(res[key])} frames, boca aberta em {opened:.0%}")
    (ROOT / "src" / "data" / "lipsync.json").write_text(json.dumps(res), encoding="utf-8")


main()
