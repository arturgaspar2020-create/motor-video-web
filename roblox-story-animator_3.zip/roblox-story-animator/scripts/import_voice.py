"""Usa um áudio gravado/gerado pelo usuário (ex.: fala do Gojo feita no site do fish.audio) no lugar da fala de um plano.

  python scripts/import_voice.py story.json s07 caminho/da/fala.mp3

Corta o silêncio do começo/fim, salva em public/audio/vo/<plano>.mp3, calcula o tempo de cada palavra pelo
trecho com voz (aproximado — legenda; a boca segue o volume real) e marca a fala como voz do usuário (não é
PRÉVIA). Depois rode: prepare_vo.py -> lipsync.py -> build_timeline.py story.json -> music_story.py.
O texto do story.json precisa ser o que foi falado no áudio.
"""
import json
import subprocess
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from cast_voiceover import OUT_AUDIO, OUT_JSON, align_words, restore_punctuation  # noqa: E402
from story_lib import load_story  # noqa: E402


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    if len(sys.argv) != 4:
        sys.exit(__doc__)
    story_path, sid, src = sys.argv[1], sys.argv[2], Path(sys.argv[3])
    story = load_story(story_path)
    shot = next((s for s in story["shots"] if s["id"] == sid), None)
    if not shot or not shot.get("line"):
        sys.exit(f"plano {sid} não existe ou não tem fala")
    if not src.exists():
        sys.exit(f"arquivo não encontrado: {src}")
    line = shot["line"]
    OUT_AUDIO.mkdir(parents=True, exist_ok=True)
    out = OUT_AUDIO / f"{sid}.mp3"
    # corta silêncio no começo e no fim (deixa ~50 ms), mono 44,1 kHz
    af = ("silenceremove=start_periods=1:start_threshold=-45dB:start_silence=0.05,"
          "areverse,silenceremove=start_periods=1:start_threshold=-45dB:start_silence=0.08,areverse")
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", str(src), "-af", af, "-ac", "1", "-ar", "44100", "-b:a", "160k", str(out)], check=True)
    words = restore_punctuation(line["text"], align_words(out, line["text"]))
    timings = json.loads(OUT_JSON.read_text(encoding="utf-8")) if OUT_JSON.exists() else {"lines": {}}
    timings["lines"][sid] = {"text": line["text"], "by": line["by"], "voice": f"user-file:{src.name}", "words": words}
    OUT_JSON.parent.mkdir(parents=True, exist_ok=True)
    OUT_JSON.write_text(json.dumps(timings, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"{sid} {line['by']}: {words[-1]['end']:.2f}s  {line['text']}  [arquivo do usuário]")
    for w in words:
        print(f"   {w['start']:5.2f}-{w['end']:5.2f}  {w['text']}")


main()
