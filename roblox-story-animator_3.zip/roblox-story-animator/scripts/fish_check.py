"""Verifica a integração com o fish.audio SEM gastar créditos (e, opcionalmente, faz 1 teste curto grátis).

Passos:
  1. FISH_API_KEY presente? (lida do .env da raiz do projeto ou do ambiente; o valor NUNCA é impresso)
  2. Voz (reference_id): GET /model/{id} — não gera áudio, não consome crédito.
     Confere: type=tts, state=trained, visibilidade, idioma, sem remoção por DMCA.
  3. Saldo: GET /wallet/self/api-credit — só leitura, não consome crédito.
  4. (opcional, --tts-test) 1 frase curta com o modelo GRÁTIS s2.1-pro-free, salva em out/fish_teste.mp3,
     e confere o saldo antes/depois: se o saldo cair, avisa que houve cobrança.

Segurança de custo: só aceita o modelo "s2.1-pro-free" (a API cai no s2.1-pro PAGO se o cabeçalho
`model` vier vazio ou desconhecido). Outro modelo só com --allow-paid (exige autorização do usuário).

Uso (na raiz do projeto):
    python scripts/fish_check.py                          # passos 1-3, custo zero
    python scripts/fish_check.py --tts-test               # + teste de 1 frase no modelo grátis
    python scripts/fish_check.py --voice <reference_id>   # outra voz (padrão: a do preset gojo)
"""

import argparse
import json
import os
import sys
import urllib.error
import urllib.request
from pathlib import Path

ROOT = Path.cwd()
API = os.environ.get("FISH_API_BASE", "https://api.fish.audio").rstrip("/")
FREE_MODEL = "s2.1-pro-free"


def get_key():
    env = ROOT / ".env"
    if env.exists():
        for line in env.read_text(encoding="utf-8").splitlines():
            if line.strip().startswith("FISH_API_KEY="):
                v = line.split("=", 1)[1].strip().strip('"').strip("'")
                if v:
                    return v
    return os.environ.get("FISH_API_KEY") or None


def default_voice():
    for base in (ROOT / "characters", Path(__file__).resolve().parent.parent / "characters"):
        f = base / "gojo.json"
        if f.exists():
            return json.loads(f.read_text(encoding="utf-8")).get("fish_voice")
    return None


def scrub(text, key):
    return text.replace(key, "***") if key else text


def call(method, path, key=None, body=None, headers=None, timeout=60):
    h = {"Content-Type": "application/json", **(headers or {})}
    if key:
        h["Authorization"] = f"Bearer {key}"
    req = urllib.request.Request(API + path, data=json.dumps(body).encode() if body is not None else None, method=method, headers=h)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status, r.read()
    except urllib.error.HTTPError as e:
        return e.code, e.read()
    except urllib.error.URLError as e:
        return 0, str(e.reason).encode()


def credit(key):
    st, raw = call("GET", "/wallet/self/api-credit?check_free_credit=true", key)
    if st != 200:
        return None, st, raw
    d = json.loads(raw)
    return d, st, raw


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    p = argparse.ArgumentParser()
    p.add_argument("--voice", default=None)
    p.add_argument("--model", default=FREE_MODEL)
    p.add_argument("--tts-test", action="store_true")
    p.add_argument("--allow-paid", action="store_true")
    p.add_argument("--text", default="Teste rápido de voz. Tudo certo por aqui.")
    a = p.parse_args()
    ok = True

    if a.model != FREE_MODEL and not a.allow_paid:
        sys.exit(f"Modelo '{a.model}' pode ser PAGO. Use {FREE_MODEL} ou rode com --allow-paid se o usuário autorizou.")

    key = get_key()
    print("1) FISH_API_KEY:", "encontrada (valor oculto)" if key else "NÃO encontrada — crie .env com FISH_API_KEY=... na raiz do projeto")

    voice = a.voice or default_voice()
    if not voice:
        sys.exit("sem reference_id: passe --voice <id>")
    st, raw = call("GET", f"/model/{voice}", key)
    if st == 200:
        m = json.loads(raw)
        issues = []
        if m.get("type") != "tts":
            issues.append(f"type={m.get('type')} (precisa ser tts)")
        if m.get("state") != "trained":
            issues.append(f"state={m.get('state')} (precisa ser trained)")
        if m.get("dmca_taken_down"):
            issues.append("removida por DMCA")
        if "pt" not in (m.get("languages") or []):
            issues.append(f"idiomas={m.get('languages')} (sem 'pt')")
        print(f"2) voz {voice[:8]}…: '{m.get('title')}' | state={m.get('state')} | visibilidade={m.get('visibility')} | idiomas={m.get('languages')} | autor={(m.get('author') or {}).get('nickname')}")
        if issues:
            ok = False
            print("   PROBLEMA:", "; ".join(issues))
        else:
            print("   OK: voz TTS treinada, em português, utilizável como reference_id")
    else:
        ok = False
        print(f"2) voz {voice[:8]}…: HTTP {st} — {'não existe ou não é visível para esta conta' if st == 404 else scrub(raw.decode(errors='ignore')[:200], key)}")

    if not key:
        print("3) saldo: pulado (sem chave)")
        if a.tts_test:
            print("4) teste TTS: pulado (sem chave)")
        sys.exit(0 if ok else 1)

    c0, st, raw = credit(key)
    if c0 is None:
        ok = False
        print(f"3) saldo: HTTP {st} — {'chave inválida' if st == 401 else scrub(raw.decode(errors='ignore')[:200], key)}")
    else:
        print(f"3) saldo de crédito da API: {c0.get('credit')} | crédito grátis disponível: {c0.get('has_free_credit')}")

    if a.tts_test and c0 is not None:
        body = {"text": a.text, "reference_id": voice, "format": "mp3", "language": "pt-BR", "latency": "normal"}
        st, raw = call("POST", "/v1/tts", key, body, {"model": a.model}, timeout=120)
        if st == 200 and raw:
            out = ROOT / "out" / "fish_teste.mp3"
            out.parent.mkdir(parents=True, exist_ok=True)
            out.write_bytes(raw)
            c1, _, _ = credit(key)
            print(f"4) teste TTS ({a.model}): OK — {len(raw)} bytes em {out}")
            if c1 is not None:
                try:
                    diff = float(c0.get("credit") or 0) - float(c1.get("credit") or 0)
                except (TypeError, ValueError):
                    diff = 0.0
                if diff > 0:
                    ok = False
                    print(f"   ATENÇÃO: o saldo caiu {diff} — houve cobrança. Não gere mais nada até revisar o plano.")
                else:
                    print("   saldo inalterado: o modelo grátis aceitou esta voz sem custo")
        else:
            ok = False
            msg = {401: "chave inválida", 402: "pagamento exigido (o modelo grátis não cobriu este uso)", 404: "voz não encontrada para esta conta", 429: "limite de uso do plano grátis"}.get(st, "")
            print(f"4) teste TTS ({a.model}): HTTP {st} {msg} — {scrub(raw.decode(errors='ignore')[:200], key)}")

    print("RESULTADO:", "OK" if ok else "com problemas (veja acima)")
    sys.exit(0 if ok else 1)


main()
