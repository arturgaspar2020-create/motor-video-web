"""Biblioteca comum do Roblox Story Animator: vocabulário válido, leitura do story.json,
resolução de marcas de tempo ("w3", "w3e+0.2", "end", 1.5) e validação.

Mantenha as listas abaixo iguais às uniões de tipos de assets/template/src/types.ts.
"""

import json
import math
import re
from pathlib import Path

POSES = {"idle", "talk", "walk", "run", "point", "wave", "cheer", "shrug", "facepalm", "cry", "scared", "think", "sit",
         "lie", "fall", "jump", "lookup", "angry", "dance", "sneak", "climb", "laugh", "dizzy", "hands_hips", "reach", "bow",
         "punch", "kick", "power", "land", "carry"}
EXPRS = {"neutral", "happy", "laugh", "smug", "shock", "scared", "angry", "sad", "cry", "sleepy", "confused",
         "determined", "love", "evil", "dizzy", "wink", "disgust", "starstruck"}
SETS = {"street", "bedroom", "rooftop", "park", "classroom", "livingroom", "void", "hospital"}
FX = {"dust", "sparkle", "confetti", "energy_purple", "energy_blue", "impact", "speedlines", "smoke", "hearts", "stars"}
WEATHER = {"clear", "rain", "fog"}
TIMES = {"day", "sunset", "night"}
MOODS = {"calm", "funny", "tension", "sad", "epic", "mystery"}
CAMS = {"extreme_close", "close", "medium", "full", "wide", "establishing", "low", "high", "ots", "two", "pov_up", "top"}
MOVES = {"hold", "push", "pull", "orbit", "pan", "shake", "punch", "crash", "tilt_up", "dolly"}
GAZES = {"camera", "front", "up", "down", "left", "right"}
HATS = {"none", "cap", "wide", "beanie", "tophat", "crown", "party", "flower"}
HAIRS = {"none", "short", "long", "spiky", "bun", "pigtails", "curly", "buzz", "bob", "afro", "ponytail", "side"}
SFX = {"whoosh", "whoosh_fast", "pop", "boing", "thud", "fall", "ding", "sting", "hit", "sparkle", "sad_trombone",
       "footsteps", "door", "slap", "scratch", "heartbeat", "crickets", "bell", "tada", "suspense", "gulp", "zoom"}

ATTACH = {"head", "back", "torso", "handR", "handL"}
LICENSE_RE = re.compile(r"^(own|CC0|CC-BY:.+|permission:.+)$")

WORDS_PER_SEC_ESTIMATE = 2.9  # edge-tts pt-BR com rate ~+8%
AT_RE = re.compile(r"^(w(\d+)(e?)|start|line|lineEnd|end)([+-]\d*\.?\d+)?$")


SKILL_DIR = Path(__file__).resolve().parent.parent
CHAR_DIR = SKILL_DIR / "characters"


def _find_asset(rel):
    """assets/... da skill, ou public/... do projeto (quando os scripts rodam de dentro do projeto)."""
    for base in (SKILL_DIR / "assets", Path.cwd() / "assets", Path.cwd() / "public"):
        f = base / rel
        if f.exists():
            return f
    return None


def library_sounds():
    """Nomes base dos sons da biblioteca (assets/sons da skill ou public/audio/sfx do projeto), sem _01, _02."""
    names = set()
    for d in (SKILL_DIR / "assets" / "sons", Path.cwd() / "public" / "audio" / "sfx"):
        if d.is_dir():
            for f in d.iterdir():
                if f.suffix.lower() in (".wav", ".mp3", ".ogg", ".m4a"):
                    names.add(f.stem)
                    names.add(re.sub(r"_\d+$", "", f.stem))
    return names


def load_skins():
    f = _find_asset("skins/skins.json")
    return json.loads(f.read_text(encoding="utf-8"))["skins"] if f else {}


def load_voice_palette():
    f = _find_asset("voices.json")
    return json.loads(f.read_text(encoding="utf-8"))["voices"] if f else {}


def apply_skins_and_voices(story):
    """"skin": "05" -> camisa/calça do par 05 + cor da pele da cabeça; "voice": "pt_mulher_2" -> voz/pitch/velocidade da paleta."""
    skins, palette = load_skins(), load_voice_palette()
    for cid, c in story.get("cast", {}).items():
        v = c.get("voice")
        if v in palette:
            pv = palette[v]
            c["voice_preset"] = v
            c["voice"] = pv["voice"]
            c.setdefault("rate", pv.get("rate", "+0%"))
            c.setdefault("pitch", pv.get("pitch", "+0Hz"))
            if pv.get("shift"):
                c.setdefault("shift", pv["shift"])
        sk = c.get("skin")
        if sk is not None and not c.get("rig"):
            sk = str(sk).zfill(2) if str(sk).isdigit() else str(sk)
            c["skin"] = sk
            if sk in skins:
                d = skins[sk]
                look = dict(c.get("look") or {})
                look["shirtTexture"], look["pantsTexture"] = d["shirt"], d["pants"]
                look.setdefault("skin", d["skin_color"])
                look.setdefault("shirt", "#888888")
                look.setdefault("pants", "#444444")
                if c.get("age") == "crianca":
                    look.setdefault("scale", 0.8)
                c["look"] = look
    return story
PRESET_ONLY = {"id", "reserved_voice", "personality", "expressions", "poses", "voice_note", "requires_models", "rights_note",
               "aliases", "rig_note", "look_note", "model_files"}
VOICE_FIELDS = {"provider", "fish_voice", "fish_model", "voice", "rate", "pitch", "eleven_voice"}


def load_presets():
    """Personagens fixos (characters/*.json): nome, visual, personalidade e voz própria."""
    out = {}
    if CHAR_DIR.is_dir():
        for f in sorted(CHAR_DIR.glob("*.json")):
            p = json.loads(f.read_text(encoding="utf-8"))
            out[p["id"]] = p
    return out


def expand_cast(story):
    """"cast": {"gojo": {"preset": "gojo"}} vira o personagem completo. O story pode mudar o visual
    (look) e a cor, mas nunca nome nem voz de um personagem fixo."""
    presets = load_presets()
    for cid, c in list(story.get("cast", {}).items()):
        pid = c.get("preset") or (cid if cid in presets and not c.get("voice") else None)
        if not pid:
            nm = str(c.get("name", "")).strip().lower()
            for k, pr in presets.items():  # "Satoru Gojo", "Gojo"... -> personagem fixo
                if nm and nm in {pr["name"].lower(), *[a.lower() for a in pr.get("aliases", [])]}:
                    pid = k
        if not pid:
            continue
        if pid not in presets:
            raise ValueError(f"cast.{cid}: preset '{pid}' não existe em characters/")
        p = {k: v for k, v in presets[pid].items() if k not in PRESET_ONLY}
        merged = {**p, **{k: v for k, v in c.items() if k not in VOICE_FIELDS | {"name", "preset", "rig"}}}
        if "rig" in c and isinstance(c["rig"], dict) and "rig" in p:  # ajustes finos (ex.: tirar hideUV p/ usar a venda)
            merged["rig"] = {**p["rig"], **c["rig"]}
        if "look" in c:
            merged["look"] = {**p.get("look", {}), **c["look"]}
        merged["preset"] = pid
        story["cast"][cid] = merged
    return story


def load_story(path):
    return apply_skins_and_voices(expand_cast(json.loads(Path(path).read_text(encoding="utf-8-sig"))))


def words_of(text):
    return [w for w in re.split(r"\s+", text.strip()) if w]


def resolve_at(value, fps, line_at, words, duration, where):
    """Converte uma marca de tempo em frame local do plano."""
    if value is None:
        return 0
    if isinstance(value, (int, float)):
        f = round(value * fps)
    else:
        m = AT_RE.match(str(value).strip())
        if not m:
            raise ValueError(f"{where}: marca de tempo inválida '{value}' (use segundos, 'w3', 'w3e', 'line', 'lineEnd', 'end', com +/-s)")
        head, idx, is_end, off = m.group(1), m.group(2), m.group(3), m.group(4)
        off_f = round(float(off) * fps) if off else 0
        if idx is not None:
            i = int(idx)
            if not words:
                raise ValueError(f"{where}: '{value}' usa palavra, mas o plano não tem fala")
            if i >= len(words):
                raise ValueError(f"{where}: '{value}' fora da fala ({len(words)} palavras, índice 0..{len(words) - 1})")
            f = line_at + (words[i]["end"] if is_end else words[i]["start"]) + off_f
        elif head == "start":
            f = off_f
        elif head == "line":
            f = line_at + off_f
        elif head == "lineEnd":
            f = line_at + (words[-1]["end"] if words else 0) + off_f
        else:  # end
            f = duration - 1 + off_f
    return int(max(0, min(duration - 1, f)))


def validate(story, strict=True):
    """Retorna (erros, avisos)."""
    errors, warns = [], []
    cast = story.get("cast", {})
    if "narrator" not in cast:
        warns.append("cast sem 'narrator' (ok se só personagens falam)")
    for cid, c in cast.items():
        if not c.get("voice"):
            errors.append(f"cast.{cid}: falta 'voice'")
        look = c.get("look")
        if look:
            if look.get("hat", "none") not in HATS:
                errors.append(f"cast.{cid}.look.hat inválido: {look.get('hat')}")
            if look.get("hair", "none") not in HAIRS:
                errors.append(f"cast.{cid}.look.hair inválido: {look.get('hair')}")
            for k in ("shirt", "pants"):
                if k not in look:
                    errors.append(f"cast.{cid}.look: falta '{k}'")
            for ac in look.get("accessories", []):
                if ac.get("attach") not in ATTACH:
                    errors.append(f"cast.{cid}: acessório {ac.get('src')} com attach inválido (use {', '.join(sorted(ATTACH))})")
                if not str(ac.get("src", "")).lower().endswith((".glb", ".gltf")):
                    errors.append(f"cast.{cid}: acessório precisa de src .glb/.gltf em public/")
                if not LICENSE_RE.match(str(ac.get("license", ""))):
                    errors.append(f"cast.{cid}: acessório {ac.get('src')} sem licença válida (own | CC0 | CC-BY:<autor> | permission:<quem>)")
    # skins: todo personagem em cena (menos os de modelo próprio, ex. Gojo) usa um par camisa+calça do catálogo
    skins = load_skins()
    used = {}
    on_screen = {a.get("id") for s in story.get("shots", []) for a in s.get("actors", [])}
    for cid, c in cast.items():
        if c.get("rig") or cid not in on_screen:
            continue
        sk = c.get("skin")
        if sk is None:
            errors.append(f"cast.{cid}: falta 'skin' (id do catálogo assets/skins/skins.json) — roupa lisa não é mais usada")
            continue
        if skins and sk not in skins:
            errors.append(f"cast.{cid}: skin '{sk}' não existe no catálogo")
            continue
        if c.get("gender") not in ("F", "M"):
            errors.append(f"cast.{cid}: falta 'gender' (\"F\" ou \"M\") para conferir a skin")
        if c.get("age") not in ("adulto", "crianca"):
            errors.append(f"cast.{cid}: falta 'age' (\"adulto\" ou \"crianca\")")
        if skins:
            d = skins[sk]
            if d["gender"] != "U" and c.get("gender") in ("F", "M") and d["gender"] != c["gender"]:
                errors.append(f"cast.{cid}: skin {sk} é {'feminina' if d['gender'] == 'F' else 'masculina'} e o personagem é {c['gender']}")
            if c.get("age") in ("adulto", "crianca") and d["age"] != c["age"]:
                errors.append(f"cast.{cid}: skin {sk} é de {d['age']} e o personagem é {c['age']}")
        if skins and skins[sk].get("style") == "decote" and any(x.get("age") == "crianca" for x in cast.values()):
            errors.append(f"cast.{cid}: skin {sk} é corpete/lingerie com decote — não use em história com crianças; escolha uma skin discreta (ex.: 32, 33, 34, 35)")
        elif skins and skins[sk].get("style") == "decote":
            warns.append(f"cast.{cid}: skin {sk} é corpete/lingerie com decote — confirme se combina com o público do vídeo")
        if sk in used:
            warns.append(f"cast.{cid}: skin {sk} repetida (também em {used[sk]}) — prefira uma skin por personagem")
        used[sk] = cid
        if (c.get("look") or {}).get("hair", "none") == "none" and not any(a.get("attach") == "head" for a in (c.get("look") or {}).get("accessories", [])):
            warns.append(f"cast.{cid}: sem cabelo — escolha look.hair (short, spiky, curly, afro, buzz, bob, long, ponytail, bun, pigtails, side)")
    presets = load_presets()
    for pid, p in presets.items():
        if not p.get("reserved_voice"):
            continue
        for cid, c in cast.items():
            same_voice = p.get("fish_voice") and c.get("fish_voice") == p.get("fish_voice")
            if same_voice and c.get("preset") != pid:
                errors.append(f"cast.{cid}: a voz {p['fish_voice'][:8]}… é exclusiva do personagem fixo '{p['name']}' — use outra voz")
            if c.get("preset") == pid and c.get("name") != p["name"]:
                errors.append(f"cast.{cid}: o personagem fixo '{p['name']}' não pode ser renomeado")
            names = {p["name"].lower(), *[a.lower() for a in p.get("aliases", [])]}
            if c.get("name", "").strip().lower() in names and c.get("preset") != pid:
                errors.append(f"cast.{cid}: '{p['name']}' é personagem fixo — use \"{cid}\": {{\"preset\": \"{pid}\"}}")
    for cid, c in cast.items():
        if c.get("provider") == "fish" and not c.get("fish_voice"):
            errors.append(f"cast.{cid}: provider fish precisa de fish_voice (reference_id do fish.audio)")
    voices = {}
    for cid, c in cast.items():
        key = (c.get("voice"), c.get("pitch", "+0Hz"), c.get("rate", "+0%"), c.get("shift", 0))
        if key in voices:
            errors.append(f"cast.{cid} usa exatamente a mesma voz/pitch/rate de {voices[key]} — cada personagem precisa de voz distinta")
        voices[key] = cid
    ids = set()
    for i, s in enumerate(story.get("shots", [])):
        w = f"shots[{i}]({s.get('id')})"
        if not s.get("id") or s["id"] in ids:
            errors.append(f"{w}: id ausente ou repetido")
        ids.add(s.get("id"))
        if s.get("set") not in SETS:
            errors.append(f"{w}: set inválido {s.get('set')}")
        if s.get("time", "day") not in TIMES:
            errors.append(f"{w}: time inválido {s.get('time')}")
        if s.get("mood", "calm") not in MOODS:
            errors.append(f"{w}: mood inválido {s.get('mood')}")
        line = s.get("line")
        if line:
            if line.get("by") not in cast:
                errors.append(f"{w}: fala de '{line.get('by')}' que não está no cast")
            if not line.get("text", "").strip():
                errors.append(f"{w}: fala vazia")
        elif not s.get("hold"):
            warns.append(f"{w}: sem fala e sem 'hold' — usará 1,0 s")
        actor_ids = set()
        for a in s.get("actors", []):
            actor_ids.add(a.get("id"))
            if a.get("id") not in cast:
                errors.append(f"{w}: ator '{a.get('id')}' não está no cast")
            if a.get("pose", "idle") not in POSES:
                errors.append(f"{w}: pose inválida {a.get('pose')}")
            if a.get("expr", "neutral") not in EXPRS:
                errors.append(f"{w}: expressão inválida {a.get('expr')}")
            if a.get("gaze", "front") not in GAZES:
                errors.append(f"{w}: gaze inválido {a.get('gaze')}")
            for k in a.get("keys", []):
                if k.get("pose") and k["pose"] not in POSES:
                    errors.append(f"{w}: pose inválida em keys: {k['pose']}")
                if k.get("expr") and k["expr"] not in EXPRS:
                    errors.append(f"{w}: expressão inválida em keys: {k['expr']}")
        if line and line.get("by") != "narrator" and line.get("by") not in actor_ids:
            warns.append(f"{w}: '{line.get('by')}' fala mas não está em cena (voz em off, sem lip-sync)")
        cams = [s.get("camera")] + [c.get("camera") for c in s.get("cuts", [])]
        if not s.get("camera"):
            errors.append(f"{w}: falta 'camera'")
        for c in cams:
            if not c:
                continue
            if c.get("type") not in CAMS:
                errors.append(f"{w}: câmera inválida {c.get('type')}")
            if c.get("move", "hold") not in MOVES:
                errors.append(f"{w}: movimento inválido {c.get('move')}")
            for k in ("on", "from"):
                if c.get(k) and c[k] not in actor_ids:
                    errors.append(f"{w}: camera.{k}='{c[k]}' não está em actors")
            if c.get("type") in ("close", "extreme_close", "low") and abs(c.get("angle", 0)) > 35:
                warns.append(f"{w}: close com angle {c.get('angle')}° será limitado a ±35° para mostrar o rosto")
            if c.get("type") in ("ots", "two") and not c.get("from"):
                errors.append(f"{w}: câmera {c.get('type')} precisa de 'from'")
        for pr in s.get("props", []):
            if not pr.get("src", "").lower().endswith((".glb", ".gltf")):
                errors.append(f"{w}: prop precisa de src .glb/.gltf em public/ (ex.: models/banco.glb)")
            lic = str(pr.get("license", ""))
            if not LICENSE_RE.match(lic):
                errors.append(f"{w}: prop {pr.get('src')} sem licença válida (own | CC0 | CC-BY:<autor> | permission:<quem>)")
        if s.get("weather", "clear") not in WEATHER:
            errors.append(f"{w}: weather inválido {s.get('weather')} (use {', '.join(sorted(WEATHER))})")
        for e in s.get("fx", []):
            if e.get("type") not in FX:
                errors.append(f"{w}: fx inválido {e.get('type')} (use {', '.join(sorted(FX))})")
            if e.get("on") and e["on"] not in actor_ids:
                errors.append(f"{w}: fx.on='{e['on']}' não está em actors")
        for x in s.get("sfx", []):
            if x.get("name") not in SFX and x.get("name") not in library_sounds():
                warns.append(f"{w}: efeito '{x.get('name')}' não é sintetizado — precisa existir na biblioteca de sons (public/audio/sfx, com ou sem _01, _02...)")
    return errors, warns


def estimate_seconds(story):
    total = 0.0
    for s in story["shots"]:
        line = s.get("line")
        if line:
            total += len(words_of(line["text"])) / WORDS_PER_SEC_ESTIMATE + s.get("lead", 0.12) + s.get("tail", 0.18) + s.get("hold", 0)
        else:
            total += s.get("hold", 1.0)
    return total


def cut_lengths(timeline):
    """Duração (s) de cada enquadramento, considerando cortes internos."""
    fps = timeline["fps"]
    out = []
    for s in timeline["shots"]:
        ats = [c["at"] for c in s["cuts"]] + [s["duration"]]
        out += [(b - a) / fps for a, b in zip(ats, ats[1:])]
    return out


def ceil_f(sec, fps):
    return int(math.ceil(sec * fps - 1e-6))
