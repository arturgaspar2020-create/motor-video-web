"""Sintetiza a biblioteca de efeitos cômicos/dramáticos (tudo por código, sem samples).

Uso:  python scripts/sfx_story.py        -> public/audio/sfx/<nome>.wav
Nomes válidos = story_lib.SFX (o story.json só pode usar estes).
"""

import sys
from pathlib import Path

import numpy as np
import soundfile as sf

sys.path.insert(0, str(Path(__file__).resolve().parent))
from story_lib import SFX  # noqa: E402
from synth_kit import SR, bell, bp, env, hp, ir, lp, piano, rng, sine_sweep, soft_hit, stereo, tt, verb  # noqa: E402

OUT = Path.cwd() / "public" / "audio" / "sfx"


def add(x, y, at_s, g=1.0):
    """Soma y em x a partir de at_s segundos, cortando o que passar do fim."""
    i = int(at_s * SR)
    if i >= len(x):
        return
    n = min(len(y), len(x) - i)
    x[i:i + n] += y[:n] * g


def noise(d):
    return rng.standard_normal(int(d * SR))


def whoosh(d=0.45, lo=300, hi=3500):
    t = tt(d)
    p = t / d
    x = noise(d)
    out = np.zeros_like(x)
    for b in range(0, len(x), 512):
        c = lo + (hi - lo) * np.sin(np.pi * p[b]) ** 2
        out[b:b + 512] = bp(x[b:b + 512], max(80, c / 1.8), c * 1.8)
    return out * np.sin(np.pi * p) ** 1.5 * 1.2


def pop():
    t = tt(0.12)
    return sine_sweep(900, 300, 0.12) * np.exp(-t / 0.03) * 0.8


def boing():
    t = tt(0.7)
    f = 180 + 120 * np.sin(2 * np.pi * 9 * t) * np.exp(-t / 0.3) + 100 * np.exp(-t / 0.05)
    return np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-t / 0.28) * 0.8


def thud():
    t = tt(0.5)
    body = np.sin(2 * np.pi * np.cumsum(55 + 90 * np.exp(-t / 0.04)) / SR) * np.exp(-t / 0.12)
    return np.tanh((body + lp(noise(0.5), 1200) * np.exp(-t / 0.03) * 0.5) * 1.6) * 0.8


def fall():
    d = 1.1
    t = tt(d)
    whistle = sine_sweep(1800, 300, 0.85) * env(0.85, 0.05, 0.05) * 0.35
    x = np.zeros(len(t))
    x[: len(whistle)] += whistle
    th = thud()
    add(x, th, 0.85)
    return x


def ding():
    return bell(88, 1.4) * 2.2


def sting():
    # "dun dun DUN": três golpes graves de metais
    d = 2.2
    x = np.zeros(int(d * SR))
    for k, (at, m, dur) in enumerate([(0, 45, 0.25), (0.32, 44, 0.25), (0.66, 40, 1.4)]):
        t = tt(dur)
        f = 440 * 2 ** ((m - 69) / 12)
        ph = 2 * np.pi * f * t
        y = np.tanh((np.sin(ph) + 0.6 * np.sin(2 * ph) + 0.4 * np.sin(3 * ph) + 0.3 * np.sin(4.01 * ph)) * 2) * env(dur, 0.01, dur * 0.6)
        y = lp(y, 1600 if k < 2 else 2400)
        add(x, y, at, (0.6 if k < 2 else 0.85))
    return x


def hit():
    return soft_hit(1.2)[: int(1.5 * SR)] * 1.2


def sparkle():
    d = 1.2
    x = np.zeros(int(d * SR))
    for k, m in enumerate([84, 88, 91, 96, 100]):
        y = bell(m, 0.8)
        add(x, y, k * 0.07, 0.8)
    return x


def sad_trombone():
    d = 2.9
    x = np.zeros(int(d * SR))
    for k, (m, dur) in enumerate([(58, 0.5), (57, 0.5), (56, 0.5), (55, 1.1)]):
        t = tt(dur)
        f = 440 * 2 ** ((m - 69) / 12) * (1 + (0.025 * np.sin(2 * np.pi * 6 * t) if k == 3 else 0))
        ph = 2 * np.pi * np.cumsum(f) / SR
        y = lp(np.tanh((np.sin(ph) + 0.7 * np.sin(2 * ph) + 0.5 * np.sin(3 * ph)) * 1.8), 1400) * env(dur, 0.04, 0.12)
        add(x, y, k * 0.55, 0.6)
    return x


def footsteps():
    d = 1.6
    x = np.zeros(int(d * SR))
    for k in range(5):
        t = tt(0.12)
        y = bp(noise(0.12), 200, 2500) * np.exp(-t / 0.025) + np.sin(2 * np.pi * 90 * t) * np.exp(-t / 0.03) * 0.6
        add(x, y, k * 0.3, (0.8 if k % 2 else 0.65))
    return x


def door():
    d = 1.0
    t = tt(0.7)
    creak = bp(np.sign(np.sin(2 * np.pi * np.cumsum(60 + 40 * np.sin(2 * np.pi * 2 * t)) / SR)) * 0.5, 300, 2400) * env(0.7, 0.05, 0.2) * 0.4
    x = np.zeros(int(d * SR))
    x[: len(creak)] += creak
    th = thud() * 0.7
    add(x, th, 0.65)
    return x


def slap():
    t = tt(0.25)
    return hp(noise(0.25), 800) * np.exp(-t / 0.018) * 1.1 + np.sin(2 * np.pi * 160 * t) * np.exp(-t / 0.03) * 0.4


def scratch():
    d = 0.5
    t = tt(d)
    f = 600 + 900 * np.sin(2 * np.pi * 3.5 * t) ** 2
    y = bp(noise(d), 300, 3000) * 0.5 + np.sin(2 * np.pi * np.cumsum(f) / SR) * 0.3
    return y * env(d, 0.01, 0.1)


def heartbeat():
    d = 1.8
    x = np.zeros(int(d * SR))
    for at, g in [(0, 1), (0.22, 0.7), (0.9, 1), (1.12, 0.7)]:
        t = tt(0.25)
        y = np.sin(2 * np.pi * np.cumsum(45 + 40 * np.exp(-t / 0.03)) / SR) * np.exp(-t / 0.07)
        add(x, y, at, g)
    return np.tanh(x * 1.5) * 0.9


def crickets():
    d = 2.5
    t = tt(d)
    chirp = (np.sin(2 * np.pi * 4300 * t) * (np.sin(2 * np.pi * 30 * t) > 0.2) * ((t * 2.2) % 1 < 0.35)) * 0.25
    return chirp * env(d, 0.2, 0.4)


def school_bell():
    d = 1.6
    t = tt(d)
    ring = np.sin(2 * np.pi * 2200 * t) * (np.sin(2 * np.pi * 22 * t) > 0) * 0.3 + np.sin(2 * np.pi * 3100 * t) * 0.1
    return ring * env(d, 0.01, 0.3)


def tada():
    d = 1.8
    x = np.zeros(int(d * SR))
    for k, ms in enumerate([[60, 64, 67], [65, 69, 72, 77]]):
        for m in ms:
            y = piano(m + 12, 1.4 if k else 0.3)
            add(x, y, k * 0.18, 0.7)
    return x


def suspense():
    d = 2.4
    t = tt(d)
    y = (np.sin(2 * np.pi * 110 * t) + np.sin(2 * np.pi * 116.5 * t) + 0.5 * np.sin(2 * np.pi * 233 * t)) * (t / d) ** 1.5
    return lp(y, 900) * 0.45


def gulp():
    t = tt(0.35)
    return sine_sweep(500, 140, 0.35) * np.exp(-((t - 0.12) ** 2) / 0.004) * 0.9


def zoom():
    d = 0.35
    return sine_sweep(200, 2400, d) * env(d, 0.01, 0.1) * 0.25 + whoosh(d, 800, 6000)[: int(d * SR)] * 0.6


BANK = {
    "whoosh": lambda: whoosh(0.45),
    "whoosh_fast": lambda: whoosh(0.25, 600, 5000),
    "pop": pop, "boing": boing, "thud": thud, "fall": fall, "ding": ding, "sting": sting, "hit": hit,
    "sparkle": sparkle, "sad_trombone": sad_trombone, "footsteps": footsteps, "door": door, "slap": slap,
    "scratch": scratch, "heartbeat": heartbeat, "crickets": crickets, "bell": school_bell, "tada": tada,
    "suspense": suspense, "gulp": gulp, "zoom": zoom,
}


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    missing = SFX - set(BANK)
    assert not missing, f"faltam efeitos: {missing}"
    OUT.mkdir(parents=True, exist_ok=True)
    small = ir(0.6, 0.12)
    import re
    user = {p.stem.lower() for p in OUT.iterdir() if p.suffix.lower() in (".mp3", ".ogg", ".m4a")} | {
        re.sub(r"_\d+$", "", p.stem.lower()) for p in OUT.iterdir() if re.search(r"_\d+$", p.stem)}
    marker = OUT / ".sintetizados"
    made = set(marker.read_text().split()) if marker.exists() else set()
    user |= {p.stem for p in OUT.glob("*.wav") if p.stem in BANK and p.stem not in made}
    for name, fn in BANK.items():
        if name in user:  # o usuário mandou um som com esse nome (ou variações): o dele tem prioridade
            print(f"{name}: mantido o da biblioteca do usuário")
            continue
        made.add(name)
        x = fn()
        x = stereo(np.asarray(x, dtype=np.float64))
        x = x + verb(x, small) * 0.12
        x = hp(x, 35)
        peak = np.max(np.abs(x))
        if peak > 0:
            x *= 0.89 / peak
        sf.write(OUT / f"{name}.wav", x.astype(np.float32), SR, subtype="PCM_16")
        print(f"{name}: {len(x) / SR:.2f}s")
    marker.write_text(" ".join(sorted(made)))


main()
