"""Gera as falas com uma voz por personagem (narrador + elenco), com tempos por palavra.

Provedores:
  - edge (PADRÃO, gratuito): edge-tts, vozes neurais. Cada membro do cast define voice/rate/pitch.
  - fish (por personagem): membros com "provider": "fish" + "fish_voice" (reference_id de um modelo de voz
    do fish.audio) usam a API do fish.audio (FISH_API_KEY no .env; modelo "s2.1-pro-free" = plano grátis).
    Se faltar a chave ou a API falhar, usa o Edge TTS automaticamente (fala marcada como PRÉVIA e avisada
    pelo build_timeline); --strict-fish faz parar em vez disso. Só o modelo grátis s2.1-pro-free é aceito
    sem --allow-paid. A chave nunca é impressa.
  - elevenlabs (OPCIONAL, pago): só com autorização do usuário, ELEVENLABS_API_KEY no .env da raiz
    e "eleven_voice" em cada membro do cast. Membros sem eleven_voice caem no edge (avisado).

Saída no MESMO formato do voiceover.py original, então o prepare_vo.py original é reutilizado:
  public/audio/vo/<id_do_plano>.mp3  +  scripts/out/vo-timings.json

Uso (na raiz do projeto Remotion):
    python scripts/cast_voiceover.py story.json
    python scripts/cast_voiceover.py story.json --only s03 s07     # regera só esses planos
    python scripts/cast_voiceover.py story.json --provider elevenlabs
    python scripts/cast_voiceover.py --preview-voices story.json   # uma frase de teste por voz -> out/voices/
"""

import argparse
import asyncio
import base64
import json
import os
import re
import ssl
import subprocess
import sys
import unicodedata
import urllib.error
import urllib.request
from pathlib import Path

ROOT = Path.cwd()
OUT_AUDIO = ROOT / "public" / "audio" / "vo"
OUT_JSON = ROOT / "scripts" / "out" / "vo-timings.json"
ELEVEN_MODEL = "eleven_multilingual_v2"


def env_key(name="ELEVENLABS_API_KEY"):
    env = ROOT / ".env"
    if env.exists():
        for line in env.read_text(encoding="utf-8").splitlines():
            if line.strip().startswith(name + "="):
                return line.split("=", 1)[1].strip().strip('"').strip("'") or None
    return os.environ.get(name) or None


def norm(s):
    s = unicodedata.normalize("NFD", s.lower())
    return re.sub(r"[^a-z0-9]", "", "".join(c for c in s if unicodedata.category(c) != "Mn"))


def restore_punctuation(text, words):
    """O edge-tts devolve palavras sem pontuação; recoloca o token original (com ?!.,) para as legendas."""
    toks = [t for t in re.split(r"\s+", text.strip()) if t]
    out, j = [], 0
    for w in words:
        nw = norm(w["text"])
        k = j
        while k < len(toks) and k < j + 4 and not (norm(toks[k]) and (norm(toks[k]).startswith(nw) or nw.startswith(norm(toks[k])))):
            k += 1
        if k < len(toks) and k < j + 4:
            out.append({**w, "text": toks[k]})
            j = k + 1
        else:
            out.append(w)
    return out


# ---------------------------------------------------------------- edge-tts
def _patch_ssl():
    # Ambientes com proxy corporativo: respeita SSL_CERT_FILE (nunca desliga a verificação).
    ca = os.environ.get("SSL_CERT_FILE")
    if ca and Path(ca).exists():
        import edge_tts.communicate as cm

        if hasattr(cm, "_SSL_CTX"):
            cm._SSL_CTX = ssl.create_default_context(cafile=ca)


def shift_semitones(path, st):
    """Muda o tom em st semitons mantendo a duração (vozes infantis a partir de vozes adultas)."""
    if not st:
        return
    import subprocess
    r = 2 ** (st / 12)
    tmp = Path(str(path) + ".tmp.mp3")
    subprocess.run(["ffmpeg", "-y", "-loglevel", "error", "-i", str(path), "-af",
                    f"asetrate=24000*{r:.5f},aresample=24000,atempo={1 / r:.5f}", "-ar", "24000", "-b:a", "96k", str(tmp)], check=True)
    os.replace(tmp, path)


async def synth_edge(path, text, voice, rate, pitch, shift=0):
    import edge_tts

    last = None
    for attempt in range(1, 6):
        try:
            com = edge_tts.Communicate(text, voice, rate=rate, pitch=pitch, boundary="WordBoundary")
            words = []
            with open(path, "wb") as f:
                async for ch in com.stream():
                    if ch["type"] == "audio":
                        f.write(ch["data"])
                    elif ch["type"] == "WordBoundary":
                        st = ch["offset"] / 1e7
                        words.append({"text": ch["text"], "start": round(st, 3), "end": round(st + ch["duration"] / 1e7, 3)})
            if words:
                shift_semitones(path, shift)
                return words
            last = RuntimeError("sem WordBoundary")
        except Exception as e:  # serviço às vezes responde sem áudio; tentar de novo resolve
            last = e
        await asyncio.sleep(1.5 * attempt)
    raise RuntimeError(f"edge-tts falhou para voz {voice}: {last}")


# ---------------------------------------------------------------- ElevenLabs (opcional)
def words_from_alignment(al):
    words, cur, start, end = [], "", None, None
    for ch, s, e in zip(al["characters"], al["character_start_times_seconds"], al["character_end_times_seconds"]):
        if ch.isspace():
            if cur:
                words.append({"text": cur, "start": round(start, 3), "end": round(end, 3)})
            cur, start = "", None
            continue
        if start is None:
            start = s
        cur += ch
        end = e
    if cur:
        words.append({"text": cur, "start": round(start, 3), "end": round(end, 3)})
    return words


def synth_eleven(path, text, voice_id, key):
    body = {"text": text, "model_id": ELEVEN_MODEL, "language_code": "pt",
            "voice_settings": {"stability": 0.38, "similarity_boost": 0.8, "style": 0.45, "use_speaker_boost": True, "speed": 1.05}}
    req = urllib.request.Request(f"https://api.elevenlabs.io/v1/text-to-speech/{voice_id}/with-timestamps?output_format=mp3_44100_128",
                                 data=json.dumps(body).encode(), headers={"xi-api-key": key, "Content-Type": "application/json"}, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=120) as r:
            res = json.loads(r.read())
    except urllib.error.HTTPError as e:
        sys.exit(f"ElevenLabs {e.code}: {e.read().decode()[:300]}")
    Path(path).write_bytes(base64.b64decode(res["audio_base64"]))
    return words_from_alignment(res["alignment"])


# ---------------------------------------------------------------- fish.audio (voz própria por personagem)
FISH_API = os.environ.get("FISH_API_BASE", "https://api.fish.audio").rstrip("/")
FISH_URL = FISH_API + "/v1/tts/stream/with-timestamp"
# A API cai no s2.1-pro (PAGO) se o cabeçalho `model` vier vazio/desconhecido: só o grátis é permitido
# sem --allow-paid (autorização explícita do usuário).
FISH_FREE_MODEL = "s2.1-pro-free"


def _tokens(text):
    return [t for t in re.split(r"\s+", text.strip()) if t]


def _weight(tok):
    w = len(norm(tok)) + 1.0
    if re.search(r"[.!?…]$", tok):
        w += 4.0  # pausa depois de ponto
    elif re.search(r"[,;:]$", tok):
        w += 2.0
    return w


def _voiced_times(path, hop=0.01):
    """Instantes (s) dos quadros com voz, para distribuir palavras só onde há fala."""
    import numpy as np

    raw = subprocess.run(["ffmpeg", "-v", "error", "-i", str(path), "-ac", "1", "-ar", "16000", "-f", "f32le", "-"], capture_output=True, check=True).stdout
    x = np.frombuffer(raw, dtype=np.float32)
    n = int(len(x) / (16000 * hop))
    rms = np.array([np.sqrt(np.mean(x[int(i * 160):int((i + 1) * 160)] ** 2) + 1e-12) for i in range(n)])
    db = 20 * np.log10(rms)
    voiced = np.flatnonzero(db > db.max() - 32)
    return [i * hop for i in voiced], n * hop


def align_words(path, text, segments=None):
    """Tempos por palavra para áudio sem marcação de palavra (fish.audio).

    Com `segments` (trechos com início/fim vindos da API), distribui as palavras de cada trecho dentro dele.
    Sem eles, distribui pelo tempo COM VOZ do áudio (pulando pausas), proporcional ao tamanho da palavra.
    É aproximado (legendas); a boca usa o volume real do áudio (lipsync.py), então continua sincronizada.
    """
    toks = _tokens(text)
    if segments:
        out, ti = [], 0
        for seg in segments:
            need = len(norm(seg["text"]))
            group, got = [], 0
            while ti < len(toks) and (got < need or not group):
                group.append(toks[ti])
                got += len(norm(toks[ti]))
                ti += 1
            tot = sum(_weight(t) for t in group) or 1
            acc = 0.0
            for t in group:
                w = _weight(t)
                st = seg["start"] + (seg["end"] - seg["start"]) * acc / tot
                en = seg["start"] + (seg["end"] - seg["start"]) * (acc + len(norm(t)) + 1) / tot
                out.append({"text": t, "start": round(st, 3), "end": round(en, 3)})
                acc += w
        rest = toks[ti:]
        if rest and out:  # sobrou texto: estica no fim
            last = out[-1]["end"]
            for k, t in enumerate(rest):
                out.append({"text": t, "start": round(last + 0.2 * k, 3), "end": round(last + 0.2 * (k + 1), 3)})
        return out
    vt, total = _voiced_times(path)
    # 1) tenta casar frases (separadas por pontuação) com "ilhas" de fala (separadas por pausas reais)
    phrases, cur = [], []
    for t in toks:
        cur.append(t)
        if re.search(r"[.!?…,;:]$", t):
            phrases.append(cur)
            cur = []
    if cur:
        phrases.append(cur)
    islands = []
    for t in vt:
        if islands and t - islands[-1][1] <= 0.16:
            islands[-1][1] = t
        else:
            islands.append([t, t])
    islands = [i for i in islands if i[1] - i[0] >= 0.05] or islands
    while len(islands) > len(phrases) and len(islands) > 1:
        gaps = [islands[k + 1][0] - islands[k][1] for k in range(len(islands) - 1)]
        k = gaps.index(min(gaps))
        islands[k] = [islands[k][0], islands[k + 1][1]]
        del islands[k + 1]
    if len(phrases) > 1 and len(islands) == len(phrases):
        segs = [{"text": " ".join(ph), "start": a, "end": b + 0.01} for ph, (a, b) in zip(phrases, islands)]
        return align_words(path, text, segs)
    # 2) senão, distribui pelo tempo com voz
    if not vt:
        vt = [i * total / 100 for i in range(100)]
    tot = sum(_weight(t) for t in toks) or 1
    out, acc = [], 0.0
    for t in toks:
        a = vt[min(len(vt) - 1, int(len(vt) * acc / tot))]
        b = vt[min(len(vt) - 1, int(len(vt) * (acc + len(norm(t)) + 1) / tot))]
        out.append({"text": t, "start": round(a, 3), "end": round(max(b, a + 0.06), 3)})
        acc += _weight(t)
    return out


class FishError(Exception):
    pass


def synth_fish(path, text, reference_id, key, model=FISH_FREE_MODEL, speed=1.0, language="pt-BR"):
    """Uma fala pelo fish.audio (stream com tempos). MP3, idioma pt-BR. Lança FishError em qualquer falha.
    A chave só vai no cabeçalho Authorization; nunca é impressa (mensagens passam por _scrub)."""
    body = {"text": text, "reference_id": reference_id, "format": "mp3", "mp3_bitrate": 128, "latency": "balanced",
            "language": language, "prosody": {"speed": speed, "volume": 0}}
    req = urllib.request.Request(FISH_URL, data=json.dumps(body).encode(), method="POST",
                                 headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json", "model": model})
    audio, snaps, offsets = bytearray(), {}, {}
    try:
        with urllib.request.urlopen(req, timeout=180) as r:
            for raw in r:
                line = raw.decode("utf-8", "ignore").strip()
                if not line.startswith("data:"):
                    continue
                payload = line[5:].strip()
                if not payload or payload == "[DONE]":
                    continue
                ev = json.loads(payload)
                if ev.get("audio_base64"):
                    audio += base64.b64decode(ev["audio_base64"])
                seq = ev.get("chunk_seq", 0)
                offsets[seq] = ev.get("chunk_audio_offset_sec", offsets.get(seq, 0.0))
                if ev.get("alignment"):
                    snaps[seq] = ev["alignment"]
    except urllib.error.HTTPError as e:
        msg = _scrub(e.read().decode(errors="ignore")[:200], key)
        hint = {401: "chave inválida", 402: "pagamento exigido (o plano grátis não cobriu)", 404: "voz não encontrada/visível",
                429: "limite do plano grátis", 503: "servidor ocupado"}.get(e.code, "")
        raise FishError(f"HTTP {e.code} {hint}: {msg}") from None
    except (urllib.error.URLError, TimeoutError, OSError, json.JSONDecodeError) as e:
        raise FishError(_scrub(f"falha de rede/resposta: {e}", key)) from None
    if not audio:
        raise FishError("a API não devolveu áudio")
    Path(path).write_bytes(bytes(audio))
    segs = []
    for seq in sorted(snaps):
        for sg in snaps[seq].get("segments", []):
            segs.append({"text": sg["text"], "start": sg["start"] + offsets.get(seq, 0.0), "end": sg["end"] + offsets.get(seq, 0.0)})
    return align_words(path, text, segs or None)


def _scrub(text, key):
    return text.replace(key, "***") if key else text


async def run(story, args):
    cast = story["cast"]
    key = env_key()
    provider = args.provider
    if provider == "elevenlabs" and not key:
        sys.exit("ELEVENLABS_API_KEY ausente (.env ou ambiente). Use o padrão gratuito: --provider edge")
    _patch_ssl()
    OUT_AUDIO.mkdir(parents=True, exist_ok=True)
    OUT_JSON.parent.mkdir(parents=True, exist_ok=True)
    only = set(args.only)
    timings = json.loads(OUT_JSON.read_text(encoding="utf-8")) if OUT_JSON.exists() and only else {"lines": {}}
    timings["provider"] = provider
    sem = asyncio.Semaphore(4)
    fish_key = env_key("FISH_API_KEY")
    fish_chars = sorted({s["line"]["by"] for s in story["shots"] if s.get("line") and cast[s["line"]["by"]].get("provider") == "fish"})
    for cid in fish_chars:
        model = cast[cid].get("fish_model", FISH_FREE_MODEL)
        if model != FISH_FREE_MODEL and not args.allow_paid:
            sys.exit(f"cast.{cid}: fish_model '{model}' pode ser PAGO. Use {FISH_FREE_MODEL} ou rode com --allow-paid (só com autorização).")
    if fish_chars:
        if not fish_key:
            msg = f"{', '.join(fish_chars)}: FISH_API_KEY ausente (.env da raiz do projeto)"
            if args.strict_fish:
                sys.exit(msg + " — modo --strict-fish: nada foi gerado.")
            print(f"AVISO: {msg} -> usando Edge TTS (alternativa grátis). Falas marcadas como PRÉVIA.")
        else:
            print(f"fish.audio: chave encontrada (oculta) | modelo {FISH_FREE_MODEL if not args.allow_paid else 'conforme cast'} | {', '.join(fish_chars)}")
    jobs = [s for s in story["shots"] if s.get("line") and (not only or s["id"] in only)]
    fish_dead = {"motivo": None}  # falha de conta (401/402/404) desliga o fish para o resto do lote

    async def one(s):
        line = s["line"]
        m = cast[line["by"]]
        path = OUT_AUDIO / f"{s['id']}.mp3"
        async with sem:
            if m.get("provider") == "fish" and fish_key and not fish_dead["motivo"]:
                try:
                    words = await asyncio.to_thread(synth_fish, path, line["text"], m["fish_voice"], fish_key,
                                                    m.get("fish_model", FISH_FREE_MODEL), m.get("fish_speed", 1.0), m.get("fish_language", "pt-BR"))
                    timings["lines"][s["id"]] = {"text": line["text"], "by": line["by"], "voice": f"fish:{m['fish_voice']}:{m.get('fish_model', FISH_FREE_MODEL)}", "words": words}
                    print(f"{s['id']:>6} {line['by']:<10} {words[-1]['end']:5.2f}s  {line['text']}  [fish.audio]")
                    return
                except FishError as e:
                    if args.strict_fish:
                        raise SystemExit(f"{s['id']}: fish.audio falhou ({e}) — modo --strict-fish")
                    if any(c in str(e) for c in ("HTTP 401", "HTTP 402", "HTTP 404")):
                        fish_dead["motivo"] = str(e)
                    print(f"AVISO {s['id']}: fish.audio falhou ({e}) -> Edge TTS (PRÉVIA)")
            if provider == "elevenlabs" and m.get("eleven_voice"):
                words = await asyncio.to_thread(synth_eleven, path, line["text"], m["eleven_voice"], key)
                used = f"elevenlabs:{m['eleven_voice']}"
            else:
                if provider == "elevenlabs":
                    print(f"aviso: {line['by']} sem eleven_voice -> edge")
                words = await synth_edge(path, line["text"], m["voice"], m.get("rate", "+0%"), m.get("pitch", "+0Hz"), m.get("shift", 0))
                used = f"edge:{m['voice']} {m.get('rate', '+0%')} {m.get('pitch', '+0Hz')}"
                if m.get("provider") == "fish":
                    used = "PREVIA-" + used
        words = restore_punctuation(line["text"], words)
        timings["lines"][s["id"]] = {"text": line["text"], "by": line["by"], "voice": used, "words": words}
        print(f"{s['id']:>6} {line['by']:<10} {words[-1]['end']:5.2f}s  {line['text']}")

    await asyncio.gather(*(one(s) for s in jobs))
    order = [s["id"] for s in story["shots"] if s.get("line")]
    timings["lines"] = {k: timings["lines"][k] for k in order if k in timings["lines"]}
    OUT_JSON.write_text(json.dumps(timings, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"{len(jobs)} falas -> {OUT_AUDIO}")


async def preview(story):
    _patch_ssl()
    out = ROOT / "out" / "voices"
    out.mkdir(parents=True, exist_ok=True)
    for cid, m in story["cast"].items():
        text = m.get("sample") or f"Oi, eu sou {m.get('name', cid)}, e essa é a minha voz."
        fish_key = env_key("FISH_API_KEY")
        if m.get("provider") == "fish" and fish_key and m.get("fish_model", FISH_FREE_MODEL) == FISH_FREE_MODEL:
            try:
                await asyncio.to_thread(synth_fish, out / f"{cid}.mp3", text, m["fish_voice"], fish_key, FISH_FREE_MODEL, 1.0, m.get("fish_language", "pt-BR"))
                print(f"{cid}: fish.audio {m['fish_voice'][:8]}… -> {out / (cid + '.mp3')}")
                continue
            except FishError as e:
                print(f"aviso: {cid}: fish.audio falhou ({e}) — prévia com edge")
            await synth_edge(out / f"{cid}.mp3", text, m["voice"], m.get("rate", "+0%"), m.get("pitch", "+0Hz"), m.get("shift", 0))
        else:
            if m.get("provider") == "fish":
                print(f"aviso: {cid} usa fish.audio mas falta FISH_API_KEY — prévia com edge")
            await synth_edge(out / f"{cid}.mp3", text, m["voice"], m.get("rate", "+0%"), m.get("pitch", "+0Hz"), m.get("shift", 0))
        print(f"{cid}: {m['voice']} {m.get('rate', '+0%')} {m.get('pitch', '+0Hz')} -> {out / (cid + '.mp3')}")


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    p = argparse.ArgumentParser()
    p.add_argument("story")
    p.add_argument("--provider", choices=["edge", "elevenlabs"], default="edge")
    p.add_argument("--only", nargs="*", default=[])
    p.add_argument("--preview-voices", action="store_true")
    p.add_argument("--fallback-edge", action="store_true", help="(compatibilidade) o fallback para Edge já é automático")
    p.add_argument("--strict-fish", action="store_true", help="se o fish.audio falhar ou faltar chave, PARA em vez de usar Edge")
    p.add_argument("--allow-paid", action="store_true", help="permite fish_model diferente de s2.1-pro-free (pode cobrar)")
    args = p.parse_args()
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from story_lib import load_story

    story = load_story(args.story)
    asyncio.run(preview(story) if args.preview_voices else run(story, args))


if __name__ == "__main__":
    main()
