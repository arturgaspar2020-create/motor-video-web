"""Gera skins femininas adultas discretas (blusa + calça/saia) no molde da skill. Uso: python make_modest_skins.py <pasta assets/skins>"""
import json, sys
from pathlib import Path
from PIL import Image, ImageDraw, ImageFilter
import random

def shade(c, k):
    return tuple(max(0, min(255, int(v * k))) for v in c)

def hexrgb(h):
    h = h.lstrip('#'); return tuple(int(h[i:i+2], 16) for i in (0, 2, 4))

def fabric(d, rect, col, rnd, vertical=True):
    x, y, w, h = rect
    d.rectangle([x, y, x + w - 1, y + h - 1], fill=col)
    for i in range(40):  # leve textura de tecido
        yy = y + rnd.randint(0, h - 1)
        d.line([x, yy, x + w - 1, yy], fill=shade(col, 0.96 + rnd.random() * 0.08))
    d.rectangle([x, y, x + w - 1, y + h - 1], outline=shade(col, 0.7), width=3)

def make(spec, out):
    rnd = random.Random(spec['id'])
    top, bot, skin = hexrgb(spec['top']), hexrgb(spec['bottom']), hexrgb(spec['skin'])
    shoe = hexrgb(spec.get('shoe', '#3a2a22'))
    S = Image.new('RGB', (1024, 1024), (0, 0, 0)); d = ImageDraw.Draw(S)
    torso = {'pz': (128, 128, 256, 256), 'nz': (512, 128, 256, 256), 'nx': (0, 128, 128, 256), 'px': (384, 128, 128, 256), 'py': (128, 0, 256, 128), 'ny': (128, 384, 256, 128)}
    for k, r in torso.items():
        fabric(d, r, top, rnd)
    # frente: decote em V com pele, botões, barra
    x, y, w, h = torso['pz']
    d.polygon([(x + 96, y), (x + 160, y), (x + 128, y + 58)], fill=skin)
    d.line([(x + 96, y), (x + 128, y + 58), (x + 160, y)], fill=shade(top, 0.6), width=5)
    if spec.get('buttons', True):
        for i in range(4):
            cy = y + 80 + i * 40; d.ellipse([x + 122, cy, x + 134, cy + 12], fill=shade(top, 1.25), outline=shade(top, 0.6))
    d.rectangle([x, y + h - 22, x + w - 1, y + h - 1], fill=shade(top, 0.85))
    if spec.get('pattern') == 'flores':
        for i in range(18):
            px, py = x + rnd.randint(10, w - 20), y + rnd.randint(70, h - 40)
            c = hexrgb(spec.get('accent', '#ffffff'))
            for a in range(5):
                d.ellipse([px - 6 + (a - 2) * 4, py - 6 + (a % 2) * 5, px + 2 + (a - 2) * 4, py + 2 + (a % 2) * 5], fill=c)
    xb, yb, _, _ = torso['nz']; d.rectangle([xb, yb + h - 22, xb + w - 1, yb + h - 1], fill=shade(top, 0.85))
    # braços: manga até ~45%, depois pele (mão embaixo)
    for off in (0, 512):
        arm = {'nx': (0, 640, 128, 256), 'pz': (128, 640, 128, 256), 'px': (256, 640, 128, 256), 'nz': (384, 640, 128, 256)}
        for k, (ax, ay, aw, ah) in arm.items():
            ax += off; sl = int(ah * spec.get('sleeve', 0.45))
            fabric(d, (ax, ay, aw, sl), top, rnd)
            d.rectangle([ax, ay + sl, ax + aw - 1, ay + ah - 1], fill=skin)
            d.rectangle([ax, ay + sl - 10, ax + aw - 1, ay + sl], fill=shade(top, 0.8))
        fabric(d, (128 + off, 512, 128, 128), top, rnd)
        d.rectangle([128 + off, 896, 255 + off, 1023], fill=skin)
    P = Image.new('RGB', (1024, 512), (0, 0, 0)); e = ImageDraw.Draw(P)
    skirt = spec.get('skirt')
    for off in (0, 512):
        for k, (lx, ly, lw, lh) in {'nx': (0, 128, 128, 256), 'pz': (128, 128, 128, 256), 'px': (256, 128, 128, 256), 'nz': (384, 128, 128, 256)}.items():
            lx += off
            if skirt:
                cut = int(lh * 0.55)
                fabric(e, (lx, ly, lw, cut), bot, rnd)
                e.rectangle([lx, ly + cut, lx + lw - 1, ly + lh - 1], fill=skin)
            else:
                fabric(e, (lx, ly, lw, lh), bot, rnd)
                if spec.get('jeans'):
                    e.line([(lx + lw // 2, ly), (lx + lw // 2, ly + lh)], fill=shade(bot, 1.25), width=2)
            e.rectangle([lx, ly + lh - 40, lx + lw - 1, ly + lh - 1], fill=shoe)
            e.rectangle([lx, ly + lh - 10, lx + lw - 1, ly + lh - 1], fill=shade(shoe, 0.6))
            if k == 'pz':
                e.rectangle([lx, ly, lx + lw - 1, ly + 14], fill=shade(bot, 0.75))
        fabric(e, (128 + off, 0, 128, 128), bot, rnd)
        e.rectangle([128 + off, 384, 255 + off, 511], fill=shade(shoe, 0.6))
    S = S.filter(ImageFilter.SMOOTH); P = P.filter(ImageFilter.SMOOTH)
    o = out / spec['id']; o.mkdir(parents=True, exist_ok=True)
    S.save(o / 'camisa.jpg', quality=90); P.save(o / 'calca.jpg', quality=90)

SPECS = [
    {'id': '32', 'top': '#9b7fd8', 'bottom': '#3b5f9a', 'skin': '#f9c8a8', 'tone': 'branca', 'color': 'lilás', 'jeans': True},
    {'id': '33', 'top': '#5fc8b8', 'bottom': '#5fc8b8', 'skin': '#6e3820', 'tone': 'negra', 'color': 'verde-água', 'skirt': True, 'buttons': False, 'pattern': 'flores', 'accent': '#ffffff'},
    {'id': '34', 'top': '#ff8a6b', 'bottom': '#34507e', 'skin': '#753e25', 'tone': 'negra', 'color': 'coral', 'jeans': True},
    {'id': '35', 'top': '#f2c94c', 'bottom': '#c9b08a', 'skin': '#f9c8a8', 'tone': 'branca', 'color': 'amarela', 'sleeve': 0.8},
]

if __name__ == '__main__':
    out = Path(sys.argv[1]); cat = json.loads((out / 'skins.json').read_text(encoding='utf-8'))
    for s in SPECS:
        make(s, out)
        cat['skins'][s['id']] = {'id': s['id'], 'gender': 'F', 'age': 'adulto', 'tone': s['tone'], 'color': s['color'], 'role': 'mae',
                                 'skin_color': s['skin'], 'shirt': f"skins/{s['id']}/camisa.jpg", 'pants': f"skins/{s['id']}/calca.jpg",
                                 'source_files': {'gerado': 'make_modest_skins.py'}, 'style': 'discreta'}
    (out / 'skins.json').write_text(json.dumps(cat, ensure_ascii=False, indent=1), encoding='utf-8')
    print('ok', [s['id'] for s in SPECS])
