"""Trilha instrumental sintetizada que acompanha o CLIMA de cada plano (mood do story.json).

Lê src/data/timeline.json, escolhe o arranjo de cada compasso pelo mood do plano em que ele começa
(calm, funny, tension, sad, epic, mystery), grava public/audio/music.wav e marca hasMusic=true.
Instrumentos de synth_kit.py (reaproveitados do music.py original). Livre de direitos.

Uso (na raiz do projeto, depois de build_timeline.py):  python scripts/music_story.py [--bpm 112]
"""

import argparse
import json
import sys
from pathlib import Path

import numpy as np
import soundfile as sf

sys.path.insert(0, str(Path(__file__).resolve().parent))
from synth_kit import SR, bass, bell, clap, hp, ir, kick, lp, marimba, pad, piano, place, pluck, shaker, snare, stereo, tuba, verb  # noqa: E402

ROOT = Path.cwd()
CH = {"C": [48, 52, 55, 60], "G": [43, 47, 50, 55], "Am": [45, 48, 52, 57], "F": [41, 45, 48, 53],
      "Dm": [50, 53, 57, 62], "E": [40, 44, 47, 52], "Bb": [46, 50, 53, 58]}
ROOTN = {"C": 36, "G": 31, "Am": 33, "F": 29, "Dm": 38, "E": 28, "Bb": 34}
PROG = {
    "calm": ["C", "Am", "F", "G"],
    "funny": ["C", "G", "C", "F"],
    "tension": ["Am", "F", "E", "Am"],
    "sad": ["Am", "F", "C", "G"],
    "epic": ["C", "G", "Am", "F"],
    "mystery": ["Am", "Dm", "E", "Bb"],
}


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    ap = argparse.ArgumentParser()
    ap.add_argument("--bpm", type=float, default=112)
    args = ap.parse_args()
    tl_path = ROOT / "src" / "data" / "timeline.json"
    tl = json.loads(tl_path.read_text(encoding="utf-8"))
    fps = tl["fps"]
    dur = tl["totalFrames"] / fps + 0.6
    n = int(dur * SR)
    beat = 60 / args.bpm
    bar = beat * 4
    starts = [(s["start"] / fps, s["mood"]) for s in tl["shots"]]

    def mood_at(t):
        m = starts[0][1]
        for st, md in starts:
            if st <= t + 0.05:
                m = md
        return m

    drums, low, pads, leads = (np.zeros((n, 2)) for _ in range(4))
    kicks = []
    t0, k = 0.0, 0
    while t0 < dur:
        mood = mood_at(t0)
        name = PROG[mood][k % 4]
        chord = CH[name]
        r = ROOTN[name]
        d = min(bar, dur - t0)
        if mood == "calm":
            place(pads, pad(chord, d + 0.6, 1400, 0.45), t0)
            for i in range(8):
                place(leads, stereo(pluck(chord[[0, 2, 1, 3][i % 4]] + 12), (-0.3, 0.3)[i % 2]), t0 + i * beat / 2, 0.5)
            for i in range(8):
                place(drums, shaker(), t0 + i * beat / 2, 0.35)
        elif mood == "funny":
            for i in range(4):
                tb = t0 + i * beat
                if i % 2 == 0:
                    place(low, stereo(tuba(r + (0 if i == 0 else 7), beat * 0.5)), tb, 0.9)
                    place(drums, kick(0.6), tb)
                    kicks.append((tb, 0.6))
                else:
                    for m in chord[1:]:
                        place(leads, stereo(marimba(m + 12, 0.25), 0.2), tb, 0.35)
                    place(drums, clap(), tb, 0.45)
            for i in (1, 3, 5, 7):
                place(leads, stereo(pluck(chord[i % 4] + 24, 0.2), -0.3), t0 + i * beat / 2, 0.22)
        elif mood == "tension":
            place(pads, pad(chord, d + 0.6, 800, 0.6), t0)
            for i in range(8):
                place(low, stereo(bass(r, beat * 0.4)), t0 + i * beat / 2, 0.55)
            for i in range(16):
                place(drums, shaker(), t0 + i * beat / 4, 0.18 + 0.12 * (i % 4 == 0))
            if k % 2 == 1:
                place(leads, stereo(bell(chord[3] + 12, 1.8), 0.4), t0 + beat * 3, 0.18)
        elif mood == "sad":
            place(pads, pad(chord, d + 0.8, 1000, 0.5), t0)
            for i, idx in enumerate([0, 2, 3, 2]):
                place(leads, stereo(piano(chord[idx] + 12, 1.8), -0.2 + 0.13 * i), t0 + i * beat, 0.55)
            place(low, stereo(bass(r, bar * 0.9) * 0.6), t0, 0.5)
        elif mood == "epic":
            place(pads, pad(chord, d + 0.6, 2400, 0.6), t0)
            for i in range(4):
                place(drums, kick(0.9), t0 + i * beat)
                kicks.append((t0 + i * beat, 0.9))
                if i % 2:
                    place(drums, stereo(snare()), t0 + i * beat, 0.5)
            for i in range(8):
                place(low, stereo(bass(r, beat * 0.42)), t0 + i * beat / 2, 0.65)
                place(leads, stereo(marimba(chord[[0, 1, 2, 3, 2, 1, 2, 3][i]] + 12), (-0.35, 0.35)[i % 2]), t0 + i * beat / 2, 0.4)
        else:  # mystery
            place(pads, pad(chord, d + 0.8, 700, 0.65), t0)
            for i in (0, 3, 5):
                place(leads, stereo(bell(chord[(i + k) % 4] + 24, 1.6), (-0.5, 0.5)[i % 2]), t0 + i * beat / 2, 0.16)
            place(drums, kick(0.35), t0)
        t0 += bar
        k += 1

    sc = np.ones(n)
    tf = np.arange(n) / SR
    for kt, depth in kicks:
        i = int(kt * SR)
        seg = tf[i: i + int(0.3 * SR)] - kt
        sc[i: i + len(seg)] = np.minimum(sc[i: i + len(seg)], 1 - 0.4 * depth * np.exp(-seg / 0.09))
    sc = lp(sc, 40)
    pads *= sc[:, None]
    wet = verb(pads * 0.3 + leads * 0.4, ir(2.2, 0.6)) * 0.7
    mix = drums * 0.7 + low * 0.85 + pads * 0.85 + leads * 0.85 + wet
    mix = hp(mix, 30)
    mix *= np.clip((dur - tf) / 1.2, 0, 1)[:, None] * np.clip(tf / 0.05, 0, 1)[:, None]
    mix = np.tanh(mix * 1.1)
    mix *= 0.89 / max(1e-9, np.max(np.abs(mix)))
    out = ROOT / "public" / "audio" / "music.wav"
    out.parent.mkdir(parents=True, exist_ok=True)
    sf.write(out, mix.astype(np.float32), SR, subtype="PCM_16")
    tl["hasMusic"] = True
    tl_path.write_text(json.dumps(tl, ensure_ascii=False, indent=1), encoding="utf-8")
    moods = sorted({m for _, m in starts})
    print(f"music: {out} ({dur:.1f}s, {k} compassos, climas: {', '.join(moods)}) — timeline.hasMusic=true")


main()
