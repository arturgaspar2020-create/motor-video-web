"""Gera src/data/timeline.json (tudo em frames) a partir de story.json + src/data/vo.json.

Os cortes são DERIVADOS DA VOZ REAL: cada plano dura lead + fala + tail (+ hold).
Sem vo.json (ou com --estimate) gera uma prévia com tempos estimados, sem áudio.

Uso (na raiz do projeto Remotion):
    python scripts/build_timeline.py story.json              # usa src/data/vo.json se existir
    python scripts/build_timeline.py story.json --estimate   # prévia silenciosa
"""

import argparse
import json
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))
from story_lib import WORDS_PER_SEC_ESTIMATE, ceil_f, cut_lengths, load_story, resolve_at, validate, words_of  # noqa: E402

ROOT = Path.cwd()
SFX_DIR = ROOT / "public" / "audio" / "sfx"
AUDIO_EXT = (".wav", ".mp3", ".ogg", ".m4a")
# piso padrão de cada cenário para os passos automáticos (sobrescreva com "floor" no plano)
FLOOR = {"street": "asfalto", "park": "grama", "bedroom": "madeira", "livingroom": "madeira",
         "classroom": "piso", "rooftop": "concreto", "void": "concreto", "hospital": "piso"}
# duração padrão (frames) de cada efeito quando "until" não é dado
FX_LEN = {"dust": 22, "sparkle": 36, "confetti": 75, "energy_purple": 45, "energy_blue": 45, "impact": 14,
          "speedlines": 18, "smoke": 40, "hearts": 40, "stars": 30}


def pick_sound(name, seed):
    """Arquivo do som: nome exato, ou uma das variações nome_01, nome_02... (sorteio fixo por plano)."""
    import hashlib
    import re as _re
    for ext in AUDIO_EXT:
        if (SFX_DIR / f"{name}{ext}").exists():
            return f"audio/sfx/{name}{ext}"
    if not SFX_DIR.exists():
        return None
    vars_ = sorted(p.name for p in SFX_DIR.iterdir() if p.suffix.lower() in AUDIO_EXT and _re.fullmatch(_re.escape(name) + r"_\d+", p.stem))
    if not vars_:
        return None
    h = int(hashlib.md5(seed.encode()).hexdigest(), 16)
    return "audio/sfx/" + vars_[h % len(vars_)]


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    p = argparse.ArgumentParser()
    p.add_argument("story")
    p.add_argument("--estimate", action="store_true")
    p.add_argument("--out", default="src/data/timeline.json")
    args = p.parse_args()

    story = load_story(args.story)
    errors, warns = validate(story)
    for w in warns:
        print("aviso:", w)
    if errors:
        for e in errors:
            print("ERRO:", e)
        sys.exit(1)

    fps = int(story.get("fps", 30))
    vo_path = ROOT / "src" / "data" / "vo.json"
    vo = {} if args.estimate or not vo_path.exists() else json.loads(vo_path.read_text(encoding="utf-8"))
    vo_dir = ROOT / "public" / "audio" / "vo"

    shots_out, cursor = [], 0
    for s in story["shots"]:
        sid = s["id"]
        line = s.get("line")
        lead = s.get("lead", 0.12 if line else 0)
        tail = s.get("tail", 0.18 if line else 0)
        hold = s.get("hold", 0 if line else 1.0)
        line_out, words = None, []
        if line:
            at = ceil_f(lead, fps)
            v = vo.get(sid)
            has_audio = bool(v) and (vo_dir / f"{sid}.wav").exists()
            if v:
                words = [{"text": w["text"], "start": round(w["start"] * fps), "end": max(round(w["start"] * fps) + 1, round(w["end"] * fps))} for w in v["words"]]
                frames = ceil_f(v["seconds"], fps)
            else:
                toks = words_of(line["text"])
                per = fps / WORDS_PER_SEC_ESTIMATE
                words = [{"text": t, "start": round(i * per), "end": round((i + 0.85) * per)} for i, t in enumerate(toks)]
                frames = ceil_f(len(toks) / WORDS_PER_SEC_ESTIMATE, fps)
            duration = at + frames + ceil_f(tail + hold, fps)
            line_out = {"by": line["by"], "text": line["text"], "voKey": sid, "at": at, "frames": frames, "words": words, "hasAudio": has_audio}
        else:
            at = 0
            duration = max(6, ceil_f(hold, fps))

        def R(v, where):
            return resolve_at(v, fps, at, words, duration, f"{sid}.{where}")

        actors = []
        for a in s.get("actors", []):
            o = {"id": a["id"], "x": a.get("x", 0), "z": a.get("z", 0), "face": a.get("face", 0), "pose": a.get("pose", "idle"), "expr": a.get("expr", "neutral"), "keys": []}
            if "y" in a:
                o["y"] = a["y"]
            if "gaze" in a:
                o["gaze"] = a["gaze"]
            if "to" in a:
                o["to"] = a["to"]
                mv = a.get("move", ["start", "end"])
                o["moveFrom"], o["moveTo"] = R(mv[0], "move[0]"), R(mv[1], "move[1]")
            for k in a.get("keys", []):
                kk = {"at": R(k.get("at", 0), "keys.at")}
                for f in ("pose", "expr", "face", "gaze"):
                    if f in k:
                        kk[f] = k[f]
                o["keys"].append(kk)
            actors.append(o)

        cuts = [{"at": 0, "camera": s["camera"]}]
        for c in s.get("cuts", []):
            cuts.append({"at": R(c["at"], "cuts.at"), "camera": c["camera"]})
        cuts.sort(key=lambda c: c["at"])
        sfx = [{"name": x["name"], "at": R(x.get("at", 0), "sfx.at"), "volume": x.get("volume", 0.6)} for x in s.get("sfx", [])]
        # passos automáticos: atores andando/correndo ganham um passo a cada pisada, com o som do piso do cenário
        if s.get("footsteps", True):
            for a in actors:
                if "to" not in a:
                    continue
                pose = a["pose"] if a["pose"] in ("run", "sneak") else "walk"
                step = {"walk": 8.7, "run": 5.2, "sneak": 15.7}[pose]
                floor = s.get("floor") or FLOOR.get(s["set"], "concreto")
                f = float(a["moveFrom"])
                while f < a["moveTo"]:
                    sfx.append({"name": f"passo_{floor}", "at": int(f), "volume": 0.3 if pose != "sneak" else 0.15, "auto": True})
                    f += step
        if not args.estimate:
            resolved, missing = [], set()
            for k, x in enumerate(sfx):
                fpath = pick_sound(x["name"], f"{sid}-{k}")
                if fpath:
                    resolved.append({kk: vv for kk, vv in {**x, "file": fpath}.items() if kk != "auto"})
                elif not x.get("auto"):
                    missing.add(x["name"])
            if missing:
                print(f"aviso: {sid}: sons não encontrados em public/audio/sfx (rode sfx_story.py ou adicione à biblioteca): {', '.join(sorted(missing))}")
            sfx = resolved
        else:
            sfx = []
        flash = [R(x, "flash") for x in s.get("flash", [])]
        o = {"id": sid, "start": cursor, "duration": duration, "set": s["set"], "time": s.get("time", "day"), "mood": s.get("mood", "calm"),
             "line": line_out, "actors": actors, "cuts": cuts, "sfx": sfx, "flash": flash}
        amb = s.get("ambience")
        if amb and not args.estimate:
            amb = {"name": amb, "volume": 0.22} if isinstance(amb, str) else amb
            fpath = pick_sound(amb["name"], f"{sid}-amb")
            if fpath:
                o["ambience"] = {"file": fpath, "volume": amb.get("volume", 0.22)}
            else:
                print(f"aviso: {sid}: som ambiente '{amb['name']}' não encontrado em public/audio/sfx")
        if s.get("props"):
            for pr in s["props"]:
                if not (ROOT / "public" / pr["src"]).exists():
                    print(f"ERRO: {sid}: modelo não encontrado em public/{pr['src']}")
                    sys.exit(1)
            o["props"] = s["props"]
        if s.get("title"):
            t = s["title"]
            o["title"] = {"text": t["text"], "at": R(t.get("at", 0), "title.at"), "until": R(t.get("until", "end"), "title.until") + 1}
        # partículas/efeitos 3D (poeira, brilho, confete, energia, impacto, linhas de velocidade...)
        fx_out = []
        for k, e in enumerate(s.get("fx", [])):
            a0 = R(e.get("at", 0), "fx.at")
            a1 = R(e["until"], "fx.until") + 1 if "until" in e else a0 + FX_LEN.get(e["type"], 24)
            fe = {"type": e["type"], "at": a0, "until": max(a0 + 2, a1), "seed": k}
            for f in ("on", "pos", "color", "size", "count"):
                if f in e:
                    fe[f] = e[f]
            fx_out.append(fe)
        if fx_out:
            o["fx"] = fx_out
        for f in ("weather", "fog", "clouds"):
            if f in s:
                o[f] = s[f]
        shots_out.append(o)
        cursor += duration

    for cid, c in story["cast"].items():
        if c.get("rig") and not (ROOT / "public" / c["rig"]["src"]).exists():
            print(f"ERRO: cast.{cid}: modelo do personagem não encontrado em public/{c['rig']['src']} (rode setup_project.py)")
            sys.exit(1)
        for ac in (c.get("look") or {}).get("accessories", []):
            if not (ROOT / "public" / ac["src"]).exists():
                print(f"ERRO: cast.{cid}: acessório não encontrado em public/{ac['src']}")
                sys.exit(1)
    music = (ROOT / "public" / "audio" / "music.wav").exists() and not args.estimate
    tl = {"title": story.get("title", ""), "fps": fps, "width": 1080, "height": 1920, "totalFrames": cursor, "hasMusic": music, "cast": story["cast"], "shots": shots_out}
    out = ROOT / args.out
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(tl, ensure_ascii=False, indent=1), encoding="utf-8")
    lip = ROOT / "src" / "data" / "lipsync.json"
    if not lip.exists() or args.estimate:
        lip.write_text("{}", encoding="utf-8")

    vt = ROOT / "scripts" / "out" / "vo-timings.json"
    if vt.exists():
        prev = [k for k, v in json.loads(vt.read_text(encoding="utf-8")).get("lines", {}).items() if str(v.get("voice", "")).startswith("PREVIA-")]
        if prev:
            print(f"  AVISO: falas com voz PROVISÓRIA (Edge no lugar do fish.audio): {', '.join(prev)} — não entregue como vídeo final")
    cl = cut_lengths(tl)
    with_audio = sum(1 for s in shots_out if s["line"] and s["line"]["hasAudio"])
    with_line = sum(1 for s in shots_out if s["line"])
    print(f"timeline: {len(shots_out)} planos, {len(cl)} enquadramentos, {cursor} frames = {cursor / fps:.2f}s")
    print(f"  enquadramento médio {sum(cl) / len(cl):.2f}s, maior {max(cl):.2f}s | falas com áudio: {with_audio}/{with_line} | música: {music}")
    long = [f"{s['id']}" for s in shots_out for a, b in zip([c["at"] for c in s["cuts"]], [c["at"] for c in s["cuts"]][1:] + [s["duration"]]) if (b - a) / fps > 3.2]
    if long:
        print("  aviso: enquadramentos > 3,2 s (adicione cortes internos):", ", ".join(sorted(set(long))))
    target = story.get("target_seconds")
    if target and abs(cursor / fps - target) > target * 0.2:
        print(f"  aviso: duração {cursor / fps:.1f}s difere >20% do alvo {target}s — ajuste o texto, não a velocidade da voz")


main()
