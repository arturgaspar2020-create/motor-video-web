"""Cria um projeto Remotion novo a partir de assets/template + scripts desta skill.

Uso:
    python <skill>/scripts/setup_project.py <pasta-do-projeto> [--story story.json] [--models <pasta .glb>] [--no-install]

Não sobrescreve uma pasta existente com conteúdo (use outro nome). Verifica as dependências
de Python/Node/ffmpeg e diz o que falta, sem instalar nada no sistema por conta própria.
"""

import argparse
import importlib.util
import shutil
import subprocess
import sys
from pathlib import Path

SKILL = Path(__file__).resolve().parent.parent


def main():
    sys.stdout.reconfigure(encoding="utf-8")
    p = argparse.ArgumentParser()
    p.add_argument("dest")
    p.add_argument("--story")
    p.add_argument("--no-install", action="store_true")
    p.add_argument("--models", help="pasta com .glb do usuário (copiada para public/models/lib)")
    p.add_argument("--sounds", help="pasta de sons do usuário (subpastas ok) -> public/audio/sfx (nomes em minúsculas)")
    p.add_argument("--textures", help="pasta de texturas/roupas do usuário (.png/.jpg) -> public/textures")
    a = p.parse_args()
    dest = Path(a.dest).resolve()
    if dest.exists() and any(dest.iterdir()):
        sys.exit(f"{dest} já existe e não está vazia — escolha outro nome")
    shutil.copytree(SKILL / "assets" / "template", dest, ignore=shutil.ignore_patterns("node_modules", "out", ".remotion"), dirs_exist_ok=True)
    shutil.copytree(SKILL / "scripts", dest / "scripts", ignore=shutil.ignore_patterns("__pycache__", "setup_project.py"), dirs_exist_ok=True)
    if (SKILL / "characters").is_dir():  # personagens fixos (ex.: Gojo): voz exclusiva + modelo 3D próprio
        shutil.copytree(SKILL / "characters", dest / "characters", ignore=shutil.ignore_patterns("*.glb", "*.png"), dirs_exist_ok=True)
        import json as _json
        for pf in (SKILL / "characters").glob("*.json"):
            for src, dst in _json.loads(pf.read_text(encoding="utf-8")).get("model_files", {}).items():
                (dest / dst).parent.mkdir(parents=True, exist_ok=True)
                shutil.copy(SKILL / src, dest / dst)
    (dest / "src" / "data").mkdir(parents=True, exist_ok=True)
    if a.story:
        shutil.copy(a.story, dest / "story.json")
        models = Path(a.story).resolve().parent / "models"
        if models.is_dir():  # modelos .glb que acompanham a história (props/acessórios)
            shutil.copytree(models, dest / "public" / "models", dirs_exist_ok=True)
    if a.models:  # biblioteca de modelos do usuário (ex.: pasta modelos\) -> public/models/lib
        shutil.copytree(Path(a.models), dest / "public" / "models" / "lib", ignore=shutil.ignore_patterns("*.md", "*.jpg", "*.png", "*.zip"), dirs_exist_ok=True)
    if not (dest / ".env").exists() and (dest / ".env.example").exists():
        shutil.copy(dest / ".env.example", dest / ".env")  # vazio: o usuário cola as chaves aqui
    print("projeto criado em", dest)

    missing = [m for m in ("edge_tts", "numpy", "scipy", "soundfile", "PIL") if importlib.util.find_spec(m) is None]
    if missing:
        names = {"edge_tts": "edge-tts", "PIL": "pillow"}
        print("Python: faltam módulos ->", "python -m pip install " + " ".join(names.get(m, m) for m in missing))
    for tool in ("node", "npm", "ffmpeg", "ffprobe"):
        if shutil.which(tool) is None:
            print(f"falta no sistema: {tool}")
    if not a.no_install and shutil.which("npm"):
        print("npm install (pode levar ~1 min)...")
        r = subprocess.run("npm install --no-audit --no-fund", cwd=dest, shell=True)
        if r.returncode != 0:
            sys.exit("npm install falhou — veja a saída acima")
    A = SKILL / "assets"
    # biblioteca da skill: skins (camisa+calça), texturas de cenário, sons CC0/CC-BY, cabelos .glb, paleta de vozes
    for src, dst in (("skins", "public/skins"), ("textures", "public/textures"), ("sons", "public/audio/sfx"), ("models", "public/models")):
        if (A / src).is_dir():
            shutil.copytree(A / src, dest / dst, dirs_exist_ok=True, ignore=shutil.ignore_patterns("*.md"))
    if (A / "voices.json").exists():
        shutil.copy(A / "voices.json", dest / "public" / "voices.json")
    if a.sounds:  # biblioteca de sons: achata subpastas; nomes em minúsculas, espaços -> _
        out = dest / "public" / "audio" / "sfx"
        out.mkdir(parents=True, exist_ok=True)
        n = 0
        for f in Path(a.sounds).rglob("*"):
            if f.suffix.lower() in (".wav", ".mp3", ".ogg", ".m4a"):
                shutil.copy(f, out / (f.stem.lower().replace(" ", "_").replace("-", "_") + f.suffix.lower()))
                n += 1
        print(f"sons copiados: {n}")
    if a.textures:
        shutil.copytree(Path(a.textures), dest / "public" / "textures", dirs_exist_ok=True)
    if (SKILL / "assets" / "moldes").is_dir():
        shutil.copytree(SKILL / "assets" / "moldes", dest / "public" / "moldes", dirs_exist_ok=True)
    if a.story:
        subprocess.run([sys.executable, "scripts/build_timeline.py", "story.json", "--estimate"], cwd=dest)
    print("próximo passo: cd", dest, "&& python scripts/cast_voiceover.py story.json")


main()
