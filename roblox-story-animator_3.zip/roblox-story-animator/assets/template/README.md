# Template — Roblox Story Animator (Remotion + React Three Fiber)

Projeto Remotion que transforma `src/data/timeline.json` em vídeo 1080×1920. Crie projetos com
`python <skill>/scripts/setup_project.py <pasta> --story story.json` (não edite este template direto).

```
src/
  Main.tsx                  canvas 3D único + legendas/título/flash/vinheta + áudio
  timeline.ts               lê timeline.json/lipsync.json, valida soma de frames, boca por frame
  types.ts                  contrato de dados (espelhado em scripts/story_lib.py)
  character/
    BlockyCharacter.tsx     boneco de blocos (R6), cabelo, chapéus, acessórios, rosto em canvas
    RiggedCharacter.tsx     personagem de .glb com esqueleto Roblox animado (ex.: Gojo) + rosto redesenhado
    faceDraw.ts             18 expressões desenhadas + boca falante + lágrimas/suor/veia/brilhos
    poses.ts                26 poses procedurais (função pura do frame) + blend
    actorState.ts           resolve pose/expressão/posição/piscar/"pop" de careta num frame
  world/
    Sets.tsx                7 cenários + luz por horário + estrelas/lua
    ShotCamera.tsx          12 tipos de plano × 10 movimentos, anti-colisão, tremor
    GlbModel.tsx            carregador .glb (height/width, anchor, parts, tint, spec-gloss, ossos)
    ModelProp.tsx           .glb parado no cenário (props)
  overlay/                  legendas palavra a palavra, título, flash, fonte local
  audio/Soundtrack.tsx      vozes, efeitos e trilha com ducking
public/fonts/               Lilita One (SIL OFL 1.1, ver OFL.txt)
src/data/timeline.json      stub (prévia da história de exemplo) — substituído por build_timeline.py
```

`npx remotion studio` abre a prévia; render: `npx remotion render src/index.ts RobloxStory out/x.mp4 --gl=angle`.
