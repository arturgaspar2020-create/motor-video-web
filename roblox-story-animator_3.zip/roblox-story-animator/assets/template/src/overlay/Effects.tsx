import { AbsoluteFill, random, spring, useCurrentFrame, useVideoConfig } from "remotion";
import { fontFamily } from "./font";
import { shotAt } from "../timeline";


/** Flash branco curto nos impactos (shot.flash) e no primeiro frame de planos marcados. */
export const Flash: React.FC = () => {
  const frame = useCurrentFrame();
  const { shot, local } = shotAt(frame);
  let o = 0;
  for (const f of shot.flash) if (local >= f && local < f + 6) o = Math.max(o, 0.85 * (1 - (local - f) / 6));
  if (o <= 0) return null;
  return <AbsoluteFill style={{ background: "#ffffff", opacity: o }} />;
};

/** Texto grande (título, "3 DIAS DEPOIS…", onomatopeia). */
export const TitleCard: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps } = useVideoConfig();
  const { shot, local } = shotAt(frame);
  const t = shot.title;
  if (!t || local < t.at || local >= t.until) return null;
  const s = spring({ frame: local - t.at, fps, config: { damping: 9, stiffness: 180 } });
  return (
    <AbsoluteFill style={{ alignItems: "center", paddingTop: 330 }}>
      <div style={{ fontFamily, fontSize: 120, color: "#ffe14d", WebkitTextStroke: "18px #16131f", paintOrder: "stroke fill", textAlign: "center", width: 940, lineHeight: 1.05, transform: `scale(${s}) rotate(${-4 + 4 * s}deg)`, textShadow: "0 10px 0 rgba(0,0,0,0.35)" }}>
        {t.text}
      </div>
    </AbsoluteFill>
  );
};

export const Vignette: React.FC = () => <AbsoluteFill style={{ background: "radial-gradient(ellipse 80% 70% at 50% 50%, rgba(0,0,0,0) 60%, rgba(0,0,0,0.28) 100%)", pointerEvents: "none" }} />;

/** Linhas de velocidade estilo anime (fx "speedlines", e automáticas nos primeiros frames de "impact"). */
export const SpeedLines: React.FC = () => {
  const frame = useCurrentFrame();
  const { width, height } = useVideoConfig();
  const { shot, local } = shotAt(frame);
  let o = 0;
  let seed = 0;
  for (const e of shot.fx ?? []) {
    const until = e.type === "impact" ? Math.min(e.until, e.at + 10) : e.until;
    if ((e.type === "speedlines" || e.type === "impact") && local >= e.at && local < until) {
      o = Math.max(o, e.type === "impact" ? 1 - (local - e.at) / 10 : Math.min(1, (until - local) / 5));
      seed = e.seed;
    }
  }
  if (o <= 0) return null;
  const step = Math.floor(local / 2);
  const cx = width / 2;
  const cy = height * 0.45;
  const R = Math.hypot(width, height) * 0.6;
  const lines = Array.from({ length: 64 }).map((_, i) => {
    const a = (i / 64) * Math.PI * 2 + random(`sl${seed}-${step}-${i}`) * 0.08;
    const inner = R * (0.42 + random(`si${seed}-${step}-${i}`) * 0.25);
    const w = 4 + random(`sw${seed}-${step}-${i}`) * 14;
    const ca = Math.cos(a);
    const sa = Math.sin(a);
    const px = -sa * w;
    const py = ca * w;
    return `M${cx + ca * R + px},${cy + sa * R + py} L${cx + ca * R - px},${cy + sa * R - py} L${cx + ca * inner},${cy + sa * inner} Z`;
  });
  return (
    <AbsoluteFill style={{ opacity: o * 0.85, pointerEvents: "none" }}>
      <svg width={width} height={height}>
        <path d={lines.join(" ")} fill="#ffffff" />
      </svg>
    </AbsoluteFill>
  );
};
