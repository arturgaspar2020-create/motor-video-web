import { spring, useCurrentFrame, useVideoConfig } from "remotion";
import { fontFamily } from "./font";
import { shotAt, TL } from "../timeline";
import type { Shot } from "../types";

// Legendas estilo Shorts sincronizadas palavra a palavra: blocos de 1–3 palavras no centro da tela,
// a palavra falada "pula" e a cor segue quem fala (narrador branco; personagens com cor própria).


const MAX_WORDS = 3;
const MAX_CHARS = 16;

type Chunk = { words: { text: string; start: number; end: number }[]; from: number; to: number };

const chunksOf = (shot: Shot): Chunk[] => {
  const line = shot.line;
  if (!line) return [];
  const out: Chunk[] = [];
  let cur: Chunk["words"] = [];
  const flush = () => {
    if (cur.length) out.push({ words: cur, from: line.at + cur[0].start, to: 0 });
    cur = [];
  };
  for (const w of line.words) {
    const len = cur.reduce((n, x) => n + x.text.length + 1, 0) + w.text.length;
    if (cur.length >= MAX_WORDS || (cur.length && len > MAX_CHARS)) flush();
    cur.push(w);
    if (/[.!?…,;:]$/.test(w.text)) flush();
  }
  flush();
  for (let i = 0; i < out.length; i++) {
    const last = out[i].words[out[i].words.length - 1];
    out[i].to = i + 1 < out.length ? out[i + 1].from : Math.min(shot.duration, line.at + last.end + 8);
  }
  return out;
};

export const Captions: React.FC = () => {
  const frame = useCurrentFrame();
  const { fps, width } = useVideoConfig();
  const { shot, local } = shotAt(frame);
  const chunk = chunksOf(shot).find((c) => local >= c.from && local < c.to);
  if (!chunk || !shot.line) return null;
  const color = TL.cast[shot.line.by]?.color ?? "#ffffff";
  const enter = spring({ frame: local - chunk.from, fps, config: { damping: 12, stiffness: 220, mass: 0.6 } });
  return (
    <div style={{ position: "absolute", left: 70, width: width - 140, top: 1150, display: "flex", justifyContent: "center", flexWrap: "wrap", gap: "0 30px", transform: `scale(${0.7 + 0.3 * enter})` }}>
      {chunk.words.map((w, i) => {
        const active = local >= shot.line!.at + w.start && local < shot.line!.at + w.end + 2;
        const pop = spring({ frame: local - (shot.line!.at + w.start), fps, config: { damping: 10, stiffness: 260, mass: 0.5 } });
        const said = local >= shot.line!.at + w.start;
        return (
          <span
            key={i}
            style={{
              fontFamily,
              fontSize: 104,
              lineHeight: 1.12,
              color: active ? color : said ? "#ffffff" : "rgba(255,255,255,0.92)",
              WebkitTextStroke: "16px #16131f",
              paintOrder: "stroke fill",
              textShadow: "0 8px 0 rgba(0,0,0,0.35)",
              display: "inline-block",
              transform: `scale(${active ? 1 + 0.08 * pop : 1}) rotate(${active ? -2 : 0}deg)`,
              letterSpacing: 1,
            }}
          >
            {w.text.toLowerCase()}
          </span>
        );
      })}
    </div>
  );
};
