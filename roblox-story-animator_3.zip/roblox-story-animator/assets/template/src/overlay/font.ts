import { continueRender, delayRender, staticFile } from "remotion";

// Fonte das legendas empacotada em public/fonts (Lilita One, SIL OFL — ver public/fonts/OFL.txt).
// Local = o render não depende de internet nem do Google Fonts.
export const fontFamily = "LilitaOneLocal";

// document.fonts.check() devolve true para famílias desconhecidas, então carregamos sempre (uma vez por aba).
const w = typeof window !== "undefined" ? (window as unknown as { __lilitaLoaded?: boolean }) : null;
if (w && !w.__lilitaLoaded) {
  w.__lilitaLoaded = true;
  const handle = delayRender("Carregando fonte local Lilita One");
  const faces = [
    new FontFace(fontFamily, `url(${staticFile("fonts/LilitaOne-latin.woff2")}) format("woff2")`, { unicodeRange: "U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD" }),
    new FontFace(fontFamily, `url(${staticFile("fonts/LilitaOne-latin-ext.woff2")}) format("woff2")`, { unicodeRange: "U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF" }),
  ];
  Promise.all(faces.map((f) => f.load()))
    .then((loaded) => {
      loaded.forEach((f) => document.fonts.add(f));
      continueRender(handle);
    })
    .catch((err) => {
      console.error("fonte local falhou, usando fallback", err);
      continueRender(handle);
    });
}
