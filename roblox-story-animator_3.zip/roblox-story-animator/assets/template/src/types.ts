// Contrato de dados do Roblox Story Animator.
// story.json (escrito na Fase 1) -> scripts/build_timeline.py -> src/data/timeline.json (frames resolvidos).
// Os componentes só leem timeline.json: tudo aqui está em FRAMES, já resolvido a partir da voz real.

export type Vec3 = [number, number, number];

export type Pose =
  | "idle" | "talk" | "walk" | "run" | "point" | "wave" | "cheer" | "shrug" | "facepalm" | "cry"
  | "scared" | "think" | "sit" | "lie" | "fall" | "jump" | "lookup" | "angry" | "dance" | "sneak"
  | "climb" | "laugh" | "dizzy" | "hands_hips" | "reach" | "bow" | "punch" | "kick" | "power" | "land" | "carry";

export type Expr =
  | "neutral" | "happy" | "laugh" | "smug" | "shock" | "scared" | "angry" | "sad" | "cry" | "sleepy"
  | "confused" | "determined" | "love" | "evil" | "dizzy" | "wink" | "disgust" | "starstruck";

export type HatKind = "none" | "cap" | "wide" | "beanie" | "tophat" | "crown" | "party" | "flower";
export type HairKind = "none" | "short" | "long" | "spiky" | "bun" | "pigtails" | "curly" | "buzz" | "bob" | "afro" | "ponytail" | "side";

export type Look = {
  skin?: string;
  shirt: string;
  shirtStripe?: string;
  sleeves?: boolean;
  pants: string;
  shoes?: string;
  hat?: HatKind;
  hatColor?: string;
  hair?: HairKind;
  hairColor?: string;
  glasses?: boolean;
  accessory?: "none" | "backpack" | "cape" | "bow";
  accessoryColor?: string;
  /** Escala do corpo (criança ~0.8, adulto 1, gigante 1.6). */
  scale?: number;
  /** Roupa com estampa (PNG em public/, no molde assets/moldes): camisa = tronco + braços; calça = pernas. */
  shirtTexture?: string;
  pantsTexture?: string;
  /** Acessórios .glb importados (cabelo, chapéu, óculos, mochila, relógio, arma...). */
  accessories?: AccessorySpec[];
};

/** Personagem a partir de .glb com esqueleto (ver RiggedCharacter.tsx e characters/gojo.json). */
export type RigSpec = {
  src: string;
  /** altura final em u (boneco padrão = 5,25) */
  height?: number;
  /** giro em graus para o modelo olhar para +z */
  facing?: number;
  /** esconde triângulos cuja textura cai nestas áreas do atlas [x,y,w,h] em px (ex.: a venda do Gojo) */
  hideUV?: [number, number, number, number][];
  /** rosto pintado na textura: região [x,y,w,h] (px do atlas) redesenhada a cada frame */
  face?: {
    region: [number, number, number, number]; skin: string; eyes: [number, number, number, number];
    eyeScale?: number; eyeY?: number; mouthY?: number;
    /** região do rosto armazenada de cabeça para baixo no atlas (comum em exportações) */
    flipY?: boolean;
  };
};

export type CastMember = {
  name: string;
  voice: string;
  rate?: string;
  pitch?: string;
  eleven_voice?: string;
  /** Cor da legenda quando este personagem fala. */
  color?: string;
  look?: Look;
  /** se presente, o personagem é o modelo .glb animado (no lugar do boneco de blocos) */
  rig?: RigSpec;
};

export type Gaze = "camera" | "front" | "up" | "down" | "left" | "right";

/** Mudança de estado de um ator num frame local do plano. */
export type ActorKey = { at: number; pose?: Pose; expr?: Expr; face?: number; gaze?: Gaze };

export type ShotActor = {
  id: string;
  x: number;
  z: number;
  y?: number;
  /** Direção em graus: 0 = olhando para +z (para a câmera padrão), 90 = para +x. */
  face: number;
  pose: Pose;
  expr: Expr;
  gaze?: Gaze;
  /** Deslocamento durante o plano: posição final e janela [moveFrom, moveTo) em frames locais. */
  to?: [number, number];
  moveFrom?: number;
  moveTo?: number;
  keys: ActorKey[];
};

export type CamType =
  | "extreme_close" | "close" | "medium" | "full" | "wide" | "establishing" | "low" | "high"
  | "ots" | "two" | "pov_up" | "top";

export type CamMove = "hold" | "push" | "pull" | "orbit" | "pan" | "shake" | "punch" | "crash" | "tilt_up" | "dolly";

export type CameraSpec = {
  type: CamType;
  /** Ator enquadrado. */
  on?: string;
  /** Para "ots"/"two": o outro ator. */
  from?: string;
  /** Azimute extra em graus em relação à frente do ator (0 = de frente, 90 = perfil). */
  angle?: number;
  move?: CamMove;
  /** Rolagem (dutch angle) em graus. */
  dutch?: number;
  /** Intensidade extra de tremor 0-1. */
  shake?: number;
};

export type Cut = { at: number; camera: CameraSpec };
/** file = caminho em public/ já resolvido (variação sorteada) pelo build_timeline. */
export type SfxCue = { name: string; at: number; volume: number; file?: string };
export type Word = { text: string; start: number; end: number };

export type Line = {
  by: string;
  text: string;
  voKey: string;
  /** Frame local em que a voz começa. */
  at: number;
  frames: number;
  words: Word[];
  hasAudio: boolean;
};

export type SetName = "street" | "bedroom" | "rooftop" | "park" | "classroom" | "livingroom" | "void" | "hospital";
export type FxType = "dust" | "sparkle" | "confetti" | "energy_purple" | "energy_blue" | "impact" | "speedlines" | "smoke" | "hearts" | "stars";
/** Efeito/partícula num intervalo de frames locais; "on" = ator (posição acompanha o ator), ou pos fixa. */
export type FxSpec = { type: FxType; at: number; until: number; seed: number; on?: string; pos?: Vec3; color?: string; size?: number; count?: number };
export type TimeOfDay = "day" | "sunset" | "night";
export type Mood = "calm" | "funny" | "tension" | "sad" | "epic" | "mystery";

/** Modelo 3D importado (public/models/*.glb). license é obrigatório: own | CC0 | CC-BY:<autor> | permission:<quem>. */
/** height: altura final em unidades (boneco = 5,25) — redimensiona e apoia no chão automaticamente. */
export type PropSpec = {
  src: string; x: number; z: number; y?: number; rot?: number; scale?: number; height?: number; license: string;
  /** só malhas cujo nome contém um destes trechos / esconder estas */
  parts?: string[]; hideParts?: string[];
  /** cor multiplicada (ex.: cabelo cinza feito para receber cor) */
  tint?: string;
};

export type AttachPoint = "head" | "back" | "torso" | "handR" | "handL";

/** Acessório .glb preso a um ponto do corpo; acompanha poses, cabeça e "pop" das caretas. */
export type AccessorySpec = {
  src: string; attach: AttachPoint; license: string;
  /** tamanho final em u: altura OU largura (cabeça do boneco: 1,24 de largura, 1,2 de altura; braço: 1 de largura) */
  height?: number; width?: number;
  /** "center" (padrão), "top" (cabelo: topo do modelo no ponto + offset), "base" */
  anchor?: "center" | "top" | "base";
  /** deslocamento local em u e rotação em graus, no referencial do ponto de encaixe */
  offset?: [number, number, number]; rot?: [number, number, number];
  parts?: string[]; hideParts?: string[]; tint?: string;
};

export type Shot = {
  id: string;
  start: number;
  duration: number;
  set: SetName;
  time: TimeOfDay;
  mood: Mood;
  line: Line | null;
  actors: ShotActor[];
  cuts: Cut[];
  sfx: SfxCue[];
  /** Frames locais com flash branco (impacto). */
  flash: number[];
  /** Texto grande opcional na tela (título/onomatopeia). */
  title?: { text: string; at: number; until: number };
  props?: PropSpec[];
  fx?: FxSpec[];
  /** clima: chuva (gotas 3D + escurece), neblina */
  weather?: "clear" | "rain" | "fog";
  /** neblina 0-1 (independente do clima) */
  fog?: number;
  /** nuvens de blocos no céu (padrão: true em cenários abertos de dia/pôr do sol) */
  clouds?: boolean;
  /** som ambiente em loop durante o plano (vento, sala de aula, rua...) */
  ambience?: { file: string; volume: number };
};

export type Timeline = {
  title: string;
  fps: number;
  width: number;
  height: number;
  totalFrames: number;
  hasMusic: boolean;
  cast: Record<string, CastMember>;
  shots: Shot[];
};
