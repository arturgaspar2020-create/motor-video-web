import { ThreeCanvas } from "@remotion/three";
import { AbsoluteFill, useCurrentFrame, useVideoConfig } from "remotion";
import { Soundtrack } from "./audio/Soundtrack";
import { resolveActor } from "./character/actorState";
import { BlockyCharacter } from "./character/BlockyCharacter";
import { RiggedCharacter } from "./character/RiggedCharacter";
import { Captions } from "./overlay/Captions";
import { Flash, SpeedLines, TitleCard, Vignette } from "./overlay/Effects";
import { FxLayer } from "./world/Fx";
import { mouthOpen, shotAt, TL } from "./timeline";
import { isIndoor, RAIN_SKY, SetView, SKY, TimeLighting } from "./world/Sets";
import { ModelProp } from "./world/ModelProp";
import { ApplyCamera, cameraPose } from "./world/ShotCamera";

// Um único canvas 3D: a cada frame descobre o plano ativo e monta cenário + elenco + câmera.
// Por cima: legendas, título, flash e vinheta. Tudo derivado do frame (determinístico).

export const Main: React.FC = () => {
  const frame = useCurrentFrame();
  const { width, height } = useVideoConfig();
  const { shot, local } = shotAt(frame);
  const actors = Object.fromEntries(
    shot.actors.map((a) => [a.id, { frame: resolveActor(shot, a, local), scale: TL.cast[a.id]?.look?.scale ?? 1 }]),
  );
  const pose = cameraPose(shot, local, actors);
  const rain = shot.weather === "rain";
  const sky = (rain ? RAIN_SKY : SKY)[shot.time];
  // neblina: 0..1 (clima "fog" = 0,6; chuva = 0,35). Cor = horizonte do céu.
  const fogK = shot.fog ?? (shot.weather === "fog" ? 0.6 : rain ? 0.35 : 0);
  const fogNear = 6 + (1 - fogK) * 60;
  const fogFar = fogNear + 18 + (1 - fogK) * 260;
  const pos = Object.fromEntries(
    shot.actors.map((a) => [a.id, { x: actors[a.id].frame.x, y: actors[a.id].frame.y, z: actors[a.id].frame.z, face: (actors[a.id].frame.faceRad * 180) / Math.PI, scale: actors[a.id].scale }]),
  );
  return (
    <AbsoluteFill style={{ backgroundColor: sky[2] }}>
      <AbsoluteFill style={{ background: `linear-gradient(180deg, ${sky[0]} 0%, ${sky[1]} 55%, ${sky[2]} 100%)` }} />
      <ThreeCanvas width={width} height={height} gl={{ antialias: true }} shadows="percentage" flat camera={{ fov: 40, near: 0.1, far: 900, position: [0, 5, 20] }}>
        <ApplyCamera pose={pose} />
        {fogK > 0 ? <fog attach="fog" args={[sky[2], fogNear, fogFar]} /> : null}
        <TimeLighting time={shot.time} indoor={isIndoor(shot.set)} />
        <SetView set={shot.set} time={shot.time} t={frame} weather={shot.weather} clouds={shot.clouds} />
        <FxLayer shot={shot} local={local} actors={pos} cam={pose.position} />
        {(shot.props ?? []).map((p, i) => (
          <ModelProp key={`${shot.id}-${i}-${p.src}`} spec={p} />
        ))}
        {shot.actors.map((a) => {
          const member = TL.cast[a.id];
          // personagem com modelo próprio (ex.: Gojo) -> .glb animado; senão, boneco de blocos
          return member?.rig ? (
            <RiggedCharacter key={a.id} member={member} rig={member.rig} state={actors[a.id].frame} mouth={mouthOpen(shot, a.id, local)} t={frame} />
          ) : (
            <BlockyCharacter key={a.id} member={member} state={actors[a.id].frame} mouth={mouthOpen(shot, a.id, local)} t={frame} />
          );
        })}
      </ThreeCanvas>
      {fogK > 0 ? <AbsoluteFill style={{ background: sky[2], opacity: fogK * 0.18, pointerEvents: "none" }} /> : null}
      <SpeedLines />
      <Vignette />
      <TitleCard />
      <Captions />
      <Flash />
      <Soundtrack />
    </AbsoluteFill>
  );
};
