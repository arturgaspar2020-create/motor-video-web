import { BoxGeometry } from "three";

// Roupas com estampa para o boneco de blocos. Moldes (assets/moldes/): camisa 1024×1024 (tronco + braços)
// e calça 1024×512 (pernas). 128 px = 1 unidade. Cada face é pintada "em pé" (topo da área = cima do corpo);
// no topo da peça, o lado de cima da imagem é as COSTAS; na base (baixo/mão/sola), é a FRENTE.
// DIR./ESQ. são do personagem: o braço DIR. fica em −x (personagem olhando para +z).

export type Rect = [number, number, number, number];
type Faces = { px: Rect; nx: Rect; py: Rect; ny: Rect; pz: Rect; nz: Rect };

export const SHIRT_SIZE: [number, number] = [1024, 1024];
export const PANTS_SIZE: [number, number] = [1024, 512];

export const SHIRT = {
  torso: { pz: [128, 128, 256, 256], nz: [512, 128, 256, 256], nx: [0, 128, 128, 256], px: [384, 128, 128, 256], py: [128, 0, 256, 128], ny: [128, 384, 256, 128] } as Faces,
  armR: { nx: [0, 640, 128, 256], pz: [128, 640, 128, 256], px: [256, 640, 128, 256], nz: [384, 640, 128, 256], py: [128, 512, 128, 128], ny: [128, 896, 128, 128] } as Faces,
  armL: { nx: [512, 640, 128, 256], pz: [640, 640, 128, 256], px: [768, 640, 128, 256], nz: [896, 640, 128, 256], py: [640, 512, 128, 128], ny: [640, 896, 128, 128] } as Faces,
};
export const PANTS = {
  legR: { nx: [0, 128, 128, 256], pz: [128, 128, 128, 256], px: [256, 128, 128, 256], nz: [384, 128, 128, 256], py: [128, 0, 128, 128], ny: [128, 384, 128, 128] } as Faces,
  legL: { nx: [512, 128, 128, 256], pz: [640, 128, 128, 256], px: [768, 128, 128, 256], nz: [896, 128, 128, 256], py: [640, 0, 128, 128], ny: [640, 384, 128, 128] } as Faces,
};

/** Caixa com UV de cada face apontando para a área certa do molde. */
export const clothBox = (size: [number, number, number], faces: Faces, img: [number, number]) => {
  const g = new BoxGeometry(...size);
  const [hw, hh, hd] = size.map((v) => v / 2);
  const pos = g.getAttribute("position");
  const nor = g.getAttribute("normal");
  const uv = g.getAttribute("uv");
  const [W, H] = img;
  for (let i = 0; i < pos.count; i++) {
    const x = pos.getX(i), y = pos.getY(i), z = pos.getZ(i);
    const nx = nor.getX(i), ny = nor.getY(i), nz = nor.getZ(i);
    let r: Rect, u: number, v: number; // u: 0 esquerda→1 direita; v: 0 baixo→1 cima (como se vê a face)
    if (nz > 0.5) { r = faces.pz; u = (x + hw) / (2 * hw); v = (y + hh) / (2 * hh); }
    else if (nz < -0.5) { r = faces.nz; u = (hw - x) / (2 * hw); v = (y + hh) / (2 * hh); }
    else if (nx > 0.5) { r = faces.px; u = (hd - z) / (2 * hd); v = (y + hh) / (2 * hh); }
    else if (nx < -0.5) { r = faces.nx; u = (z + hd) / (2 * hd); v = (y + hh) / (2 * hh); }
    else if (ny > 0.5) { r = faces.py; u = (x + hw) / (2 * hw); v = (hd - z) / (2 * hd); }
    else { r = faces.ny; u = (x + hw) / (2 * hw); v = (z + hd) / (2 * hd); }
    const [rx, ry, rw, rh] = r;
    // imagem: y cresce para baixo; textura (flipY): v=1 é o topo da imagem
    uv.setXY(i, (rx + u * rw) / W, 1 - (ry + (1 - v) * rh) / H);
  }
  uv.needsUpdate = true;
  return g;
};
