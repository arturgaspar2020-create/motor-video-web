import { useThree } from "@react-three/fiber";
import { useEffect, useMemo, useState } from "react";
import { cancelRender, continueRender, delayRender } from "remotion";
import { Bone, Box3, CanvasTexture, Euler, Matrix4, Mesh, MeshStandardMaterial, Object3D, Quaternion, SRGBColorSpace, Vector3, type Group, type Texture } from "three";
import { clone as cloneSkinned } from "three/examples/jsm/utils/SkeletonUtils.js";
import type { CastMember, RigSpec } from "../types";
import { loadGlb } from "../world/GlbModel";
import type { ActorFrame } from "./actorState";
import { drawFace, FACE_H, FACE_W } from "./faceDraw";

// Personagem a partir de um .glb COM ESQUELETO no padrão Roblox (R6/R15 de GFX: Lower/Upper Torso,
// Head, Left/Right Upper/Lower Arm, Left/Right Upper/Lower Leg). As poses do motor (poses.ts) giram os
// ossos; o rosto pintado na textura é redesenhado a cada frame (olhos originais + caretas + boca da voz).
// Malhas soltas (rosto, cabelo) são presas ao osso da cabeça. Ver characters/gojo.json ("rig").

type Loaded = { scene: Group; tex: Texture | null };
const cache = new Map<string, Promise<Loaded>>();
const load = (src: string) => {
  if (!cache.has(src)) {
    cache.set(
      src,
      loadGlb(src).then((scene) => {
        let tex: Texture | null = null;
        scene.traverse((o) => {
          const m = (o as Mesh).material as MeshStandardMaterial | undefined;
          if (!tex && m?.map) tex = m.map;
        });
        return { scene, tex };
      }),
    );
  }
  return cache.get(src)!;
};

const key = (s: string) => s.toLowerCase().replace(/[^a-z]/g, "");
const BONES = ["uppertorso", "head", "leftupperarm", "rightupperarm", "leftupperleg", "rightupperleg"] as const;
type BoneKey = (typeof BONES)[number];

type Rig = {
  root: Object3D;
  fit: number;
  lift: number;
  bones: Partial<Record<BoneKey, { bone: Bone; q0: Quaternion; qp: Quaternion; p0: Vector3; pivot: Vector3 | null }>>;
  /** braço/perna que fica do lado direito DO PERSONAGEM (−x quando ele olha para +z) */
  armR: BoneKey; armL: BoneKey; legR: BoneKey; legL: BoneKey;
  faceCanvas: HTMLCanvasElement | null;
  faceTex: CanvasTexture | null;
  atlas: HTMLImageElement | ImageBitmap | HTMLCanvasElement | null;
  /** recorte dos olhos já na orientação de exibição (desvirado se flipY) */
  eyes: HTMLCanvasElement | null;
};

const qFace = (deg: number) => new Quaternion().setFromAxisAngle(new Vector3(0, 1, 0), (deg * Math.PI) / 180);

export const RiggedCharacter: React.FC<{ member: CastMember; rig: RigSpec; state: ActorFrame; mouth: number; t: number }> = ({ rig, state, mouth, t }) => {
  const advance = useThree((s) => s.advance);
  const [model, setModel] = useState<Rig | null>(null);
  const [handle] = useState(() => delayRender(`Carregando personagem ${rig.src}`));

  useEffect(() => {
    load(rig.src)
      .then(({ scene, tex }) => {
        const root = cloneSkinned(scene) as Object3D;
        const F = qFace(rig.facing ?? 0); // gira o modelo para olhar para +z
        root.quaternion.copy(F);
        root.updateMatrixWorld(true);
        // ossos por nome (o GLTFLoader troca espaços por "_")
        const found: Partial<Record<BoneKey, Bone>> = {};
        root.traverse((o) => {
          if (!(o as Bone).isBone) return;
          const k = key(o.name);
          for (const b of BONES) if (k === b && !found[b]) found[b] = o as Bone;
        });
        // prende malhas soltas (rosto/cabelo) ao osso da cabeça, preservando a posição
        const head = found.head;
        const loose: Object3D[] = [];
        root.traverse((o) => {
          if ((o as Mesh).isMesh && !(o as unknown as { isSkinnedMesh?: boolean }).isSkinnedMesh) loose.push(o);
        });
        if (head) loose.forEach((o) => head.attach(o));
        // esconde partes pelo lugar na textura (ex.: venda): remove triângulos com UV dentro das áreas
        if (rig.hideUV?.length && tex?.image) {
          const W = (tex.image as { width: number }).width;
          const H = (tex.image as { height: number }).height;
          root.traverse((o) => {
            const mesh = o as Mesh;
            if (!mesh.isMesh || !mesh.geometry.getAttribute("uv")) return;
            const g = mesh.geometry.clone();
            const uv = g.getAttribute("uv");
            const idx = g.getIndex();
            const n = idx ? idx.count : uv.count;
            const keep: number[] = [];
            for (let i = 0; i < n; i += 3) {
              const a = [0, 1, 2].map((k) => (idx ? idx.getX(i + k) : i + k));
              const u = (a.reduce((acc, v) => acc + uv.getX(v), 0) / 3) * W;
              const v = (a.reduce((acc, vv) => acc + uv.getY(vv), 0) / 3) * H;
              const hidden = rig.hideUV!.some(([x, y, w, h]) => u >= x && u <= x + w && v >= y && v <= y + h);
              if (!hidden) keep.push(...a);
            }
            if (keep.length !== n) {
              g.setIndex(keep);
              mesh.geometry = g;
            }
          });
        }
        // volta da pose de "GFX" para a pose-base do esqueleto (malha como foi modelada: braços e pernas
        // retos) e depois corrige só a orientação geral, que no arquivo vem "deitada" (eixos Z-up).
        root.traverse((o) => {
          const sk = (o as unknown as { skeleton?: { pose: () => void } }).skeleton;
          if (sk) sk.pose();
        });
        root.updateMatrixWorld(true);
        const all: Record<string, Bone> = {};
        root.traverse((o) => {
          if ((o as Bone).isBone) all[key(o.name)] = all[key(o.name)] ?? (o as Bone);
        });
        const top = all.main ?? all.lowertorso;
        const P = (k: string) => (all[k] ? all[k].getWorldPosition(new Vector3()) : new Vector3());
        if (top && all.head && all.leftupperarm && all.rightupperarm) {
          const up = P("head").sub(P("lowertorso").lengthSq() ? P("lowertorso") : P("main")).normalize();
          const side = P("rightupperarm").sub(P("leftupperarm")).normalize();
          const fwd = new Vector3().crossVectors(side, up).normalize();
          const sideO = new Vector3().crossVectors(up, fwd).normalize();
          // base atual (sideO, up, fwd) -> base desejada (X, Y, Z) no referencial do personagem (com F)
          const cur = new Quaternion().setFromRotationMatrix(new Matrix4().makeBasis(sideO, up, fwd));
          const want = F.clone();
          const R = want.multiply(cur.invert()); // rotação de mundo a aplicar
          const qp = top.parent!.getWorldQuaternion(new Quaternion());
          top.quaternion.premultiply(qp.clone().invert().multiply(R).multiply(qp));
          root.updateMatrixWorld(true);
        }
        // a malha veio modelada na pose de GFX: mede o eixo comprido de cada braço/perna (pela geometria)
        // e gira o osso superior até esse eixo apontar para baixo, do ombro/quadril para a ponta.
        const Finv = F.clone().invert();
        /** pontos da malha já deformados pelos ossos, em coordenadas de mundo */
        const worldPts = (mesh: Mesh) => {
          root.updateMatrixWorld(true);
          const pos = mesh.geometry.getAttribute("position");
          const pts: Vector3[] = [];
          const step = Math.max(1, Math.floor(pos.count / 400));
          const sk = mesh as unknown as { isSkinnedMesh?: boolean; applyBoneTransform?: (i: number, v: Vector3) => Vector3 };
          for (let i = 0; i < pos.count; i += step) {
            const v = new Vector3().fromBufferAttribute(pos, i);
            if (sk.isSkinnedMesh && sk.applyBoneTransform) sk.applyBoneTransform(i, v); // posição deformada pelos ossos
            pts.push(v.applyMatrix4(mesh.matrixWorld));
          }
          return pts;
        };
        /** caixa da malha no referencial do personagem */
        const charBox = (mesh: Mesh) => new Box3().setFromPoints(worldPts(mesh).map((v) => v.clone().applyQuaternion(Finv)));
        const limbAxis = (mesh: Mesh, pivot: Vector3) => {
          const pts = worldPts(mesh);
          const c = pts.reduce((a, v) => a.add(v), new Vector3()).divideScalar(pts.length);
          // eixo principal por iteração de potência na covariância
          let ax = new Vector3(1, 0.3, 0.2).normalize();
          for (let it = 0; it < 30; it++) {
            const acc = new Vector3();
            for (const v of pts) {
              const d = v.clone().sub(c);
              acc.add(d.multiplyScalar(d.dot(ax)));
            }
            ax = acc.normalize();
          }
          // sentido: do lado mais perto do pivô (ombro/quadril) para a ponta
          if (pivot.clone().sub(c).dot(ax) > 0) ax.negate();
          return ax.applyQuaternion(Finv); // referencial do personagem
        };
        // a malha de cada membro = a que tem mais peso de pele no osso superior + inferior daquele membro
        const meshOf = (boneKeys: string[]) => {
          let best: Mesh | null = null;
          let bestW = 0;
          root.traverse((o) => {
            const sm = o as unknown as { isSkinnedMesh?: boolean; skeleton?: { bones: Bone[] }; geometry: Mesh["geometry"] };
            if (!sm.isSkinnedMesh || !sm.skeleton) return;
            const want = new Set(sm.skeleton.bones.map((b, i) => (boneKeys.includes(key(b.name)) ? i : -1)).filter((i) => i >= 0));
            const si = sm.geometry.getAttribute("skinIndex");
            const sw = sm.geometry.getAttribute("skinWeight");
            if (!si || !sw) return;
            let w = 0;
            let tot = 0;
            for (let i = 0; i < si.count; i++) {
              for (let c = 0; c < 4; c++) {
                const wt = sw.getComponent(i, c);
                tot += wt;
                if (want.has(si.getComponent(i, c))) w += wt;
              }
            }
            const share = tot ? w / tot : 0;
            if (share > bestW) {
              bestW = share;
              best = o as Mesh;
            }
          });
          return bestW > 0.6 ? best : null;
        };
        const DOWN = new Vector3(0, -1, 0);
        for (const [frag, boneK] of [["leftlowerarm", "leftupperarm"], ["rightlowerarm", "rightupperarm"], ["leftlowerleg", "leftupperleg"], ["rightlowerleg", "rightupperleg"]] as const) {
          const mesh = meshOf([frag, boneK]);
          const bone = all[boneK];
          if (!mesh || !bone) continue;
          root.updateMatrixWorld(true);
          const axis = limbAxis(mesh, bone.getWorldPosition(new Vector3()));
          const R = new Quaternion().setFromUnitVectors(axis, DOWN);
          const qp = bone.parent!.getWorldQuaternion(new Quaternion()).premultiply(Finv);
          bone.quaternion.premultiply(qp.clone().invert().multiply(R).multiply(qp));
        }
        root.updateMatrixWorld(true);
        // o pivô do osso nem sempre fica na ponta da malha: encosta cada braço no ombro (topo do braço na
        // altura do topo do tronco, face interna colada na lateral) e cada perna embaixo do tronco.
        const torso = meshOf(["lowertorso", "uppertorso"]);
        if (torso) {
          const tb = charBox(torso);
          const moveBone = (bone: Bone, dChar: Vector3) => {
            const p1 = bone.getWorldPosition(new Vector3());
            const p2 = p1.clone().add(dChar.clone().applyQuaternion(F));
            const parent = bone.parent!;
            bone.position.add(parent.worldToLocal(p2.clone()).sub(parent.worldToLocal(p1.clone())));
            root.updateMatrixWorld(true);
          };
          for (const [frag, boneK, isArm] of [["leftlowerarm", "leftupperarm", true], ["rightlowerarm", "rightupperarm", true], ["leftlowerleg", "leftupperleg", false], ["rightlowerleg", "rightupperleg", false]] as const) {
            const mesh = meshOf([frag, boneK]);
            const bone = all[boneK];
            if (!mesh || !bone) continue;
            const b = charBox(mesh);
            const c = b.getCenter(new Vector3());
            const half = (b.max.x - b.min.x) / 2;
            const sideSign = c.x < (tb.min.x + tb.max.x) / 2 ? -1 : 1;
            const d = new Vector3();
            if (isArm) {
              d.y = tb.max.y - b.max.y;
              d.x = sideSign < 0 ? tb.min.x - half - c.x : tb.max.x + half - c.x;
              d.z = (tb.min.z + tb.max.z) / 2 - c.z;
            } else {
              d.y = tb.min.y - b.max.y;
              d.z = (tb.min.z + tb.max.z) / 2 - c.z;
            }
            if (d.length() > 0.001) moveBone(bone, d);
          }
        }
        root.traverse((o) => {
          if ((o as Mesh).isMesh) {
            o.castShadow = true;
            o.receiveShadow = true;
            o.frustumCulled = false;
          }
        });
        // pivôs de giro (ombro/quadril) medidos na malha final, guardados no espaço do pai do osso
        const pivots: Partial<Record<BoneKey, Vector3>> = {};
        for (const [frag, boneK, isArm] of [["leftlowerarm", "leftupperarm", true], ["rightlowerarm", "rightupperarm", true], ["leftlowerleg", "leftupperleg", false], ["rightlowerleg", "rightupperleg", false]] as const) {
          const mesh = meshOf([frag, boneK]);
          const bone = all[boneK];
          if (!mesh || !bone) continue;
          const b = charBox(mesh);
          const c = b.getCenter(new Vector3());
          const w = b.max.x - b.min.x;
          const P = new Vector3(c.x, isArm ? b.max.y - w / 2 : b.max.y, c.z).applyQuaternion(F);
          pivots[boneK as BoneKey] = bone.parent!.worldToLocal(P);
        }
        // descanso: quaternion local e orientação do pai no referencial do PERSONAGEM (já virado para +z)
        const rootInv = new Quaternion();
        root.getWorldQuaternion(rootInv);
        const bones: Rig["bones"] = {};
        (Object.keys(found) as BoneKey[]).forEach((k) => {
          const bone = found[k]!;
          const qp = new Quaternion();
          bone.parent!.getWorldQuaternion(qp);
          qp.premultiply(rootInv.clone().invert()).premultiply(F); // pai no referencial do personagem
          bones[k] = { bone, q0: bone.quaternion.clone(), qp, p0: bone.position.clone(), pivot: pivots[k] ?? null };
        });
        // lado direito do personagem = x negativo no mundo (personagem olhando para +z)
        const wx = (k: BoneKey) => (found[k] ? found[k]!.getWorldPosition(new Vector3()).x : 0);
        const armR: BoneKey = wx("leftupperarm") < wx("rightupperarm") ? "leftupperarm" : "rightupperarm";
        const legR: BoneKey = wx("leftupperleg") < wx("rightupperleg") ? "leftupperleg" : "rightupperleg";
        // escala pelo CORPO (malhas com esqueleto), sem o cabelo: a cabeça fica na mesma altura do boneco
        // padrão (centro ≈ 4,65 u), então closes e cortes da câmera enquadram o rosto igual.
        const box = new Box3();
        root.traverse((o) => {
          if ((o as unknown as { isSkinnedMesh?: boolean }).isSkinnedMesh) box.union(charBox(o as Mesh));
        });
        if (box.isEmpty()) box.setFromObject(root, true);
        const size = box.getSize(new Vector3());
        const fit = (rig.height ?? 5.25) / (size.y || 1);
        // rosto: copia a textura para um canvas e redesenha a região do rosto a cada frame
        let faceCanvas: HTMLCanvasElement | null = null;
        let faceTex: CanvasTexture | null = null;
        const img = (tex?.image ?? null) as HTMLImageElement | ImageBitmap | null;
        if (rig.face && img) {
          faceCanvas = document.createElement("canvas");
          faceCanvas.width = img.width;
          faceCanvas.height = img.height;
          faceTex = new CanvasTexture(faceCanvas);
          faceTex.colorSpace = SRGBColorSpace;
          faceTex.flipY = tex!.flipY;
          faceTex.wrapS = tex!.wrapS;
          faceTex.wrapT = tex!.wrapT;
          root.traverse((o) => {
            const mesh = o as Mesh;
            if (!mesh.isMesh) return;
            const swap = (m: MeshStandardMaterial) => {
              if (m.map !== tex) return m;
              const c = m.clone();
              c.map = faceTex;
              return c;
            };
            mesh.material = Array.isArray(mesh.material)
              ? (mesh.material as MeshStandardMaterial[]).map(swap)
              : swap(mesh.material as MeshStandardMaterial);
          });
        }
        let eyes: HTMLCanvasElement | null = null;
        if (rig.face && img) {
          const [ex, ey, ew, eh] = rig.face.eyes;
          eyes = document.createElement("canvas");
          eyes.width = ew;
          eyes.height = eh;
          const ec = eyes.getContext("2d")!;
          if (rig.face.flipY) {
            ec.translate(0, eh);
            ec.scale(1, -1);
          }
          ec.drawImage(img as CanvasImageSource, ex, ey, ew, eh, 0, 0, ew, eh);
        }
        setModel({
          root, fit, lift: -box.min.y * fit, bones,
          armR, armL: armR === "leftupperarm" ? "rightupperarm" : "leftupperarm",
          legR, legL: legR === "leftupperleg" ? "rightupperleg" : "leftupperleg",
          faceCanvas, faceTex, atlas: img, eyes,
        });
      })
      .catch((e) => cancelRender(new Error(`Falha ao carregar ${rig.src}: ${e}`)));
  }, [rig.src, rig.facing, rig.height, rig.face]);

  useEffect(() => {
    if (!model) return;
    advance(performance.now());
    continueRender(handle);
  }, [model, advance, handle]);

  // aplica a pose: rotação D definida no referencial do personagem, convertida para o osso
  const tmp = useMemo(() => ({ d: new Quaternion(), e: new Euler(), q: new Quaternion() }), []);
  if (model) {
    const J = state.joints;
    const set = (k: BoneKey, rx: number, ry: number, rz: number) => {
      const b = model.bones[k];
      if (!b) return;
      tmp.d.setFromEuler(tmp.e.set(rx, ry, rz, "XYZ"));
      // Dl = giro no espaço do pai; com pivô: posição = pivô + Dl·(p0 − pivô)
      const Dl = tmp.q.copy(b.qp).invert().multiply(tmp.d).multiply(b.qp);
      if (b.pivot) b.bone.position.copy(b.p0).sub(b.pivot).applyQuaternion(Dl).add(b.pivot);
      b.bone.quaternion.copy(Dl).multiply(b.q0);
    };
    set("uppertorso", J.torsoX, J.torsoY, J.torsoZ);
    set("head", J.headX, J.headY, J.headZ);
    set(model.armR, J.armRx, 0, J.armRz);
    set(model.armL, J.armLx, 0, J.armLz);
    set(model.legR, J.legRx, 0, J.legRz);
    set(model.legL, J.legLx, 0, J.legLz);
    if (model.faceCanvas && model.atlas && rig.face) {
      const c = model.faceCanvas.getContext("2d")!;
      c.drawImage(model.atlas as CanvasImageSource, 0, 0);
      const [fx, fy, fw, fh] = rig.face.region;
      const flip = !!rig.face.flipY;
      // apaga olhos/boca originais com a cor da pele e redesenha com a careta atual
      c.fillStyle = rig.face.skin;
      c.fillRect(fx, fy, fw, fh);
      c.save();
      c.translate(fx, flip ? fy + fh : fy);
      c.scale(fw / FACE_W, (flip ? -fh : fh) / FACE_H);
      drawFace(c, {
        expr: state.expr, mouth, blink: state.blink, gx: 0, gy: 0, since: state.exprSince, t, skin: rig.face.skin,
        eyeImage: { img: model.eyes ?? (model.atlas as CanvasImageSource), src: model.eyes ? [0, 0, rig.face.eyes[2], rig.face.eyes[3]] : rig.face.eyes, scale: rig.face.eyeScale ?? 1 },
        mouthY: rig.face.mouthY, eyeY: rig.face.eyeY,
      });
      c.restore();
      model.faceTex!.needsUpdate = true;
    }
  }

  if (!model) return null;
  const s = model.fit;
  return (
    <group position={[state.x, state.y, state.z]} rotation={[0, state.faceRad, 0]}>
      <group position={[0, state.joints.rootY, 0]} rotation={[state.joints.rootX, 0, state.joints.rootZ]}>
        <group position={[0, model.lift, 0]} scale={s}>
          <primitive object={model.root} />
        </group>
      </group>
    </group>
  );
};

