import type { Pose } from "../types";

// Biblioteca de poses do boneco R6 (blocos). Cada pose é função pura de t (frames desde que começou),
// então qualquer frame pode ser renderizado isolado. Convenções (personagem olhando para +z):
//  - armXx/legXx < 0  -> membro balança para FRENTE (−π/2 = apontando para frente, −π = para cima)
//  - armRz < 0 / armLz > 0 -> braço abre para FORA (R = lado direito do personagem = −x)
//  - headX > 0 -> olha para baixo; < 0 -> olha para cima. torsoX > 0 -> inclina para frente.
//  - rootX: tomba o corpo inteiro (−π/2 = deitado de costas); rootY: sobe/desce o corpo.

export type Joints = {
  rootY: number; rootX: number; rootZ: number;
  torsoX: number; torsoY: number; torsoZ: number;
  headX: number; headY: number; headZ: number;
  armRx: number; armRz: number; armLx: number; armLz: number;
  legRx: number; legRz: number; legLx: number; legLz: number;
};

export const ZERO: Joints = {
  rootY: 0, rootX: 0, rootZ: 0, torsoX: 0, torsoY: 0, torsoZ: 0, headX: 0, headY: 0, headZ: 0,
  armRx: 0, armRz: 0, armLx: 0, armLz: 0, legRx: 0, legRz: 0, legLx: 0, legLz: 0,
};

const PI = Math.PI;
const sin = Math.sin;
const cos = Math.cos;
const clamp01 = (v: number) => Math.min(1, Math.max(0, v));
const easeOutBack = (x: number) => {
  const c1 = 1.70158;
  const c3 = c1 + 1;
  return 1 + c3 * Math.pow(x - 1, 3) + c1 * Math.pow(x - 1, 2);
};

const j = (p: Partial<Joints>): Joints => ({ ...ZERO, ...p });

/** Respiração leve, comum a quase todas as poses (nunca deixe o boneco congelado). */
const breathe = (t: number, s: number) => ({
  torsoX: 0.015 * sin(t * 0.09 + s),
  headX: 0.02 * sin(t * 0.09 + s + 1),
  armRz: -0.05 - 0.02 * sin(t * 0.09 + s),
  armLz: 0.05 + 0.02 * sin(t * 0.09 + s),
});

const POSES: Record<Pose, (t: number, s: number) => Joints> = {
  idle: (t, s) => j({ ...breathe(t, s), headY: 0.06 * sin(t * 0.03 + s) }),
  talk: (t, s) =>
    j({
      ...breathe(t, s),
      armRx: -0.45 - 0.3 * Math.abs(sin(t * 0.16 + s)),
      armRz: -0.15,
      armLx: -0.15 - 0.2 * Math.abs(sin(t * 0.12 + s + 2)),
      headX: 0.05 * sin(t * 0.3 + s),
      headY: 0.1 * sin(t * 0.07 + s),
      torsoY: 0.06 * sin(t * 0.08 + s),
    }),
  walk: (t, s) => {
    const w = sin(t * 0.36 + s);
    return j({ legRx: 0.65 * w, legLx: -0.65 * w, armRx: -0.6 * w, armLx: 0.6 * w, rootY: 0.12 * Math.abs(cos(t * 0.36 + s)), torsoY: 0.05 * w });
  },
  run: (t, s) => {
    const w = sin(t * 0.6 + s);
    return j({ legRx: 1.05 * w, legLx: -1.05 * w, armRx: -1.1 * w, armLx: 1.1 * w, rootY: 0.28 * Math.abs(cos(t * 0.6 + s)), torsoX: 0.22, headX: -0.12 });
  },
  point: (t, s) => {
    const a = easeOutBack(clamp01(t / 7));
    return j({ ...breathe(t, s), armRx: -1.55 * a + 0.04 * sin(t * 0.25), armRz: -0.12 * a, torsoY: -0.12 * a, headY: -0.08 * a });
  },
  wave: (t, s) => {
    const a = clamp01(t / 6);
    return j({ ...breathe(t, s), armRz: -2.7 * a + 0.35 * sin(t * 0.5) * a, armRx: -0.2, headZ: 0.1 * sin(t * 0.25) });
  },
  cheer: (t) => {
    const b = Math.abs(sin(t * 0.32));
    return j({ armRz: -2.75 + 0.25 * sin(t * 0.64), armLz: 2.75 - 0.25 * sin(t * 0.64), rootY: 0.55 * b, legRx: -0.3 * b, legLx: -0.3 * b, headX: -0.15 });
  },
  shrug: (t, s) => {
    const a = easeOutBack(clamp01(t / 8));
    return j({ ...breathe(t, s), armRx: -0.75 * a, armLx: -0.75 * a, armRz: -0.75 * a, armLz: 0.75 * a, headZ: 0.22 * a, rootY: 0.08 * a });
  },
  facepalm: (t) => {
    const a = clamp01(t / 7);
    return j({ armRx: -2.75 * a, armRz: 0.35 * a, headX: 0.32 * a + 0.03 * sin(t * 0.4), torsoX: 0.12 * a, armLz: 0.08 });
  },
  cry: (t) => {
    const a = clamp01(t / 6);
    const sob = 0.05 * sin(t * 1.3);
    return j({ armRx: -2.45 * a, armLx: -2.45 * a, armRz: 0.4 * a, armLz: -0.4 * a, headX: 0.08 * a + sob, torsoX: 0.12 * a + sob, rootY: sob * 0.5 });
  },
  scared: (t) => {
    const a = clamp01(t / 5);
    const tr = 0.035 * sin(t * 2.7);
    return j({ armRx: -1.9 * a, armLx: -1.9 * a, armRz: 0.25 * a, armLz: -0.25 * a, torsoX: -0.2 * a + tr, headX: -0.1 * a + tr, rootY: -0.25 * a, legRz: 0.15 * a, legLz: -0.15 * a, rootZ: tr * 0.5 });
  },
  think: (t, s) => {
    const a = clamp01(t / 8);
    return j({ ...breathe(t, s), armRx: -2.25 * a, armRz: 0.3 * a, armLx: -0.5 * a, armLz: -0.5 * a, headZ: 0.18 * a, headX: -0.12 * a, headY: 0.12 * sin(t * 0.05) });
  },
  sit: (t, s) => j({ ...breathe(t, s), legRx: -PI / 2, legLx: -PI / 2, rootY: -1, armRx: -0.6, armLx: -0.6 }),
  lie: (t) => j({ rootX: -PI / 2, rootY: 0.5, armRz: -0.25, armLz: 0.25, headY: 0.05 * sin(t * 0.05) }),
  fall: (t) => {
    // tomba para trás com aceleração, quica e fica deitado
    const p = clamp01(t / 11);
    const fallA = p * p;
    const bounce = t > 11 ? 0.12 * Math.exp(-(t - 11) * 0.35) * Math.abs(sin((t - 11) * 0.9)) : 0;
    return j({ rootX: (-PI / 2) * fallA, rootY: 0.5 * fallA + bounce, armRz: -1.3 * p, armLz: 1.3 * p, legRx: -0.5 * sin(p * PI), headX: -0.3 * p });
  },
  jump: (t) => {
    // agacha (antecipação) -> sobe com braços para cima -> cai -> amortece; ciclo de 34 frames
    const c = t % 34;
    if (c < 7) {
      const a = Math.sin((c / 7) * (PI / 2));
      return j({ rootY: -0.55 * a, torsoX: 0.3 * a, headX: -0.1 * a, legRx: -0.5 * a, legLx: -0.5 * a, armRx: 0.5 * a, armLx: 0.5 * a });
    }
    if (c < 25) {
      const u = (c - 7) / 18;
      const h = 4 * u * (1 - u);
      const up = 1 - u;
      return j({ rootY: 2.8 * h, torsoX: -0.12 * up, headX: -0.2 * up, legRx: -0.9 * h, legLx: -0.35 * h, armRz: -2.6 * up - 0.4, armLz: 2.6 * up + 0.4, armRx: -0.3 * u, armLx: -0.3 * u });
    }
    const d = 1 - (c - 25) / 9;
    return j({ rootY: -0.6 * d, torsoX: 0.35 * d, legRx: -0.55 * d, legLx: -0.55 * d, armRz: -0.9 * d, armLz: 0.9 * d });
  },
  punch: (t) => {
    // soco de direita: prepara (0-5), golpe (5-8, impacto no frame ~7), segura, volta para a guarda
    const guard = { armRx: -1.25, armLx: -1.45, armRz: 0.35, armLz: -0.4, legRx: 0.25, legLx: -0.3, torsoY: 0.15, rootY: -0.12 };
    if (t < 5) {
      const a = Math.sin((t / 5) * (PI / 2));
      return j({ ...guard, armRx: -1.25 + 1.3 * a, torsoY: 0.15 + 0.4 * a, torsoX: -0.05 * a });
    }
    if (t < 8) {
      const a = (t - 5) / 3;
      return j({ ...guard, armRx: 0.05 - 1.7 * a, armRz: 0.35 - 0.35 * a, torsoY: 0.55 - 1.0 * a, torsoX: 0.2 * a, headX: 0.05 * a, rootY: -0.12 - 0.1 * a });
    }
    if (t < 15) return j({ ...guard, armRx: -1.65, armRz: 0, torsoY: -0.45, torsoX: 0.2, rootY: -0.22, headX: 0.05 });
    const r = Math.min(1, (t - 15) / 8);
    return j({ ...guard, armRx: -1.65 + 0.4 * r, armRz: 0.35 * r, torsoY: -0.45 + 0.6 * r, torsoX: 0.2 - 0.2 * r, rootY: -0.22 + 0.1 * r + 0.04 * sin(t * 0.3) });
  },
  kick: (t) => {
    // chute frontal de direita (impacto no frame ~8)
    if (t < 5) {
      const a = Math.sin((t / 5) * (PI / 2));
      return j({ legRx: 0.45 * a, torsoX: 0.1 * a, armRx: -1.1 * a, armLx: -1.3 * a, rootY: -0.15 * a });
    }
    if (t < 9) {
      const a = (t - 5) / 4;
      return j({ legRx: 0.45 - 2.15 * a, torsoX: 0.1 - 0.45 * a, armRz: -0.9 * a, armLz: 0.9 * a, armRx: -1.1 + 0.8 * a, armLx: -1.3 + 1.0 * a, rootY: -0.15 + 0.25 * a });
    }
    if (t < 15) return j({ legRx: -1.7, torsoX: -0.35, armRz: -0.9, armLz: 0.9, armRx: -0.3, armLx: -0.3, rootY: 0.1 });
    const r = Math.min(1, (t - 15) / 8);
    return j({ legRx: -1.7 * (1 - r), torsoX: -0.35 * (1 - r), armRz: -0.9 * (1 - r) - 0.1, armLz: 0.9 * (1 - r) + 0.1, armRx: -0.3 - 0.9 * r, armLx: -0.3 - 1.1 * r, rootY: 0.1 * (1 - r) });
  },
  power: (t) => {
    // carregando energia: mãos juntas à frente, corpo agachado e tremendo
    const a = clamp01(t / 10);
    const tr = 0.03 * sin(t * 2.3) * a;
    return j({ armRx: -1.45 * a, armLx: -1.45 * a, armRz: 0.45 * a, armLz: -0.45 * a, torsoX: 0.12 * a + tr, rootY: -0.35 * a, legRz: -0.18 * a, legLz: 0.18 * a, headX: 0.08 * a + tr, rootZ: tr });
  },
  land: (t) => {
    // aterrissagem de herói: cai agachado e levanta
    const d = 1 - clamp01((t - 6) / 14);
    return j({ rootY: -1.0 * d, torsoX: 0.55 * d, headX: -0.35 * d, legRx: -1.1 * d, legLx: 0.4 * d, armRz: -1.1 * d, armLz: 0.5 * d, armLx: -1.2 * d });
  },
  carry: (t, s) => j({ ...breathe(t, s), armRx: -1.3, armLx: -1.3, armRz: 0.18, armLz: -0.18, torsoX: -0.06 }),
  lookup: (t, s) => {
    const a = clamp01(t / 10);
    return j({ ...breathe(t, s), headX: -0.65 * a, torsoX: -0.12 * a, armRz: -0.15, armLz: 0.15 });
  },
  angry: (t) => {
    const st = Math.abs(sin(t * 0.45));
    return j({ armRz: -0.35, armLz: 0.35, armRx: -0.25, armLx: -0.25, torsoX: 0.15, headX: 0.12, rootY: 0.06 * st, legRx: -0.35 * st * (sin(t * 0.225) > 0 ? 1 : 0), rootZ: 0.03 * sin(t * 2.2) });
  },
  dance: (t) => {
    const w = sin(t * 0.42);
    return j({ armRz: -1.6 - 0.9 * w, armLz: 1.6 - 0.9 * w, rootZ: 0.12 * w, torsoY: 0.25 * w, headZ: -0.15 * w, rootY: 0.15 * Math.abs(cos(t * 0.42)), legRz: 0.2 * w, legLz: 0.2 * w });
  },
  sneak: (t) => {
    const w = sin(t * 0.2);
    return j({ rootY: -0.35, torsoX: 0.35, legRx: 0.4 * w - 0.3, legLx: -0.4 * w - 0.3, armRx: -1.1, armLx: -1.1, armRz: 0.2, armLz: -0.2, headX: -0.25 });
  },
  climb: (t) => {
    const w = sin(t * 0.3);
    return j({ armRx: -2.6 + 0.5 * w, armLx: -2.6 - 0.5 * w, legRx: -0.6 - 0.6 * Math.max(0, w), legLx: -0.6 - 0.6 * Math.max(0, -w), torsoX: 0.1, rootY: 0.2 * Math.abs(w) });
  },
  laugh: (t) => {
    const h = sin(t * 0.85);
    return j({ armRx: -0.8, armLx: -0.8, armRz: 0.25, armLz: -0.25, torsoX: -0.18 + 0.1 * h, headX: -0.3 + 0.12 * h, rootY: 0.06 * Math.abs(h) });
  },
  dizzy: (t) => j({ headZ: 0.25 * sin(t * 0.25), headX: 0.15 * cos(t * 0.25), rootZ: 0.12 * sin(t * 0.18), torsoZ: 0.08 * sin(t * 0.25), armRz: -0.6 - 0.3 * sin(t * 0.2), armLz: 0.6 - 0.3 * sin(t * 0.2) }),
  hands_hips: (t, s) => j({ ...breathe(t, s), armRx: 0.25, armLx: 0.25, armRz: -0.42, armLz: 0.42, headZ: 0.08, rootZ: 0.03, torsoY: 0.06 * sin(t * 0.05) }),
  reach: (t) => {
    const a = easeOutBack(clamp01(t / 8));
    return j({ armRx: -2.9 * a, armLx: -2.7 * a, torsoX: -0.12 * a, headX: -0.4 * a, rootY: 0.2 * a + 0.05 * sin(t * 0.5) });
  },
  bow: (t) => {
    const a = clamp01(t / 10);
    return j({ torsoX: 0.7 * a, headX: 0.3 * a, armRx: -0.2 * a, armLx: -0.2 * a });
  },
};

export const poseJoints = (pose: Pose, t: number, seed: number): Joints => (POSES[pose] ?? POSES.idle)(Math.max(0, t), seed);

export const mixJoints = (a: Joints, b: Joints, w: number): Joints => {
  const out = { ...a };
  (Object.keys(a) as (keyof Joints)[]).forEach((k) => {
    out[k] = a[k] + (b[k] - a[k]) * w;
  });
  return out;
};

export const ALL_POSES = Object.keys(POSES) as Pose[];
