import { random } from "remotion";
import type { Expr, Gaze, Pose, Shot, ShotActor } from "../types";
import { isSpeaking } from "../timeline";
import { mixJoints, poseJoints, type Joints } from "./poses";

// Estado resolvido de um ator num frame local: posição, rotação, juntas (com blend entre poses),
// expressão (com tempo desde a troca), olhar e piscada. Função pura do frame.

const BLEND = 6; // frames de transição entre poses
const TURN = 7; // frames para girar o corpo

export type ActorFrame = {
  x: number;
  y: number;
  z: number;
  faceRad: number;
  joints: Joints;
  expr: Expr;
  exprSince: number;
  gaze: Gaze;
  blink: number;
  headPop: number;
};

const smooth = (t: number) => {
  const c = Math.min(1, Math.max(0, t));
  return c * c * (3 - 2 * c);
};

const seedOf = (id: string) => Math.floor(random(`actor-${id}`) * 1000);

export const actorPosition = (a: ShotActor, local: number) => {
  if (!a.to) return { x: a.x, z: a.z, moving: false, dir: 0 };
  const from = a.moveFrom ?? 0;
  const to = a.moveTo ?? from + 30;
  const p = Math.min(1, Math.max(0, (local - from) / Math.max(1, to - from)));
  const e = p; // velocidade constante: passos não "patinam"
  const dx = a.to[0] - a.x;
  const dz = a.to[1] - a.z;
  return { x: a.x + dx * e, z: a.z + dz * e, moving: p > 0 && p < 1, dir: (Math.atan2(dx, dz) * 180) / Math.PI };
};

export const resolveActor = (shot: Shot, a: ShotActor, local: number): ActorFrame => {
  const seed = seedOf(a.id);
  const keys = [...a.keys].sort((p, q) => p.at - q.at);

  let pose: Pose = a.pose;
  let poseStart = -1000;
  let prevPose: Pose = a.pose;
  let expr: Expr = a.expr;
  let exprStart = -1000;
  let face = a.face;
  let prevFace = a.face;
  let faceStart = -1000;
  let gaze: Gaze = a.gaze ?? "front";
  for (const k of keys) {
    if (k.at > local) break;
    if (k.pose && k.pose !== pose) {
      prevPose = pose;
      pose = k.pose;
      poseStart = k.at;
    }
    if (k.expr && k.expr !== expr) {
      expr = k.expr;
      exprStart = k.at;
    }
    if (k.face !== undefined && k.face !== face) {
      prevFace = face;
      face = k.face;
      faceStart = k.at;
    }
    if (k.gaze) gaze = k.gaze;
  }

  const pos = actorPosition(a, local);
  // andar/correr automaticamente na direção do movimento
  let effectivePose = pose;
  if (pos.moving && (pose === "idle" || pose === "talk")) effectivePose = "walk";
  if (effectivePose === "idle" && isSpeaking(shot, a.id, local)) effectivePose = "talk";

  let faceDeg = prevFace + (face - prevFace) * smooth((local - faceStart) / TURN);
  if (pos.moving && a.keys.every((k) => k.face === undefined)) faceDeg = pos.dir;

  let joints = poseJoints(effectivePose, poseStart < 0 ? local : local - poseStart, seed);
  const w = smooth((local - poseStart) / BLEND);
  if (w < 1 && poseStart >= 0) joints = mixJoints(poseJoints(prevPose, local - poseStart + 30, seed), joints, w);

  // olhar: gira a cabeça um pouco
  const g = { headX: 0, headY: 0 };
  if (gaze === "up") g.headX = -0.45;
  if (gaze === "down") g.headX = 0.35;
  if (gaze === "left") g.headY = 0.4;
  if (gaze === "right") g.headY = -0.4;
  joints = { ...joints, headX: joints.headX + g.headX, headY: joints.headY + g.headY };

  // piscar: a cada ~3 s, 4 frames, com fase própria por ator
  const period = 84 + (seed % 30);
  const ph = (local + seed) % period;
  const blink = ph < 2 ? ph / 2 : ph < 4 ? 1 - (ph - 2) / 2 : 0;

  const since = local - exprStart;
  const headPop = since >= 0 && since < 10 ? 1 + 0.16 * Math.exp(-since * 0.35) * Math.cos(since * 0.9) : 1;

  return { x: pos.x, y: a.y ?? 0, z: pos.z, faceRad: (faceDeg * Math.PI) / 180, joints, expr, exprSince: Math.max(0, since), gaze, blink, headPop };
};
