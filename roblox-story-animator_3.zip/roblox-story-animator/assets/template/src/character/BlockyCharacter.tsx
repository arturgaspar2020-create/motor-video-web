import { useMemo } from "react";
import { CanvasTexture, LatheGeometry, SRGBColorSpace, Vector2, type Texture } from "three";
import type { AccessorySpec, AttachPoint, CastMember, Look } from "../types";
import { GlbModel } from "../world/GlbModel";
import { useImageTexture } from "../world/useImageTexture";
import { clothBox, PANTS, PANTS_SIZE, SHIRT, SHIRT_SIZE } from "./clothing";
import type { ActorFrame } from "./actorState";
import { drawFace, FACE_H, FACE_W } from "./faceDraw";

// Boneco de blocos original (proporções R6: pernas 2, tronco 2×2×1, braços 1×2×1, cabeça cilíndrica
// arredondada). Não usa malhas, marcas nem avatares da Roblox: tudo é geometria própria do Three.js.
// Altura total ≈ 5,25 u (cabeça centrada em y ≈ 4,65). O rosto é um canvas redesenhado a cada frame.

export const HEAD_Y = 4.65;
const TORSO: [number, number, number] = [2, 2, 1];
const ARM: [number, number, number] = [0.98, 2, 0.98];
const LEG: [number, number, number] = [0.98, 2, 1];
const HEAD_R = 0.62;

const DEFAULT_LOOK: Look = { skin: "#f6d03b", shirt: "#2f7df6", pants: "#2a3550", shoes: "#1d1d1d", hat: "none", hair: "none" };

const headGeometry = (() => {
  const pts: Vector2[] = [];
  const h = 0.6;
  const cr = 0.16;
  pts.push(new Vector2(0, -h));
  for (let i = 0; i <= 6; i++) {
    const a = -Math.PI / 2 + (i / 6) * (Math.PI / 2);
    pts.push(new Vector2(HEAD_R - cr + Math.cos(a) * cr, -h + cr + Math.sin(a) * cr));
  }
  for (let i = 0; i <= 6; i++) {
    const a = (i / 6) * (Math.PI / 2);
    pts.push(new Vector2(HEAD_R - cr + Math.cos(a) * cr, h - cr + Math.sin(a) * cr));
  }
  pts.push(new Vector2(0, h));
  return new LatheGeometry(pts, 40);
})();

const Mat: React.FC<{ color: string; rough?: number }> = ({ color, rough = 0.55 }) => <meshStandardMaterial color={color} roughness={rough} metalness={0.02} />;

const Box: React.FC<{ size: [number, number, number]; pos?: [number, number, number]; color: string; rot?: [number, number, number] }> = ({ size, pos = [0, 0, 0], color, rot }) => (
  <mesh position={pos} rotation={rot} castShadow receiveShadow>
    <boxGeometry args={size} />
    <Mat color={color} />
  </mesh>
);

/** Bloco com estampa (molde) ou cor lisa. */
const ClothBox: React.FC<{ size: [number, number, number]; pos: [number, number, number]; tex: Texture | null; faces: Parameters<typeof clothBox>[1]; img: [number, number]; color: string }> = ({ size, pos, tex, faces, img, color }) => {
  const geo = useMemo(() => (tex ? clothBox(size, faces, img) : null), [tex, size, faces, img]);
  if (!tex || !geo) return <Box size={size} pos={pos} color={color} />;
  return (
    <mesh position={pos} geometry={geo} castShadow receiveShadow>
      <meshStandardMaterial map={tex} roughness={0.75} metalness={0.02} />
    </mesh>
  );
};

const Hat: React.FC<{ look: Look }> = ({ look }) => {
  const c = look.hatColor ?? "#d63a3a";
  switch (look.hat) {
    case "cap":
      return (
        <group position={[0, 0.5, 0]}>
          <mesh castShadow scale={[1, 0.62, 1]}>
            <sphereGeometry args={[0.67, 24, 12, 0, Math.PI * 2, 0, Math.PI / 2]} />
            <Mat color={c} />
          </mesh>
          <Box size={[1.0, 0.07, 0.7]} pos={[0, 0.02, 0.78]} color={c} />
        </group>
      );
    case "wide":
      return (
        <group position={[0, 0.62, 0]} rotation={[0.08, 0, -0.06]}>
          <mesh castShadow>
            <cylinderGeometry args={[1.6, 1.6, 0.08, 40]} />
            <Mat color={c} />
          </mesh>
          <mesh castShadow position={[0, 0.27, 0]}>
            <cylinderGeometry args={[0.58, 0.64, 0.5, 28]} />
            <Mat color={c} />
          </mesh>
          <mesh position={[0, 0.1, 0]}>
            <cylinderGeometry args={[0.65, 0.65, 0.12, 28]} />
            <Mat color="#3b2a1e" />
          </mesh>
        </group>
      );
    case "beanie":
      return (
        <group position={[0, 0.42, 0]}>
          <mesh castShadow scale={[1, 0.85, 1]}>
            <sphereGeometry args={[0.69, 24, 12, 0, Math.PI * 2, 0, Math.PI / 2]} />
            <Mat color={c} />
          </mesh>
          <mesh position={[0, 0.02, 0]}>
            <cylinderGeometry args={[0.7, 0.7, 0.22, 28]} />
            <Mat color={c} rough={0.8} />
          </mesh>
          <mesh position={[0, 0.66, 0]}>
            <sphereGeometry args={[0.16, 12, 8]} />
            <Mat color="#ffffff" />
          </mesh>
        </group>
      );
    case "tophat":
      return (
        <group position={[0, 0.62, 0]}>
          <mesh castShadow>
            <cylinderGeometry args={[0.95, 0.95, 0.06, 32]} />
            <Mat color={c} />
          </mesh>
          <mesh castShadow position={[0, 0.5, 0]}>
            <cylinderGeometry args={[0.55, 0.55, 1.0, 28]} />
            <Mat color={c} />
          </mesh>
        </group>
      );
    case "crown":
      return (
        <group position={[0, 0.7, 0]}>
          <mesh castShadow>
            <cylinderGeometry args={[0.55, 0.55, 0.3, 24, 1, true]} />
            <meshStandardMaterial color="#ffc928" metalness={0.6} roughness={0.3} side={2} />
          </mesh>
          {[0, 1, 2, 3, 4].map((i) => (
            <mesh key={i} position={[Math.sin((i / 5) * Math.PI * 2) * 0.5, 0.3, Math.cos((i / 5) * Math.PI * 2) * 0.5]}>
              <coneGeometry args={[0.12, 0.32, 8]} />
              <meshStandardMaterial color="#ffc928" metalness={0.6} roughness={0.3} />
            </mesh>
          ))}
        </group>
      );
    case "party":
      return (
        <mesh castShadow position={[0.1, 1.1, 0]} rotation={[0, 0, -0.18]}>
          <coneGeometry args={[0.38, 1.0, 20]} />
          <Mat color={c} />
        </mesh>
      );
    case "flower":
      return (
        <group position={[0, 0.58, 0]}>
          {Array.from({ length: 9 }).map((_, i) => {
            const a = -1.1 + (i / 8) * 2.2;
            return (
              <mesh key={i} position={[Math.sin(a) * 0.55, 0.02 + 0.05 * Math.cos(i), Math.cos(a) * 0.38]}>
                <icosahedronGeometry args={[0.17, 0]} />
                <meshStandardMaterial color={i % 3 === 1 ? "#58c24e" : c} flatShading roughness={0.6} />
              </mesh>
            );
          })}
        </group>
      );
    default:
      return null;
  }
};

// Cabelos esculpidos (sem "capacete" de bloco): domo liso + mechas elipsoidais/cones, como os cabelos de malha
// dos avatares. A linha do cabelo na testa fica acima das sobrancelhas para não esconder as caretas.
type V3h = [number, number, number];
const HairMat: React.FC<{ c: string }> = ({ c }) => <meshStandardMaterial color={c} roughness={0.48} metalness={0.04} />;
const Ell: React.FC<{ p: V3h; s: V3h; r?: V3h; c: string; seg?: number }> = ({ p, s, r, c, seg = 20 }) => (
  <mesh position={p} scale={s} rotation={r} castShadow>
    <sphereGeometry args={[1, seg, Math.round(seg * 0.7)]} />
    <HairMat c={c} />
  </mesh>
);
const Dome: React.FC<{ c: string; k?: number }> = ({ c, k = 1 }) => (
  <mesh position={[0, 0.3, -0.06]} rotation={[-0.35, 0, 0]} scale={[0.69 * k, 0.5 * k, 0.72 * k]} castShadow>
    <sphereGeometry args={[1, 36, 18, 0, Math.PI * 2, 0, Math.PI / 2]} />
    <HairMat c={c} />
  </mesh>
);
const BackHair: React.FC<{ c: string; down?: number }> = ({ c, down = 0 }) => <Ell p={[0, 0.06 - down / 2, -0.3]} s={[0.67, 0.56 + down / 2, 0.4]} c={c} />;
const Fringe: React.FC<{ c: string; n?: number; drop?: number }> = ({ c, n = 5, drop = 0 }) => (
  <>
    {Array.from({ length: n }).map((_, i) => {
      const u = n === 1 ? 0 : i / (n - 1) - 0.5;
      const x = u * 1.0;
      return <Ell key={i} p={[x, 0.47 - drop - Math.abs(u) * 0.06, 0.5 - Math.abs(u) * 0.12]} s={[0.17, 0.15, 0.13]} r={[0.5, u * 0.6, -u * 0.9]} c={c} />;
    })}
  </>
);
const Sides: React.FC<{ c: string; len?: number }> = ({ c, len = 0.3 }) => (
  <>
    {[-1, 1].map((d) => (
      <Ell key={d} p={[d * 0.63, 0.32 - len / 2, 0.02]} s={[0.1, len, 0.26]} r={[0.15, 0, d * 0.08]} c={c} />
    ))}
  </>
);

const Hair: React.FC<{ look: Look }> = ({ look }) => {
  const c = look.hairColor ?? "#5a3420";
  switch (look.hair) {
    case "short":
      return (
        <>
          <Dome c={c} />
          <BackHair c={c} />
          <Fringe c={c} />
          <Sides c={c} />
        </>
      );
    case "side":
      return (
        <>
          <Dome c={c} />
          <BackHair c={c} />
          <Ell p={[0.12, 0.5, 0.42]} s={[0.55, 0.16, 0.24]} r={[0.25, 0, -0.28]} c={c} />
          <Ell p={[0.52, 0.36, 0.38]} s={[0.16, 0.2, 0.14]} r={[0.3, 0, -0.5]} c={c} />
          <Sides c={c} len={0.26} />
        </>
      );
    case "buzz":
      return (
        <>
          <mesh position={[0, 0.28, -0.04]} rotation={[-0.3, 0, 0]} scale={[0.645, 0.4, 0.665]}>
            <sphereGeometry args={[1, 36, 18, 0, Math.PI * 2, 0, Math.PI / 2]} />
            <meshStandardMaterial color={c} roughness={0.85} />
          </mesh>
          <Ell p={[0, 0.1, -0.3]} s={[0.635, 0.45, 0.35]} c={c} />
        </>
      );
    case "spiky":
      return (
        <>
          <Dome c={c} />
          <BackHair c={c} />
          {[[-0.42, 0.72, 0.1, 0.5], [0, 0.82, 0.12, 0], [0.42, 0.72, 0.1, -0.5], [-0.25, 0.8, -0.3, 0.3], [0.25, 0.8, -0.3, -0.3], [0, 0.6, -0.6, 0]].map(([x, y, z, rz], i) => (
            <mesh key={i} position={[x, y, z]} rotation={[z < 0 ? -0.9 : 0.25, 0, rz]} castShadow>
              <coneGeometry args={[0.24, 0.62, 12]} />
              <HairMat c={c} />
            </mesh>
          ))}
          {[-0.35, 0, 0.35].map((x, i) => (
            <mesh key={`f${i}`} position={[x, 0.5, 0.52]} rotation={[1.9, 0, -x * 0.8]} castShadow>
              <coneGeometry args={[0.13, 0.36, 10]} />
              <HairMat c={c} />
            </mesh>
          ))}
        </>
      );
    case "curly":
      return (
        <>
          <Dome c={c} />
          <BackHair c={c} />
          {Array.from({ length: 26 }).map((_, i) => {
            const a = (i / 26) * Math.PI * 2 * 3.1;
            const r = 0.25 + (i / 26) * 0.45;
            const z = Math.cos(a) * r - 0.1;
            return <Ell key={i} p={[Math.sin(a) * r, 0.78 - (i / 26) * 0.4 - Math.max(0, -z) * 0.3, Math.min(z, 0.48)]} s={[0.2, 0.2, 0.2]} c={c} seg={10} />;
          })}
        </>
      );
    case "afro":
      return (
        <>
          <Dome c={c} />
          <Ell p={[0, 0.58, -0.3]} s={[0.98, 0.82, 0.92]} c={c} seg={28} />
          {Array.from({ length: 14 }).map((_, i) => {
            const a = (i / 14) * Math.PI * 2;
            return <Ell key={i} p={[Math.sin(a) * 0.9, 0.62 + Math.cos(a * 2) * 0.12, Math.cos(a) * 0.7 - 0.38]} s={[0.26, 0.26, 0.26]} c={c} seg={10} />;
          })}
        </>
      );
    case "bob":
      return (
        <>
          <Dome c={c} />
          <BackHair c={c} down={0.55} />
          {[-1, 1].map((d) => (
            <Ell key={d} p={[d * 0.62, 0.0, -0.05]} s={[0.15, 0.58, 0.42]} r={[0, 0, d * 0.07]} c={c} />
          ))}
          <Fringe c={c} n={6} />
        </>
      );
    case "long":
      return (
        <>
          <Dome c={c} />
          <Ell p={[0, -0.35, -0.42]} s={[0.7, 1.1, 0.3]} r={[-0.12, 0, 0]} c={c} />
          {[-1, 1].map((d) => (
            <Ell key={d} p={[d * 0.6, -0.35, 0.02]} s={[0.15, 0.95, 0.3]} r={[0.05, 0, d * 0.06]} c={c} />
          ))}
          <Fringe c={c} n={4} />
        </>
      );
    case "ponytail":
      return (
        <group position={[0, 0.86, -0.5]}>
          <GlbModel spec={{ src: "models/hair/ponytail.glb", width: 1.8, anchor: "top", tint: c }} />
        </group>
      );
    case "bun":
      return (
        <>
          <Dome c={c} />
          <BackHair c={c} />
          <Fringe c={c} n={4} />
          <Ell p={[0, 0.82, -0.32]} s={[0.36, 0.33, 0.36]} c={c} />
        </>
      );
    case "pigtails":
      return (
        <>
          <Dome c={c} />
          <BackHair c={c} />
          <Fringe c={c} n={5} />
          {[-1, 1].map((d) => (
            <group key={d}>
              <Ell p={[d * 0.78, 0.28, -0.22]} s={[0.12, 0.12, 0.12]} c={look.accessoryColor ?? "#ff4f9a"} />
              <Ell p={[d * 0.92, -0.12, -0.22]} s={[0.24, 0.44, 0.24]} r={[0, 0, d * 0.25]} c={c} />
            </group>
          ))}
        </>
      );
    default:
      return null;
  }
};

// Pontos de encaixe (no referencial do grupo onde o acessório é montado):
// head = centro da cabeça · back = costas · torso = peito · handR/handL = ponta da mão.
const ANCHOR: Record<AttachPoint, [number, number, number]> = {
  head: [0, 0, 0],
  back: [0, 1.0, -0.75],
  torso: [0, 1.1, 0.55],
  handR: [0, -1.55, 0],
  handL: [0, -1.55, 0],
};

const Accessories: React.FC<{ list?: AccessorySpec[]; at: AttachPoint }> = ({ list, at }) => (
  <>
    {(list ?? [])
      .filter((a) => a.attach === at)
      .map((a, i) => {
        const o = a.offset ?? [0, 0, 0];
        const r = (a.rot ?? [0, 0, 0]).map((d) => (d * Math.PI) / 180) as [number, number, number];
        const base = ANCHOR[at];
        return (
          <group key={`${a.src}-${i}`} position={[base[0] + o[0], base[1] + o[1], base[2] + o[2]]} rotation={r}>
            <GlbModel spec={{ src: a.src, height: a.height, width: a.width, anchor: a.anchor ?? "center", parts: a.parts, hideParts: a.hideParts, tint: a.tint }} />
          </group>
        );
      })}
  </>
);

const Face: React.FC<{ state: ActorFrame; mouth: number; t: number; glasses?: boolean }> = ({ state, mouth, t, glasses }) => {
  const { tex, ctx } = useMemo(() => {
    const canvas = document.createElement("canvas");
    canvas.width = FACE_W;
    canvas.height = FACE_H;
    const texture = new CanvasTexture(canvas);
    texture.colorSpace = SRGBColorSpace;
    texture.anisotropy = 4;
    return { tex: texture, ctx: canvas.getContext("2d") as CanvasRenderingContext2D };
  }, []);
  const gx = state.gaze === "left" ? -12 : state.gaze === "right" ? 12 : 0;
  const gy = state.gaze === "up" ? -12 : state.gaze === "down" ? 10 : 0;
  drawFace(ctx, { expr: state.expr, mouth, blink: state.blink, gx, gy, since: state.exprSince, t, glasses });
  tex.needsUpdate = true;
  return (
    <mesh>
      <cylinderGeometry args={[HEAD_R + 0.012, HEAD_R + 0.012, 1.1, 40, 1, true, -1.0, 2.0]} />
      <meshStandardMaterial map={tex} transparent alphaTest={0.03} roughness={0.6} polygonOffset polygonOffsetFactor={-2} />
    </mesh>
  );
};

export const BlockyCharacter: React.FC<{ member?: CastMember; state: ActorFrame; mouth: number; t: number }> = ({ member, state, mouth, t }) => {
  const look = { ...DEFAULT_LOOK, ...(member?.look ?? {}) };
  const skin = look.skin ?? "#f6d03b";
  const armColor = look.sleeves ? look.shirt : skin;
  const J = state.joints;
  const scale = look.scale ?? 1;
  const capeSway = 0.12 + 0.06 * Math.sin(t * 0.15);
  const shirtTex = useImageTexture(look.shirtTexture);
  const pantsTex = useImageTexture(look.pantsTexture);
  return (
    <group position={[state.x, state.y, state.z]} rotation={[0, state.faceRad, 0]} scale={scale}>
      <group position={[0, J.rootY, 0]} rotation={[J.rootX, 0, J.rootZ]}>
        {/* pernas (pivô no quadril) */}
        {([[-0.5, J.legRx, J.legRz], [0.5, J.legLx, J.legLz]] as const).map(([x, rx, rz], i) => (
          <group key={i} position={[x, 2, 0]} rotation={[rx, 0, rz]}>
            <ClothBox size={LEG} pos={[0, -1, 0]} tex={pantsTex} faces={i === 0 ? PANTS.legR : PANTS.legL} img={PANTS_SIZE} color={look.pants} />
            {!pantsTex || member?.look?.shoes ? <Box size={[1.02, 0.28, 1.06]} pos={[0, -1.86, 0.02]} color={look.shoes ?? "#1d1d1d"} /> : null}
          </group>
        ))}
        {/* tronco (pivô no quadril) */}
        <group position={[0, 2, 0]} rotation={[J.torsoX, J.torsoY, J.torsoZ]}>
          <ClothBox size={TORSO} pos={[0, 1, 0]} tex={shirtTex} faces={SHIRT.torso} img={SHIRT_SIZE} color={look.shirt} />
          {look.shirtStripe && !shirtTex ? (
            <>
              <Box size={[2.02, 0.32, 1.02]} pos={[0, 1.35, 0]} color={look.shirtStripe} />
              <Box size={[2.02, 0.32, 1.02]} pos={[0, 0.7, 0]} color={look.shirtStripe} />
            </>
          ) : null}
          {/* braços (pivô no ombro) — R = direita do personagem (−x) */}
          {([[-1.5, J.armRx, J.armRz], [1.5, J.armLx, J.armLz]] as const).map(([x, rx, rz], i) => (
            <group key={i} position={[x, 1.6, 0]} rotation={[rx, 0, rz]}>
              <ClothBox size={ARM} pos={[0, -0.6, 0]} tex={shirtTex} faces={i === 0 ? SHIRT.armR : SHIRT.armL} img={SHIRT_SIZE} color={armColor} />
              {look.sleeves && !shirtTex ? <Box size={[1.0, 0.7, 1.0]} pos={[0, -1.25, 0]} color={skin} /> : null}
              <Accessories list={look.accessories} at={i === 0 ? "handR" : "handL"} />
            </group>
          ))}
          <Accessories list={look.accessories} at="back" />
          <Accessories list={look.accessories} at="torso" />
          {look.accessory === "backpack" ? <Box size={[1.5, 1.6, 0.6]} pos={[0, 1.05, -0.8]} color={look.accessoryColor ?? "#e0533c"} /> : null}
          {look.accessory === "cape" ? <Box size={[1.9, 2.5, 0.08]} pos={[0, 0.6, -0.62]} rot={[capeSway, 0, 0]} color={look.accessoryColor ?? "#b0262f"} /> : null}
          {/* cabeça (pivô no pescoço) */}
          <group position={[0, 2, 0]} rotation={[J.headX, J.headY, J.headZ]} scale={state.headPop}>
            <mesh position={[0, 0.08, 0]}>
              <cylinderGeometry args={[0.32, 0.32, 0.2, 16]} />
              <Mat color={skin} />
            </mesh>
            <group position={[0, HEAD_Y - 4, 0]}>
              <mesh geometry={headGeometry} castShadow receiveShadow>
                <Mat color={skin} rough={0.5} />
              </mesh>
              <Face state={state} mouth={mouth} t={t} glasses={look.glasses} />
              <Hair look={look} />
              <Hat look={look} />
              <Accessories list={look.accessories} at="head" />
              {look.accessory === "bow" ? (
                <group position={[0.45, 0.62, 0]} rotation={[0, 0, 0.3]}>
                  <Box size={[0.36, 0.3, 0.16]} pos={[-0.2, 0, 0]} color={look.accessoryColor ?? "#ff4f9a"} />
                  <Box size={[0.36, 0.3, 0.16]} pos={[0.2, 0, 0]} color={look.accessoryColor ?? "#ff4f9a"} />
                </group>
              ) : null}
            </group>
          </group>
        </group>
      </group>
    </group>
  );
};
