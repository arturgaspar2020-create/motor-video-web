import type { Expr } from "../types";

// Rosto 2D desenhado num canvas e aplicado como decalque curvo na cabeça 3D (como os rostos
// clássicos de bonecos de blocos). Expressões exageradas: olhos, sobrancelhas, boca e extras
// (lágrimas em cascata, suor, veia de raiva, bochecha corada, brilhos). A boca abre com a voz.

export const FACE_W = 512;
export const FACE_H = 450;

type EyeKind = "dot" | "big" | "wide" | "happy" | "closed" | "half" | "wink" | "x" | "spiral" | "heart" | "star" | "sad";
type BrowKind = "none" | "up" | "angry" | "sad" | "worried" | "one" | "flat";
type MouthKind = "smile" | "grin" | "smirk" | "o" | "frown" | "wavy" | "flat" | "teeth" | "evil" | "tongue" | "wail";
type Extra = "stream" | "drops" | "blush" | "sweat" | "vein" | "sparkle" | "drool";

type Spec = { eyes: EyeKind; brows: BrowKind; mouth: MouthKind; extras: Extra[] };

export const EXPRESSIONS: Record<Expr, Spec> = {
  neutral: { eyes: "dot", brows: "none", mouth: "smile", extras: [] },
  happy: { eyes: "big", brows: "up", mouth: "smile", extras: [] },
  laugh: { eyes: "happy", brows: "up", mouth: "grin", extras: ["drops", "blush"] },
  smug: { eyes: "half", brows: "one", mouth: "smirk", extras: [] },
  shock: { eyes: "wide", brows: "up", mouth: "o", extras: ["sweat"] },
  scared: { eyes: "wide", brows: "worried", mouth: "wavy", extras: ["sweat"] },
  angry: { eyes: "dot", brows: "angry", mouth: "teeth", extras: ["vein"] },
  sad: { eyes: "sad", brows: "sad", mouth: "frown", extras: [] },
  cry: { eyes: "closed", brows: "sad", mouth: "wail", extras: ["stream"] },
  sleepy: { eyes: "half", brows: "flat", mouth: "flat", extras: ["drool"] },
  confused: { eyes: "big", brows: "one", mouth: "wavy", extras: [] },
  determined: { eyes: "dot", brows: "angry", mouth: "flat", extras: [] },
  love: { eyes: "heart", brows: "up", mouth: "smile", extras: ["blush"] },
  evil: { eyes: "half", brows: "angry", mouth: "evil", extras: [] },
  dizzy: { eyes: "spiral", brows: "none", mouth: "wavy", extras: [] },
  wink: { eyes: "wink", brows: "up", mouth: "tongue", extras: [] },
  disgust: { eyes: "half", brows: "angry", mouth: "tongue", extras: [] },
  starstruck: { eyes: "star", brows: "up", mouth: "grin", extras: ["sparkle", "blush"] },
};

export type FaceState = {
  expr: Expr;
  /** abertura da boca pela voz 0–1 */
  mouth: number;
  /** piscar 0 (aberto) – 1 (fechado) */
  blink: number;
  /** deslocamento das pupilas em px */
  gx: number;
  gy: number;
  /** frames desde a última troca de expressão (animação de entrada) */
  since: number;
  /** tempo contínuo em frames (lágrimas, suor, pulsos) */
  t: number;
  glasses?: boolean;
  /** olhos vindos de uma imagem (ex.: textura do modelo): recorte [x,y,w,h] com OS DOIS olhos */
  eyeImage?: { img: CanvasImageSource; src: [number, number, number, number]; scale: number };
  /** posições verticais (px no canvas 512×450) para rostos de modelos importados */
  eyeY?: number;
  mouthY?: number;
  /** cor da pele (para pálpebras desenhadas sobre olhos de imagem) */
  skin?: string;
};

const INK = "#141414";
const EX = [-82, 82];
let EY = 178;
const MX = 256;
let MY = 305;

const ell = (c: CanvasRenderingContext2D, x: number, y: number, rx: number, ry: number, rot = 0) => {
  c.beginPath();
  c.ellipse(x, y, Math.max(0.5, rx), Math.max(0.5, ry), rot, 0, Math.PI * 2);
};

const drawEye = (c: CanvasRenderingContext2D, kind: EyeKind, side: number, s: FaceState, pop: number) => {
  const x = MX + EX[side];
  const y = EY;
  const open = 1 - s.blink;
  c.lineCap = "round";
  c.lineJoin = "round";
  c.strokeStyle = INK;
  c.fillStyle = INK;
  const blinkLine = () => {
    c.lineWidth = 12;
    c.beginPath();
    c.moveTo(x - 26, y);
    c.quadraticCurveTo(x, y + 10, x + 26, y);
    c.stroke();
  };
  switch (kind) {
    case "dot":
    case "sad": {
      if (open < 0.25) return blinkLine();
      const dy = kind === "sad" ? 8 : 0;
      ell(c, x + s.gx * 0.4, y + dy + s.gy * 0.4, 21 * pop, 31 * pop * open);
      c.fill();
      c.fillStyle = "#fff";
      ell(c, x + s.gx * 0.4 + 7, y + dy - 12 * open + s.gy * 0.4, 6, 8 * open);
      c.fill();
      if (kind === "sad") {
        c.fillStyle = "rgba(120,190,255,0.95)";
        ell(c, x + 4, y + dy + 20, 10, 6);
        c.fill();
      }
      return;
    }
    case "big":
    case "wide": {
      if (open < 0.25) return blinkLine();
      const rx = (kind === "wide" ? 52 : 40) * pop;
      const ry = (kind === "wide" ? 60 : 47) * pop * open;
      c.fillStyle = "#fff";
      ell(c, x, y, rx, ry);
      c.fill();
      c.lineWidth = 9;
      c.stroke();
      c.fillStyle = INK;
      const pr = kind === "wide" ? 10 : 18;
      ell(c, x + s.gx, y + s.gy + (kind === "wide" ? 4 * Math.sin(s.t * 1.7) : 0), pr, pr * Math.min(1, open * 1.2));
      c.fill();
      return;
    }
    case "happy": {
      c.lineWidth = 13;
      c.beginPath();
      c.moveTo(x - 30, y + 12);
      c.quadraticCurveTo(x, y - 34 * pop, x + 30, y + 12);
      c.stroke();
      return;
    }
    case "closed": {
      c.lineWidth = 13;
      c.beginPath();
      const d = side === 0 ? 1 : -1;
      c.moveTo(x - 32 * d, y - 14);
      c.lineTo(x + 6 * d, y + 2);
      c.lineTo(x - 32 * d, y + 16);
      c.stroke();
      return;
    }
    case "half": {
      if (open < 0.25) return blinkLine();
      c.beginPath();
      c.ellipse(x + s.gx * 0.3, y + 4, 24, 20, 0, 0, Math.PI);
      c.closePath();
      c.fill();
      c.lineWidth = 11;
      c.beginPath();
      c.moveTo(x - 32, y + 2);
      c.lineTo(x + 32, y + 2 + (side === 0 ? 4 : -4));
      c.stroke();
      return;
    }
    case "wink": {
      if (side === 1) return drawEye(c, "happy", side, s, pop);
      return drawEye(c, "dot", side, s, pop);
    }
    case "x": {
      c.lineWidth = 12;
      c.beginPath();
      c.moveTo(x - 24, y - 24);
      c.lineTo(x + 24, y + 24);
      c.moveTo(x + 24, y - 24);
      c.lineTo(x - 24, y + 24);
      c.stroke();
      return;
    }
    case "spiral": {
      c.lineWidth = 7;
      c.beginPath();
      const rot = s.t * 0.35 * (side === 0 ? 1 : -1);
      for (let a = 0; a < Math.PI * 6; a += 0.2) {
        const r = 2 + a * 2.3;
        const px = x + Math.cos(a + rot) * r;
        const py = y + Math.sin(a + rot) * r;
        if (a === 0) c.moveTo(px, py);
        else c.lineTo(px, py);
      }
      c.stroke();
      return;
    }
    case "heart": {
      const k = (1 + 0.12 * Math.sin(s.t * 0.5)) * pop;
      c.fillStyle = "#ff2d55";
      c.beginPath();
      c.moveTo(x, y + 28 * k);
      c.bezierCurveTo(x - 50 * k, y - 4 * k, x - 24 * k, y - 42 * k, x, y - 16 * k);
      c.bezierCurveTo(x + 24 * k, y - 42 * k, x + 50 * k, y - 4 * k, x, y + 28 * k);
      c.fill();
      c.lineWidth = 6;
      c.stroke();
      return;
    }
    case "star": {
      const k = (1 + 0.15 * Math.sin(s.t * 0.6)) * pop;
      c.fillStyle = "#ffd21e";
      c.beginPath();
      for (let i = 0; i < 10; i++) {
        const r = (i % 2 === 0 ? 40 : 17) * k;
        const a = -Math.PI / 2 + (i * Math.PI) / 5 + s.t * 0.04;
        c.lineTo(x + Math.cos(a) * r, y + Math.sin(a) * r);
      }
      c.closePath();
      c.fill();
      c.lineWidth = 6;
      c.stroke();
      return;
    }
  }
};

const drawBrows = (c: CanvasRenderingContext2D, kind: BrowKind, s: FaceState) => {
  if (kind === "none") return;
  c.strokeStyle = INK;
  c.lineWidth = 13;
  c.lineCap = "round";
  const lift = Math.max(0, 1 - s.since / 6) * 10; // salto na troca de expressão
  for (const side of [0, 1]) {
    const x = MX + EX[side];
    const d = side === 0 ? -1 : 1; // -1 lado esquerdo da tela
    let inner = 0;
    let outer = 0;
    let y = EY - 68 - lift;
    if (kind === "up") { inner = -6; outer = -2; y -= 8; }
    if (kind === "angry") { inner = 22; outer = -12; }
    if (kind === "sad" || kind === "worried") { inner = -16; outer = 12; }
    if (kind === "worried") y -= 6;
    if (kind === "flat") y += 6;
    if (kind === "one") {
      if (side === 1) { inner = -10; outer = -22; y -= 10; } else { inner = 4; outer = 4; y += 6; }
    }
    c.beginPath();
    c.moveTo(x - d * 4, y + inner);
    c.quadraticCurveTo(x + d * 18, y - 8 + (inner + outer) / 2, x + d * 40, y + outer);
    c.stroke();
  }
};

const openMouth = (c: CanvasRenderingContext2D, w: number, h: number, curve: number, teeth: boolean, tongue: boolean) => {
  // contorno de boca aberta: borda superior quase reta, inferior em arco (curve>0 sorriso, <0 tristeza)
  c.beginPath();
  if (curve >= 0) {
    c.moveTo(MX - w, MY - curve * 8);
    c.quadraticCurveTo(MX, MY + 4, MX + w, MY - curve * 8);
    c.quadraticCurveTo(MX + w * 0.9, MY + h, MX, MY + h);
    c.quadraticCurveTo(MX - w * 0.9, MY + h, MX - w, MY - curve * 8);
  } else {
    c.moveTo(MX - w, MY + h * 0.6);
    c.quadraticCurveTo(MX - w * 0.9, MY - h * 0.4, MX, MY - h * 0.4);
    c.quadraticCurveTo(MX + w * 0.9, MY - h * 0.4, MX + w, MY + h * 0.6);
    c.quadraticCurveTo(MX, MY + h * 0.45, MX - w, MY + h * 0.6);
  }
  c.closePath();
  c.fillStyle = INK;
  c.fill();
  c.save();
  c.clip();
  if (tongue) {
    c.fillStyle = "#e8394d";
    ell(c, MX, MY + h * (curve >= 0 ? 0.95 : 0.6), w * 0.55, h * 0.45);
    c.fill();
  }
  if (teeth) {
    c.fillStyle = "#fff";
    c.fillRect(MX - w, MY - (curve >= 0 ? 20 : h * 0.4 + 2), w * 2, curve >= 0 ? 30 : 18);
  }
  c.restore();
};

const drawMouth = (c: CanvasRenderingContext2D, kind: MouthKind, s: FaceState) => {
  const o = s.mouth;
  c.strokeStyle = INK;
  c.fillStyle = INK;
  c.lineCap = "round";
  c.lineWidth = 12;
  const talking = o > 0.08;
  switch (kind) {
    case "smile":
    case "tongue":
      if (talking) return openMouth(c, 62, 18 + 70 * o, 1, o > 0.35, true);
      c.beginPath();
      c.moveTo(MX - 64, MY - 8);
      c.quadraticCurveTo(MX, MY + 46, MX + 64, MY - 8);
      c.stroke();
      if (kind === "tongue") {
        c.fillStyle = "#e8394d";
        ell(c, MX + 18, MY + 30, 20, 24, 0.3);
        c.fill();
        c.lineWidth = 6;
        c.stroke();
      }
      return;
    case "grin":
      return openMouth(c, 104, 92 + 40 * o + 6 * Math.sin(s.t * 0.9), 1, true, true);
    case "evil": {
      openMouth(c, 112, 46 + 50 * o, 1.6, true, false);
      c.strokeStyle = INK;
      c.lineWidth = 4;
      for (let i = -3; i <= 3; i++) {
        c.beginPath();
        c.moveTo(MX + i * 28, MY - 14);
        c.lineTo(MX + i * 28, MY + 14);
        c.stroke();
      }
      return;
    }
    case "smirk":
      if (talking) return openMouth(c, 50, 16 + 50 * o, 0.6, false, true);
      c.beginPath();
      c.moveTo(MX - 50, MY + 10);
      c.quadraticCurveTo(MX + 20, MY + 24, MX + 62, MY - 18);
      c.stroke();
      return;
    case "o": {
      const r = 24 + 26 * o + 3 * Math.sin(s.t * 0.7);
      ell(c, MX, MY + 10, r * 0.85, r * 1.15);
      c.fill();
      return;
    }
    case "frown":
      if (talking) return openMouth(c, 58, 24 + 60 * o, -1, false, true);
      c.beginPath();
      c.moveTo(MX - 56, MY + 30);
      c.quadraticCurveTo(MX, MY - 16, MX + 56, MY + 30);
      c.stroke();
      return;
    case "wail":
      return openMouth(c, 80, 70 + 50 * o + 8 * Math.sin(s.t * 1.2), -1, false, true);
    case "wavy": {
      if (talking) return openMouth(c, 52, 18 + 56 * o, 0, false, true);
      c.lineWidth = 10;
      c.beginPath();
      for (let i = 0; i <= 24; i++) {
        const px = MX - 66 + (132 * i) / 24;
        const py = MY + 12 + Math.sin(i * 0.9 + s.t * 0.5) * 9;
        if (i === 0) c.moveTo(px, py);
        else c.lineTo(px, py);
      }
      c.stroke();
      return;
    }
    case "flat":
      if (talking) return openMouth(c, 52, 14 + 52 * o, 0, false, true);
      c.beginPath();
      c.moveTo(MX - 50, MY + 12);
      c.lineTo(MX + 50, MY + 12);
      c.stroke();
      return;
    case "teeth": {
      const h = 34 + 50 * o;
      c.fillStyle = "#fff";
      c.beginPath();
      c.roundRect(MX - 74, MY - 4, 148, h, 14);
      c.fill();
      c.lineWidth = 10;
      c.stroke();
      c.lineWidth = 5;
      c.beginPath();
      c.moveTo(MX - 74, MY - 4 + h / 2);
      c.lineTo(MX + 74, MY - 4 + h / 2);
      for (let i = -2; i <= 2; i++) {
        c.moveTo(MX + i * 28, MY - 4);
        c.lineTo(MX + i * 28, MY - 4 + h);
      }
      c.stroke();
      return;
    }
  }
};

const drawExtras = (c: CanvasRenderingContext2D, extras: Extra[], s: FaceState) => {
  for (const e of extras) {
    if (e === "stream") {
      for (const side of [0, 1]) {
        const x = MX + EX[side] + (side === 0 ? -6 : 6);
        const grad = c.createLinearGradient(0, EY + 10, 0, FACE_H);
        grad.addColorStop(0, "rgba(90,180,255,0.95)");
        grad.addColorStop(1, "rgba(60,150,255,0.55)");
        c.fillStyle = grad;
        c.beginPath();
        c.moveTo(x - 16, EY + 14);
        for (let yy = EY + 14; yy <= FACE_H; yy += 10) c.lineTo(x - 16 + Math.sin(yy * 0.08 - s.t * 0.9) * 5, yy);
        c.lineTo(x + 16, FACE_H);
        for (let yy = FACE_H; yy >= EY + 14; yy -= 10) c.lineTo(x + 16 + Math.sin(yy * 0.08 - s.t * 0.9) * 5, yy);
        c.closePath();
        c.fill();
      }
    }
    if (e === "drops") {
      c.fillStyle = "rgba(110,195,255,0.95)";
      for (const side of [0, 1]) {
        const p = (s.t % 18) / 18;
        ell(c, MX + EX[side] + (side === 0 ? -44 : 44), EY + 6 + p * 40, 9, 13);
        c.fill();
      }
    }
    if (e === "blush") {
      c.fillStyle = "rgba(255,105,140,0.55)";
      for (const side of [0, 1]) {
        ell(c, MX + EX[side] * 1.45, EY + 78, 34, 17);
        c.fill();
      }
    }
    if (e === "sweat") {
      const p = Math.min(1, s.since / 30);
      const x = MX + 168;
      const y = 80 + p * 70;
      c.fillStyle = "rgba(120,200,255,0.95)";
      c.strokeStyle = "rgba(30,90,170,0.9)";
      c.lineWidth = 5;
      c.beginPath();
      c.moveTo(x, y - 34);
      c.quadraticCurveTo(x + 22, y, x, y + 14);
      c.quadraticCurveTo(x - 22, y, x, y - 34);
      c.fill();
      c.stroke();
    }
    if (e === "vein") {
      const k = 1 + 0.18 * Math.sin(s.t * 0.8);
      c.strokeStyle = "#e0262f";
      c.lineWidth = 9;
      const x = MX + 150;
      const y = 70;
      c.beginPath();
      for (const [a, b] of [[-1, -1], [1, -1], [-1, 1], [1, 1]]) {
        c.moveTo(x + a * 8 * k, y + b * 8 * k);
        c.quadraticCurveTo(x + a * 14 * k, y + b * 4 * k, x + a * 26 * k, y + b * 22 * k);
      }
      c.stroke();
    }
    if (e === "sparkle") {
      c.fillStyle = "#fff8c4";
      for (let i = 0; i < 4; i++) {
        const a = s.t * 0.05 + i * 1.57;
        const x = MX + Math.cos(a) * 200;
        const y = EY + Math.sin(a) * 90;
        const r = 10 + 5 * Math.sin(s.t * 0.4 + i);
        c.beginPath();
        c.moveTo(x, y - r * 2);
        c.lineTo(x + r * 0.5, y);
        c.lineTo(x, y + r * 2);
        c.lineTo(x - r * 0.5, y);
        c.closePath();
        c.fill();
      }
    }
    if (e === "drool") {
      const p = (s.t % 60) / 60;
      c.fillStyle = "rgba(140,210,255,0.9)";
      ell(c, MX + 40, MY + 28 + p * 30, 8, 12 + p * 10);
      c.fill();
    }
  }
};

const IMAGE_EYES = new Set<EyeKind>(["dot", "big", "wide", "half", "sad", "wink"]);

/** Olhos "de verdade" recortados da textura, deformados pela careta (piscar, arregalar, semicerrar). */
const drawImageEyes = (c: CanvasRenderingContext2D, kind: EyeKind, s: FaceState, pop: number) => {
  const ei = s.eyeImage!;
  const [sx, sy, sw, sh] = ei.src;
  const w = 330 * ei.scale * pop * (kind === "wide" ? 1.18 : 1);
  const h = (w * sh) / sw;
  const open = 1 - s.blink;
  if (open < 0.25) {
    for (const side of [0, 1]) {
      c.strokeStyle = INK;
      c.lineWidth = 9;
      c.lineCap = "round";
      c.beginPath();
      c.moveTo(MX + EX[side] - 34, EY);
      c.quadraticCurveTo(MX + EX[side], EY + 8, MX + EX[side] + 34, EY);
      c.stroke();
    }
    return;
  }
  const hh = h * (kind === "half" ? 0.55 : kind === "sad" ? 0.85 : 1) * open;
  const dy = kind === "half" ? h * 0.22 : kind === "sad" ? h * 0.08 : 0;
  c.save();
  if (kind === "wink") {
    c.beginPath();
    c.rect(0, 0, MX, FACE_H);
    c.clip();
  }
  c.drawImage(ei.img, sx, sy + (kind === "half" ? sh * 0.4 : 0), sw, sh * (kind === "half" ? 0.6 : 1), MX - w / 2, EY - h / 2 + dy, w, hh);
  c.restore();
  if (kind === "half") {
    c.strokeStyle = INK;
    c.lineWidth = 7;
    for (const side of [0, 1]) {
      c.beginPath();
      c.moveTo(MX + EX[side] - 40, EY - h / 2 + dy + 2);
      c.lineTo(MX + EX[side] + 40, EY - h / 2 + dy + 2 + (side ? -5 : 5));
      c.stroke();
    }
  }
  if (kind === "wink") drawEye(c, "happy", 1, s, pop);
};

export const drawFace = (c: CanvasRenderingContext2D, s: FaceState) => {
  EY = s.eyeY ?? 178;
  MY = s.mouthY ?? 305;
  if (!s.eyeImage) c.clearRect(0, 0, FACE_W, FACE_H);
  const spec = EXPRESSIONS[s.expr] ?? EXPRESSIONS.neutral;
  // "pop" de entrada: olhos crescem e voltam (caretas mais legíveis no corte)
  const pop = 1 + 0.25 * Math.max(0, 1 - s.since / 7) * Math.cos((s.since / 7) * Math.PI * 0.5);
  if (spec.extras.includes("stream")) drawExtras(c, ["stream"], s);
  if (s.eyeImage && IMAGE_EYES.has(spec.eyes)) {
    drawImageEyes(c, spec.eyes, s, pop);
  } else {
    drawEye(c, spec.eyes, 0, s, pop);
    drawEye(c, spec.eyes, 1, s, pop);
  }
  drawBrows(c, spec.brows, s);
  drawMouth(c, spec.mouth, s);
  if (s.glasses) {
    c.strokeStyle = INK;
    c.lineWidth = 8;
    for (const side of [0, 1]) {
      ell(c, MX + EX[side], EY, 54, 50);
      c.stroke();
    }
    c.beginPath();
    c.moveTo(MX - 28, EY - 6);
    c.lineTo(MX + 28, EY - 6);
    c.stroke();
  }
  drawExtras(c, spec.extras.filter((e) => e !== "stream"), s);
};
