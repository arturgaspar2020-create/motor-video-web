import { useMemo } from "react";
import { RepeatWrapping, type Texture } from "three";
import { useImageTexture } from "./useImageTexture";

// Materiais com textura (public/textures/<nome>.jpg, 1024×1024, repetíveis). A repetição é calculada pelo
// tamanho da peça: "tile" = quantas unidades do mundo cada repetição cobre. "c" multiplica a cor (tingir).
// Texturas incluídas na skill (assets/textures): ver references/story-format.md → "Texturas".

export type V3t = [number, number, number];

const useTiled = (name: string, rx: number, ry: number) => {
  const base = useImageTexture(`textures/${name}.jpg`);
  return useMemo(() => {
    if (!base) return null;
    const t: Texture = base.clone();
    t.wrapS = RepeatWrapping;
    t.wrapT = RepeatWrapping;
    t.repeat.set(Math.max(0.2, rx), Math.max(0.2, ry));
    t.needsUpdate = true;
    return t;
  }, [base, rx, ry]);
};

/** Caixa texturizada: repete pela maior face (piso: x×z; parede: x×y ou z×y). */
export const TexBox: React.FC<{ s: V3t; p: V3t; tex: string; tile?: number; c?: string; r?: V3t; rough?: number; shadow?: boolean }> = ({ s, p, tex, tile = 4, c = "#ffffff", r, rough = 0.85, shadow = true }) => {
  const dims = [...s].sort((a, b) => b - a);
  const map = useTiled(tex, dims[0] / tile, dims[1] / tile);
  return (
    <mesh position={p} rotation={r} castShadow={shadow} receiveShadow>
      <boxGeometry args={s} />
      <meshStandardMaterial map={map} color={c} roughness={rough} />
    </mesh>
  );
};

/** Chão plano grande com textura repetida. */
export const TexGround: React.FC<{ tex: string; size?: number; tile?: number; c?: string; y?: number }> = ({ tex, size = 400, tile = 6, c = "#ffffff", y = 0 }) => {
  const map = useTiled(tex, size / tile, size / tile);
  return (
    <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, y, 0]} receiveShadow>
      <planeGeometry args={[size, size]} />
      <meshStandardMaterial map={map} color={c} roughness={0.95} />
    </mesh>
  );
};

/** Faixa plana (rua, calçada, caminho) com textura repetida ao longo do comprimento. */
export const TexStrip: React.FC<{ w: number; l: number; p: V3t; tex: string; tile?: number; c?: string; h?: number; side?: string }> = ({ w, l, p, tex, tile = 4, c = "#ffffff", h = 0.06, side = "#6b6f7a" }) => {
  const map = useTiled(tex, w / tile, l / tile);
  return (
    <mesh position={p} receiveShadow>
      <boxGeometry args={[w, h, l]} />
      <meshStandardMaterial attach="material-0" color={side} roughness={0.9} />
      <meshStandardMaterial attach="material-1" color={side} roughness={0.9} />
      <meshStandardMaterial attach="material-2" map={map} color={c} roughness={0.9} />
      <meshStandardMaterial attach="material-3" color={side} roughness={0.9} />
      <meshStandardMaterial attach="material-4" color={side} roughness={0.9} />
      <meshStandardMaterial attach="material-5" color={side} roughness={0.9} />
    </mesh>
  );
};
