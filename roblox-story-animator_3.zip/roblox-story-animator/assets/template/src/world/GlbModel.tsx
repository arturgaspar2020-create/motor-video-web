import { useThree } from "@react-three/fiber";
import { useEffect, useState } from "react";
import { cancelRender, continueRender, delayRender, staticFile } from "remotion";
import { Box3, Color, Mesh, MeshStandardMaterial, Vector3, type Group, type Material, type Object3D } from "three";
import { GLTFLoader, type GLTFLoaderPlugin, type GLTFParser } from "three/examples/jsm/loaders/GLTFLoader.js";
import { clone as cloneSkinned } from "three/examples/jsm/utils/SkeletonUtils.js";

// Carregador de modelos .glb/.gltf de public/ usado por cenários (ModelProp) e acessórios presos
// nos personagens. Recursos:
//  - height ou width: redimensiona para essa altura/largura (u)
//  - anchor: "base" apoia no chão, "center" centraliza, "top" pendura pelo topo (cabelos)
//  - parts / hideParts: mostra só (ou esconde) malhas cujo nome contém esses trechos
//  - tint: multiplica a cor (cabelos/peças em tons de cinza feitos para receber cor)
//  - compatibilidade com KHR_materials_pbrSpecularGlossiness (formato antigo, comum em modelos
//    do Sketchfab, que o Three.js atual não lê mais: sem isto a peça fica cinza)
//  - modelos com ossos são clonados com SkeletonUtils (cópia simples deixa a malha "flutuando")
// O render espera o carregamento (delayRender) e força um advance() do ThreeCanvas.

class SpecGlossCompat implements GLTFLoaderPlugin {
  name = "KHR_materials_pbrSpecularGlossiness";
  constructor(private parser: GLTFParser) {}
  extendMaterialParams(materialIndex: number, params: Record<string, unknown>) {
    const def = this.parser.json.materials?.[materialIndex];
    const ext = def?.extensions?.[this.name];
    if (!ext) return Promise.resolve();
    const f = ext.diffuseFactor as number[] | undefined;
    if (f) {
      params.color = new Color().setRGB(f[0], f[1], f[2]);
      params.opacity = f[3];
    }
    params.roughness = 1 - (ext.glossinessFactor ?? 0.5);
    params.metalness = 0;
    return ext.diffuseTexture ? this.parser.assignTexture(params, "map", ext.diffuseTexture, "srgb") : Promise.resolve();
  }
}

const cache = new Map<string, Promise<Group>>();
/** Carrega (com cache) um .glb de public/ já com a compatibilidade de textura antiga. Não clone aqui. */
export const loadGlb = (src: string) => load(src);
const load = (src: string) => {
  if (!cache.has(src)) {
    const loader = new GLTFLoader();
    loader.register((parser) => new SpecGlossCompat(parser));
    cache.set(src, new Promise<Group>((res, rej) => loader.load(staticFile(src), (g) => res(g.scene), undefined, rej)));
  }
  return cache.get(src)!;
};

export type GlbSpec = {
  src: string;
  height?: number;
  /** alternativa a height: largura final (x) em u — ideal para cabelos/relógios que envolvem a peça */
  width?: number;
  anchor?: "base" | "center" | "top";
  parts?: string[];
  hideParts?: string[];
  tint?: string;
};

const matches = (name: string, list: string[]) => list.some((p) => name.toLowerCase().includes(p.toLowerCase()));

/** Mostra a malha se o próprio nome ou o de algum ancestral casar com o filtro. */
const nameChain = (o: Object3D) => {
  const names: string[] = [];
  for (let p: Object3D | null = o; p; p = p.parent) names.push(p.name ?? "");
  return names.join("/");
};

export const GlbModel: React.FC<{ spec: GlbSpec }> = ({ spec }) => {
  const advance = useThree((st) => st.advance);
  const [model, setModel] = useState<{ obj: Object3D; fit: number; offset: Vector3 } | null>(null);
  const [handle] = useState(() => delayRender(`Carregando modelo ${spec.src}`));
  const key = JSON.stringify(spec);
  useEffect(() => {
    load(spec.src)
      .then((g) => {
        const obj = cloneSkinned(g);
        const tint = spec.tint ? new Color(spec.tint) : null;
        obj.traverse((o) => {
          if (!(o as Mesh).isMesh) return;
          const mesh = o as Mesh;
          const chain = nameChain(mesh);
          if (spec.parts?.length && !matches(chain, spec.parts)) mesh.visible = false;
          if (spec.hideParts?.length && matches(chain, spec.hideParts)) mesh.visible = false;
          mesh.castShadow = true;
          mesh.receiveShadow = true;
          if (tint) {
            const mats = (Array.isArray(mesh.material) ? mesh.material : [mesh.material]).map((m: Material) => {
              const c = m.clone() as MeshStandardMaterial;
              if (c.color) c.color.multiply(tint);
              return c;
            });
            mesh.material = Array.isArray(mesh.material) ? mats : mats[0];
          }
        });
        obj.updateMatrixWorld(true);
        // caixa só das malhas visíveis (precisa para "parts")
        const box = new Box3();
        obj.traverse((o) => {
          if ((o as Mesh).isMesh && o.visible) box.expandByObject(o, true);
        });
        if (box.isEmpty()) box.setFromObject(obj, true);
        const size = box.getSize(new Vector3());
        const fit = spec.width && size.x > 0 ? spec.width / size.x : spec.height && size.y > 0 ? spec.height / size.y : 1;
        const c = box.getCenter(new Vector3());
        const sized = !!(spec.width || spec.height);
        const offset =
          spec.anchor === "center" ? new Vector3(-c.x, -c.y, -c.z)
          : spec.anchor === "top" ? new Vector3(-c.x, -box.max.y, -c.z)
          : sized ? new Vector3(-c.x, -box.min.y, -c.z)
          : new Vector3();
        setModel({ obj, fit, offset });
      })
      .catch((e) => cancelRender(new Error(`Falha ao carregar ${spec.src}: ${e}`)));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [key]);
  useEffect(() => {
    if (!model) return;
    advance(performance.now());
    continueRender(handle);
  }, [model, advance, handle]);
  if (!model) return null;
  return (
    <group scale={model.fit}>
      <primitive object={model.obj} position={model.offset.toArray()} />
    </group>
  );
};
