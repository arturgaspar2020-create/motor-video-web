import { useMemo } from "react";
import { random } from "remotion";
import { BufferAttribute, BufferGeometry } from "three";
import type { SetName, TimeOfDay } from "../types";
import { TexBox, TexGround, TexStrip } from "./Textured";

// Cenários low-poly originais, saturados e "de brinquedo". Convenção: os atores ficam perto da origem,
// olhando para +z; a câmera padrão fica em +z olhando para −z, então o fundo do cenário fica em −z.
// Todos aceitam o horário (day/sunset/night): janelas e postes acendem à noite.

type V3 = [number, number, number];

const B: React.FC<{ s: V3; p: V3; c: string; r?: V3; e?: string; shadow?: boolean }> = ({ s, p, c, r, e, shadow = true }) => (
  <mesh position={p} rotation={r} castShadow={shadow} receiveShadow>
    <boxGeometry args={s} />
    <meshStandardMaterial color={c} roughness={0.75} emissive={e ?? "#000000"} emissiveIntensity={e ? 1 : 0} />
  </mesh>
);

const HOUSE_COLORS = ["#ff7eb6", "#7ee0ff", "#ffd86b", "#9cf08a", "#b89cff", "#ff9f6b", "#6bb8ff", "#f3f3f3"];
const ROOF_COLORS = ["#e04848", "#3d7be0", "#30a46c", "#8e5bd8", "#e08a2e"];

const House: React.FC<{ p: V3; side: 1 | -1; seed: number; night: boolean }> = ({ p, side, seed, night }) => {
  const h = 6 + Math.floor(random(`h${seed}`) * 4);
  const w = 6;
  const col = HOUSE_COLORS[Math.floor(random(`c${seed}`) * HOUSE_COLORS.length)];
  const roof = ROOF_COLORS[Math.floor(random(`r${seed}`) * ROOF_COLORS.length)];
  const win = night ? "#ffe9a0" : "#bfe8ff";
  const fx = -side * (w / 2 + 0.02); // fachada voltada para a rua
  return (
    <group position={p}>
      {seed % 3 === 1 ? <TexBox s={[w, h, 6.4]} p={[0, h / 2, 0]} tex="red_brick" tile={3} /> : <B s={[w, h, 6.4]} p={[0, h / 2, 0]} c={col} />}
      <B s={[w + 0.8, 0.5, 7.2]} p={[0, h + 0.25, 0]} c={roof} />
      <B s={[0.12, 2.6, 1.5]} p={[fx, 1.3, 0.8]} c={["#2e6be6", "#e6492e", "#2ea86b", "#7a4a2a"][seed % 4]} />
      <B s={[0.12, 1.5, 1.5]} p={[fx, 4.2, -1.4]} c={win} e={night ? "#ffcf5a" : undefined} shadow={false} />
      {h > 7 ? <B s={[0.12, 1.4, 1.4]} p={[fx, h - 1.6, 1.2]} c={win} e={night ? "#ffcf5a" : undefined} shadow={false} /> : null}
      <B s={[0.5, 0.15, 7.2]} p={[fx * 1.05, 2.95, 0]} c="#ffffff" />
    </group>
  );
};

const Lamp: React.FC<{ p: V3; night: boolean }> = ({ p, night }) => (
  <group position={p}>
    <B s={[0.25, 6, 0.25]} p={[0, 3, 0]} c="#3a3f4a" />
    <B s={[0.9, 0.5, 0.9]} p={[0, 6.2, 0]} c={night ? "#fff2b0" : "#dfe6ee"} e={night ? "#ffd970" : undefined} shadow={false} />
  </group>
);

const Street: React.FC<{ night: boolean }> = ({ night }) => {
  const houses = [];
  for (let i = 0; i < 12; i++) {
    const z = 18 - i * 7.5;
    houses.push(<House key={`l${i}`} p={[-9.5, 0, z]} side={-1} seed={i * 2} night={night} />);
    houses.push(<House key={`r${i}`} p={[9.5, 0, z]} side={1} seed={i * 2 + 1} night={night} />);
  }
  return (
    <group>
      <TexGround tex="grass_ground" tile={8} c="#b8f0a0" />
      <TexStrip w={10} l={200} p={[0, 0.03, -40]} tex="clean_asphalt" tile={6} c="#c8ccd8" />
      {Array.from({ length: 30 }).map((_, i) => (
        <B key={i} s={[0.35, 0.07, 2]} p={[0, 0.05, 20 - i * 5]} c="#ffffff" shadow={false} />
      ))}
      <TexStrip w={2.2} l={200} h={0.25} p={[-6.1, 0.12, -40]} tex="brick_pavement_03" tile={2.2} side="#c9c4bf" />
      <TexStrip w={2.2} l={200} h={0.25} p={[6.1, 0.12, -40]} tex="brick_pavement_03" tile={2.2} side="#c9c4bf" />
      {houses}
      {[-6.6, 6.6].flatMap((x) => [12, 0, -12, -24, -36].map((z) => <Lamp key={`${x}${z}`} p={[x, 0, z]} night={night} />))}
    </group>
  );
};

const Bedroom: React.FC<{ night: boolean }> = ({ night }) => (
  <group>
    <TexBox s={[18, 0.3, 14]} p={[0, -0.15, -1]} tex="oak_wood_planks" tile={5} />
    <B s={[18, 11, 0.4]} p={[0, 5.5, -8]} c="#b9a6ff" />
    <B s={[0.4, 11, 14]} p={[-9, 5.5, -1]} c="#a08cf0" />
    <B s={[0.4, 11, 14]} p={[9, 5.5, -1]} c="#a08cf0" />
    {/* janela com céu */}
    <B s={[4.4, 3.6, 0.1]} p={[3.5, 6.2, -7.75]} c={night ? "#141a4a" : "#8fd8ff"} e={night ? "#0c1240" : "#6cc8ff"} shadow={false} />
    <B s={[4.8, 0.3, 0.3]} p={[3.5, 4.3, -7.65]} c="#ffffff" />
    <B s={[0.2, 3.6, 0.2]} p={[3.5, 6.2, -7.6]} c="#ffffff" />
    {night ? <B s={[0.5, 0.5, 0.05]} p={[4.6, 7.2, -7.68]} c="#fff6c8" e="#fff2a8" shadow={false} /> : null}
    {/* cama */}
    <B s={[4.5, 1.2, 7]} p={[-6.2, 0.6, -4.3]} c="#ffffff" />
    <B s={[4.6, 0.5, 4.6]} p={[-6.2, 1.4, -3.1]} c="#ff6fa8" />
    <B s={[3.2, 0.6, 1.6]} p={[-6.2, 1.5, -7]} c="#fff6ea" />
    <B s={[4.7, 2.6, 0.4]} p={[-6.2, 1.3, -7.9]} c="#8a5a3c" />
    {/* prateleira com bonequinhos */}
    <B s={[6, 0.25, 1]} p={[-1.5, 5.6, -7.4]} c="#ffffff" />
    {[-3.8, -2.7, -1.6, -0.5, 0.6].map((x, i) => (
      <group key={i} position={[x, 5.73, -7.3]}>
        <B s={[0.3, 0.45, 0.2]} p={[0, 0.22, 0]} c={["#2f7df6", "#e04848", "#30a46c", "#ffd21e", "#8e5bd8"][i]} />
        <B s={[0.24, 0.24, 0.24]} p={[0, 0.58, 0]} c="#f6d03b" />
      </group>
    ))}
    {/* escrivaninha + abajur */}
    <B s={[4, 0.3, 2.2]} p={[6.2, 2.4, -6.4]} c="#ffffff" />
    <B s={[0.3, 2.4, 2]} p={[4.4, 1.2, -6.4]} c="#e8e8f0" />
    <B s={[0.3, 2.4, 2]} p={[8, 1.2, -6.4]} c="#e8e8f0" />
    <B s={[0.7, 0.8, 0.7]} p={[7.3, 3.0, -6.6]} c="#fff2b0" e={night ? "#ffcf5a" : undefined} />
    {/* tapete e porta */}
    <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0.5, 0.02, 0]} receiveShadow>
      <circleGeometry args={[3.2, 32]} />
      <meshStandardMaterial color="#7ec8ff" roughness={1} />
    </mesh>
    <B s={[0.15, 5, 2.6]} p={[8.75, 2.5, 1]} c="#ffffff" />
    <B s={[0.2, 0.3, 0.3]} p={[8.6, 2.5, 0.1]} c="#d9b44a" />
  </group>
);

const Rooftop: React.FC<{ night: boolean }> = ({ night }) => {
  const city = useMemo(() => {
    const out: { p: V3; s: V3; c: string }[] = [];
    for (let i = 0; i < 70; i++) {
      const a = random(`ca${i}`) * Math.PI * 2;
      const r = 26 + random(`cr${i}`) * 60;
      const h = 8 + random(`ch${i}`) * 30;
      out.push({ p: [Math.sin(a) * r, -40 + h / 2, Math.cos(a) * r - 10], s: [6 + random(`cw${i}`) * 6, h, 6 + random(`cd${i}`) * 6], c: HOUSE_COLORS[i % HOUSE_COLORS.length] });
    }
    return out;
  }, []);
  return (
    <group>
      <TexBox s={[20, 1, 20]} p={[0, -0.5, -2]} tex="herringbone_concrete_tile_03" tile={3} c="#e8e4f0" />
      <B s={[20, 40, 20]} p={[0, -21, -2]} c="#8fb8ff" />
      {[-10, 10].map((x) => <B key={x} s={[0.3, 1.4, 20]} p={[x, 0.7, -2]} c="#f6f6f6" />)}
      <B s={[20, 1.4, 0.3]} p={[0, 0.7, -12]} c="#f6f6f6" />
      {/* casinha da escada com porta */}
      <B s={[5, 5, 5]} p={[-5.5, 2.5, -8]} c="#7ec8ff" />
      <B s={[5.4, 0.4, 5.4]} p={[-5.5, 5.2, -8]} c="#3d7be0" />
      <B s={[2, 3.6, 0.15]} p={[-5.5, 1.8, -5.45]} c="#e8743a" />
      <B s={[0.6, 0.4, 0.2]} p={[-5.5, 4.2, -5.4]} c="#fff6c8" e={night ? "#ffe9a0" : undefined} />
      {/* caixa d'água e vasos */}
      <mesh position={[6, 2.2, -8]} castShadow>
        <cylinderGeometry args={[1.8, 1.8, 3, 20]} />
        <meshStandardMaterial color="#ffffff" roughness={0.7} />
      </mesh>
      {[[7.5, -1], [-8, 3], [8, 5]].map(([x, z], i) => (
        <group key={i} position={[x, 0, z]}>
          <B s={[1, 0.9, 1]} p={[0, 0.45, 0]} c="#c8643a" />
          <mesh position={[0, 1.3, 0]} castShadow>
            <icosahedronGeometry args={[0.7, 0]} />
            <meshStandardMaterial color="#3fbf5a" flatShading />
          </mesh>
        </group>
      ))}
      {city.map((b, i) => (
        <group key={i}>
          <B s={b.s} p={b.p} c={b.c} shadow={false} />
          {night ? <B s={[b.s[0] * 0.5, 0.8, 0.1]} p={[b.p[0], b.p[1] + b.s[1] * 0.3, b.p[2] + b.s[2] / 2 + 0.06]} c="#ffe9a0" e="#ffcf5a" shadow={false} /> : null}
        </group>
      ))}
    </group>
  );
};

const Tree: React.FC<{ p: V3; k?: number }> = ({ p, k = 1 }) => (
  <group position={p} scale={k}>
    <B s={[0.8, 3, 0.8]} p={[0, 1.5, 0]} c="#8a5a3c" />
    <mesh position={[0, 4.4, 0]} castShadow>
      <icosahedronGeometry args={[2.4, 0]} />
      <meshStandardMaterial color="#3fbf5a" flatShading roughness={0.8} />
    </mesh>
  </group>
);

const Park: React.FC = () => (
  <group>
    <TexGround tex="grass_ground" tile={7} c="#c8ffb0" />
    <TexStrip w={3} l={80} p={[0, 0.03, -20]} tex="dry_river_pebbles" tile={2.5} c="#f0e0c0" />
    {[[-7, -6], [7, -9], [-9, 4], [10, 2], [-5, -18], [6, -22], [-12, -12], [13, -15]].map(([x, z], i) => (
      <Tree key={i} p={[x, 0, z]} k={0.9 + (i % 3) * 0.2} />
    ))}
    <group position={[3.5, 0, -4]}>
      <B s={[4, 0.3, 1.2]} p={[0, 1.0, 0]} c="#c8743a" />
      <B s={[4, 1.2, 0.2]} p={[0, 1.8, -0.55]} c="#c8743a" />
      <B s={[0.2, 1, 1]} p={[-1.8, 0.5, 0]} c="#3a3f4a" />
      <B s={[0.2, 1, 1]} p={[1.8, 0.5, 0]} c="#3a3f4a" />
    </group>
    {Array.from({ length: 24 }).map((_, i) => (
      <mesh key={i} position={[(random(`fx${i}`) - 0.5) * 30, 0.25, -random(`fz${i}`) * 30 + 6]}>
        <icosahedronGeometry args={[0.25, 0]} />
        <meshStandardMaterial color={["#ff6fa8", "#ffd21e", "#ffffff", "#b89cff"][i % 4]} flatShading />
      </mesh>
    ))}
  </group>
);

const Classroom: React.FC = () => (
  <group>
    <TexBox s={[22, 0.3, 18]} p={[0, -0.15, -2]} tex="old_linoleum_flooring_01" tile={4} />
    <B s={[22, 11, 0.4]} p={[0, 5.5, -11]} c="#ffe3a8" />
    <B s={[0.4, 11, 18]} p={[-11, 5.5, -2]} c="#ffd27a" />
    <B s={[0.4, 11, 18]} p={[11, 5.5, -2]} c="#ffd27a" />
    <B s={[10, 4, 0.2]} p={[0, 5.5, -10.75]} c="#2f6a4a" />
    <B s={[10.4, 0.3, 0.5]} p={[0, 3.4, -10.6]} c="#8a5a3c" />
    {[-1, 1].map((d) => <B key={d} s={[0.1, 3, 3]} p={[d * 10.75, 6, -4]} c="#bfe8ff" e="#7fd0ff" shadow={false} />)}
    {[-5, 0, 5].flatMap((x) => [-3, 2].map((z) => (
      <group key={`${x}${z}`} position={[x, 0, z]}>
        <B s={[3, 0.25, 2]} p={[0, 2.5, 0]} c="#ffffff" />
        <B s={[0.25, 2.5, 0.25]} p={[-1.3, 1.25, -0.8]} c="#5a6070" />
        <B s={[0.25, 2.5, 0.25]} p={[1.3, 1.25, 0.8]} c="#5a6070" />
        <B s={[0.25, 2.5, 0.25]} p={[-1.3, 1.25, 0.8]} c="#5a6070" />
        <B s={[0.25, 2.5, 0.25]} p={[1.3, 1.25, -0.8]} c="#5a6070" />
      </group>
    )))}
  </group>
);

const LivingRoom: React.FC<{ night: boolean }> = ({ night }) => (
  <group>
    <TexBox s={[20, 0.3, 16]} p={[0, -0.15, -1]} tex="piso_de_madeira_cartoon_em_tons_quentes" tile={5} />
    <B s={[20, 12, 0.4]} p={[0, 6, -9]} c="#8fd0ff" />
    <B s={[0.4, 12, 16]} p={[-10, 6, -1]} c="#7ec0f0" />
    <B s={[0.4, 12, 16]} p={[10, 6, -1]} c="#7ec0f0" />
    {/* escada ao longo da parede esquerda */}
    {Array.from({ length: 12 }).map((_, i) => (
      <B key={i} s={[3, 0.8 * (i + 1), 1.2]} p={[-8.3, 0.4 * (i + 1), 5 - i * 1.2]} c="#a0643a" />
    ))}
    <B s={[0.2, 1.2, 15]} p={[-6.7, 6, -1]} r={[0.6, 0, 0]} c="#6b3f22" />
    {/* sofá, TV, planta, luminária */}
    <group position={[3, 0, -6.5]}>
      <B s={[6, 1.4, 2.4]} p={[0, 0.7, 0]} c="#e04848" />
      <B s={[6, 1.8, 0.6]} p={[0, 1.9, -1]} c="#c83a3a" />
      <B s={[0.6, 1.2, 2.4]} p={[-3, 1.4, 0]} c="#c83a3a" />
      <B s={[0.6, 1.2, 2.4]} p={[3, 1.4, 0]} c="#c83a3a" />
    </group>
    <B s={[3.6, 2.2, 0.2]} p={[3, 5.6, -8.7]} c="#1b1f2a" e={night ? "#2b4a9a" : undefined} />
    <group position={[8, 0, -7.5]}>
      <B s={[1.2, 1.2, 1.2]} p={[0, 0.6, 0]} c="#e0e0e0" />
      <mesh position={[0, 2, 0]} castShadow>
        <icosahedronGeometry args={[1, 0]} />
        <meshStandardMaterial color="#3fbf5a" flatShading />
      </mesh>
    </group>
    <mesh rotation={[-Math.PI / 2, 0, 0]} position={[2, 0.02, -1]} receiveShadow>
      <planeGeometry args={[8, 5]} />
      <meshStandardMaterial color="#ffd86b" roughness={1} />
    </mesh>
  </group>
);


const Hospital: React.FC<{ night: boolean }> = ({ night }) => (
  <group>
    <TexBox s={[24, 0.3, 18]} p={[0, -0.15, -1]} tex="terrazzo_tiles" tile={4} c="#f4f4f4" />
    <B s={[24, 12, 0.4]} p={[0, 6, -10]} c="#d5f1ea" />
    <B s={[24, 1.2, 0.45]} p={[0, 0.6, -9.98]} c="#7fc8b8" />
    <B s={[0.4, 12, 18]} p={[-12, 6, -1]} c="#c6ebe2" />
    <B s={[0.4, 12, 18]} p={[12, 6, -1]} c="#c6ebe2" />
    {/* cruz vermelha e placa */}
    <group position={[0, 8.6, -9.75]}>
      <B s={[3.4, 1.0, 0.15]} p={[0, 0, 0]} c="#e23b3b" e={night ? "#5a0e0e" : undefined} />
      <B s={[1.0, 3.4, 0.15]} p={[0, 0, 0]} c="#e23b3b" e={night ? "#5a0e0e" : undefined} />
    </group>
    <B s={[7, 1.1, 0.12]} p={[0, 6.4, -9.74]} c="#ffffff" />
    {/* janelas */}
    {[-1, 1].map((d) => (
      <B key={d} s={[0.12, 3.6, 4]} p={[d * 11.75, 6.2, -3]} c={night ? "#141a4a" : "#bfe8ff"} e={night ? "#0c1240" : "#7fd0ff"} shadow={false} />
    ))}
    {/* leitos com cortina */}
    {[-7.5, 7.5].map((x, i) => (
      <group key={i} position={[x, 0, -6.2]}>
        <B s={[3.2, 1.3, 6]} p={[0, 0.65, 0]} c="#e8edf2" />
        <B s={[3.0, 0.4, 5.6]} p={[0, 1.5, 0.1]} c="#8fc3ff" />
        <B s={[2.2, 0.5, 1.2]} p={[0, 1.75, -2.2]} c="#ffffff" />
        <B s={[3.4, 2.4, 0.3]} p={[0, 1.4, -3.05]} c="#b8c2cc" />
        <B s={[0.12, 7, 7]} p={[x > 0 ? -2.3 : 2.3, 3.5, 0.5]} c="#7ed6a8" />
        <B s={[0.15, 5, 0.15]} p={[x > 0 ? -1.9 : 1.9, 2.5, -2.4]} c="#cfd6de" />
        <B s={[0.6, 0.9, 0.3]} p={[x > 0 ? -1.9 : 1.9, 4.6, -2.4]} c="#e8fbff" />
      </group>
    ))}
    {/* balcão de recepção */}
    <group position={[0, 0, -7.5]}>
      <B s={[6, 2.6, 1.6]} p={[0, 1.3, 0]} c="#ffffff" />
      <B s={[6.2, 0.2, 1.8]} p={[0, 2.7, 0]} c="#57b7a3" />
      <B s={[1.2, 0.8, 0.1]} p={[1.6, 3.2, -0.3]} c="#1b1f2a" e={night ? "#2b4a9a" : "#123"} />
    </group>
    {/* cadeiras de espera */}
    {[-4.5, -3.2, 3.2, 4.5].map((x, i) => (
      <group key={i} position={[x, 0, 2.5 + (i % 2) * 0]}>
        <B s={[1.1, 0.25, 1.1]} p={[0, 1.2, 0]} c="#3d7be0" />
        <B s={[1.1, 1.2, 0.2]} p={[0, 1.9, -0.5]} c="#3d7be0" />
        <B s={[0.15, 1.1, 0.15]} p={[0, 0.55, 0]} c="#5a6070" />
      </group>
    ))}
    <B s={[0.15, 5.4, 2.8]} p={[11.75, 2.7, 4]} c="#f6f6f6" />
  </group>
);

/** Nuvens de blocos que andam devagar (cenários abertos, dia e pôr do sol). */
const Clouds: React.FC<{ t: number; time: TimeOfDay }> = ({ t, time }) => {
  const list = useMemo(
    () =>
      Array.from({ length: 16 }).map((_, i) => ({
        x: (random(`clx${i}`) - 0.5) * 420,
        y: 55 + random(`cly${i}`) * 45,
        z: -110 - random(`clz${i}`) * 170,
        k: 0.8 + random(`clk${i}`) * 1.4,
        n: 3 + Math.floor(random(`cln${i}`) * 3),
      })),
    [],
  );
  const col = time === "sunset" ? "#ffd2c0" : "#ffffff";
  return (
    <group>
      {list.map((c, i) => {
        const x = ((c.x + t * 0.05 * c.k + 210) % 420) - 210;
        return (
          <group key={i} position={[x, c.y, c.z]} scale={c.k}>
            {Array.from({ length: c.n }).map((_, j) => (
              <mesh key={j} position={[(j - c.n / 2) * 7, (j % 2) * 3, (j % 3) * 2]}>
                <boxGeometry args={[11 - (j % 2) * 3, 6 + (j % 2) * 3, 8]} />
                <meshStandardMaterial color={col} roughness={1} emissive={col} emissiveIntensity={0.35} />
              </mesh>
            ))}
          </group>
        );
      })}
    </group>
  );
};

const Sun: React.FC<{ time: TimeOfDay }> = ({ time }) =>
  time === "sunset" ? (
    <group position={[90, 22, -300]}>
      <mesh>
        <circleGeometry args={[26, 48]} />
        <meshBasicMaterial color="#ffb347" />
      </mesh>
      <mesh position={[0, 0, -1]}>
        <circleGeometry args={[40, 48]} />
        <meshBasicMaterial color="#ff8a5c" transparent opacity={0.35} />
      </mesh>
    </group>
  ) : time === "day" ? (
    <mesh position={[120, 170, -300]}>
      <circleGeometry args={[16, 40]} />
      <meshBasicMaterial color="#fff6c0" />
    </mesh>
  ) : null;

/** Chuva: gotas finas caindo numa caixa em volta da origem do cenário (determinística por frame). */
const Rain: React.FC<{ t: number }> = ({ t }) => {
  const drops = useMemo(
    () => Array.from({ length: 420 }).map((_, i) => ({ x: (random(`rx${i}`) - 0.5) * 44, z: (random(`rz${i}`) - 0.5) * 44 - 4, o: random(`ro${i}`) * 24, v: 0.9 + random(`rv${i}`) * 0.4 })),
    [],
  );
  return (
    <group>
      {drops.map((d, i) => {
        const y = 24 - ((d.o + t * d.v) % 24);
        return (
          <mesh key={i} position={[d.x + y * 0.06, y, d.z]} rotation={[0, 0, 0.06]}>
            <boxGeometry args={[0.03, 0.9, 0.03]} />
            <meshBasicMaterial color="#cfe4ff" transparent opacity={0.55} />
          </mesh>
        );
      })}
    </group>
  );
};

const Void: React.FC = () => (
  <mesh rotation={[-Math.PI / 2, 0, 0]} receiveShadow>
    <circleGeometry args={[14, 48]} />
    <meshStandardMaterial color="#ffffff" roughness={0.9} />
  </mesh>
);

/** Estrelas numa casca distante (paralaxe real com a câmera). */
const Stars: React.FC = () => {
  const geo = useMemo(() => {
    const n = 900;
    const arr = new Float32Array(n * 3);
    for (let i = 0; i < n; i++) {
      const u = random(`su${i}`) * Math.PI * 2;
      const v = 0.05 + random(`sv${i}`) * 0.95;
      const r = 300;
      arr[i * 3] = Math.cos(u) * Math.sqrt(1 - v * v) * r;
      arr[i * 3 + 1] = v * r;
      arr[i * 3 + 2] = Math.sin(u) * Math.sqrt(1 - v * v) * r;
    }
    const g = new BufferGeometry();
    g.setAttribute("position", new BufferAttribute(arr, 3));
    return g;
  }, []);
  return (
    <points geometry={geo}>
      <pointsMaterial size={3.2} sizeAttenuation={false} color="#ffffff" transparent opacity={0.95} />
    </points>
  );
};

const Moon: React.FC = () => (
  <group position={[-70, 120, -230]}>
    <mesh>
      <sphereGeometry args={[14, 32, 16]} />
      <meshBasicMaterial color="#fff6d0" />
    </mesh>
    <mesh position={[7, 4, 6]}>
      <sphereGeometry args={[13.2, 32, 16]} />
      <meshBasicMaterial color="#121a4a" />
    </mesh>
  </group>
);

export const SetView: React.FC<{ set: SetName; time: TimeOfDay; t?: number; weather?: string; clouds?: boolean }> = ({ set, time, t = 0, weather, clouds }) => {
  const night = time === "night";
  const outdoor = set === "street" || set === "rooftop" || set === "park" || set === "void";
  return (
    <>
      {outdoor && (clouds ?? weather !== "rain") && !night ? <Clouds t={t} time={time} /> : null}
      {outdoor && weather !== "rain" ? <Sun time={time} /> : null}
      {outdoor && weather === "rain" ? <Rain t={t} /> : null}
      {set === "hospital" ? <Hospital night={night} /> : null}
      {night && outdoor ? (
        <>
          <Stars />
          <Moon />
        </>
      ) : null}
      {set === "street" ? <Street night={night} /> : null}
      {set === "bedroom" ? <Bedroom night={night} /> : null}
      {set === "rooftop" ? <Rooftop night={night} /> : null}
      {set === "park" ? <Park /> : null}
      {set === "classroom" ? <Classroom /> : null}
      {set === "livingroom" ? <LivingRoom night={night} /> : null}
      {set === "void" ? <Void /> : null}
    </>
  );
};

export const SKY: Record<TimeOfDay, [string, string, string]> = {
  day: ["#5fb8ff", "#a9dcff", "#e8f6ff"],
  sunset: ["#3f3aa8", "#ff7a59", "#ffc988"],
  night: ["#060a2a", "#121a52", "#2a2f7a"],
};

export const TimeLighting: React.FC<{ time: TimeOfDay; indoor: boolean }> = ({ time, indoor }) => {
  const L = {
    day: { amb: 0.75, hemi: ["#cfe9ff", "#8fd17a", 0.75], sun: ["#fff4e0", 2.4], pos: [14, 26, 16] },
    sunset: { amb: 0.6, hemi: ["#ffc6a8", "#6a4a8a", 0.6], sun: ["#ff9a5a", 2.2], pos: [-22, 12, 10] },
    night: { amb: indoor ? 0.55 : 0.42, hemi: ["#5a6cff", "#1a1f40", indoor ? 0.6 : 0.5], sun: [indoor ? "#ffd9a0" : "#9fb4ff", indoor ? 1.5 : 1.1], pos: [-12, 24, 14] },
  }[time];
  return (
    <>
      <ambientLight intensity={L.amb} />
      <hemisphereLight args={[L.hemi[0] as string, L.hemi[1] as string, L.hemi[2] as number]} />
      <directionalLight
        position={L.pos as V3}
        intensity={L.sun[1] as number}
        color={L.sun[0] as string}
        castShadow
        shadow-mapSize-width={2048}
        shadow-mapSize-height={2048}
        shadow-camera-left={-24}
        shadow-camera-right={24}
        shadow-camera-top={24}
        shadow-camera-bottom={-24}
        shadow-camera-near={1}
        shadow-camera-far={90}
        shadow-bias={-0.0005}
        shadow-normalBias={0.04}
      />
      <directionalLight position={[10, 8, 22]} intensity={0.55} color="#ffffff" />
    </>
  );
};

export const isIndoor = (set: SetName) => set === "bedroom" || set === "classroom" || set === "livingroom" || set === "hospital";

/** Céu de chuva (cinza) e cor da neblina por horário. */
export const RAIN_SKY: Record<TimeOfDay, [string, string, string]> = {
  day: ["#6d7c8f", "#9aa7b6", "#c3ccd6"],
  sunset: ["#5a4f6e", "#9a7f86", "#c9b2a8"],
  night: ["#0b0f22", "#1a2036", "#2a3048"],
};
