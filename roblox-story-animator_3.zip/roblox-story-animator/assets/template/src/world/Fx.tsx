import { useLayoutEffect, useMemo, useRef } from "react";
import { random } from "remotion";
import { AdditiveBlending, DoubleSide, Shape, type Group } from "three";
import type { FxSpec, Shot } from "../types";

// Partículas e efeitos 3D, todos determinísticos (posição = função do frame e de uma semente).
// Tipos: dust, smoke, sparkle, confetti, energy_purple, energy_blue, impact, hearts, stars.
// "speedlines" é 2D (overlay/Effects.tsx). Posição: "on" = ator (acompanha) ou "pos" fixa.

type V3 = [number, number, number];
type ActorPos = Record<string, { x: number; y: number; z: number; face: number; scale: number }>;

const r = (k: string) => random(k);
const clamp01 = (v: number) => Math.min(1, Math.max(0, v));

/** Plano sempre virado para a câmera. */
const Billboard: React.FC<{ cam: V3; children: React.ReactNode; position?: V3 }> = ({ cam, children, position }) => {
  const ref = useRef<Group>(null);
  useLayoutEffect(() => {
    ref.current?.lookAt(cam[0], cam[1], cam[2]);
  });
  return (
    <group ref={ref} position={position}>
      {children}
    </group>
  );
};

const heartShape = (() => {
  const s = new Shape();
  s.moveTo(0, -0.5);
  s.bezierCurveTo(-0.9, 0.1, -0.5, 0.75, 0, 0.35);
  s.bezierCurveTo(0.5, 0.75, 0.9, 0.1, 0, -0.5);
  return s;
})();
const starShape = (() => {
  const s = new Shape();
  for (let i = 0; i < 10; i++) {
    const a = (i / 10) * Math.PI * 2 + Math.PI / 2;
    const rr = i % 2 === 0 ? 0.5 : 0.22;
    if (i === 0) s.moveTo(Math.cos(a) * rr, Math.sin(a) * rr);
    else s.lineTo(Math.cos(a) * rr, Math.sin(a) * rr);
  }
  s.closePath();
  return s;
})();

const Dust: React.FC<{ e: FxSpec; t: number; p: V3; dark?: boolean }> = ({ e, t, p, dark }) => {
  const n = e.count ?? (dark ? 10 : 12);
  const len = e.until - e.at;
  const u = clamp01(t / len);
  return (
    <group position={p}>
      {Array.from({ length: n }).map((_, i) => {
        const a = (i / n) * Math.PI * 2 + r(`d${e.seed}${i}`) * 0.6;
        const sp = 0.6 + r(`ds${e.seed}${i}`) * 0.8;
        const dist = (dark ? 0.8 : 2.2) * sp * (1 - Math.pow(1 - u, 2.4));
        const k = (0.35 + u * (dark ? 1.4 : 0.9)) * (e.size ?? 1);
        const y = 0.25 + (dark ? u * 3.5 : u * 0.5) * sp;
        return (
          <mesh key={i} position={[Math.cos(a) * dist, y, Math.sin(a) * dist]} scale={k}>
            <icosahedronGeometry args={[0.5, 1]} />
            <meshStandardMaterial color={e.color ?? (dark ? "#55575e" : "#d8cbb4")} transparent opacity={0.8 * (1 - u)} roughness={1} depthWrite={false} />
          </mesh>
        );
      })}
    </group>
  );
};

const Sparkle: React.FC<{ e: FxSpec; t: number; p: V3; cam: V3 }> = ({ e, t, p, cam }) => {
  const n = e.count ?? 14;
  const len = e.until - e.at;
  const fade = Math.min(clamp01(t / 4), clamp01((len - t) / 8));
  return (
    <group position={p}>
      {Array.from({ length: n }).map((_, i) => {
        const a = r(`sa${e.seed}${i}`) * Math.PI * 2 + t * 0.03;
        const rad = (0.8 + r(`sr${e.seed}${i}`) * 1.4) * (e.size ?? 1);
        const y = (r(`sy${e.seed}${i}`) - 0.3) * 2.4 + t * 0.012;
        const tw = Math.max(0, Math.sin(t * 0.45 + i * 1.7));
        return (
          <Billboard key={i} cam={cam} position={[Math.cos(a) * rad, y, Math.sin(a) * rad]}>
            <mesh scale={(0.25 + 0.45 * tw) * fade * (e.size ?? 1)} rotation={[0, 0, t * 0.08 + i]}>
              <shapeGeometry args={[starShape]} />
              <meshBasicMaterial color={e.color ?? (i % 3 === 0 ? "#ffffff" : "#ffe36b")} transparent opacity={0.95} side={DoubleSide} depthWrite={false} />
            </mesh>
          </Billboard>
        );
      })}
    </group>
  );
};

const CONF = ["#ff4f6d", "#ffd21e", "#3ddc84", "#3da5ff", "#b04dff", "#ff9f2e", "#ffffff"];
const Confetti: React.FC<{ e: FxSpec; t: number; p: V3 }> = ({ e, t, p }) => {
  const n = e.count ?? 90;
  return (
    <group position={p}>
      {Array.from({ length: n }).map((_, i) => {
        const k = `${e.seed}${i}`;
        const x0 = (r(`cx${k}`) - 0.5) * 12;
        const z0 = (r(`cz${k}`) - 0.5) * 8;
        const delay = r(`cd${k}`) * 20;
        const tt = Math.max(0, t - delay);
        const y = 10 + r(`cy${k}`) * 3 - tt * (0.09 + r(`cv${k}`) * 0.05);
        if (y < 0.05) return null;
        const sway = Math.sin(tt * 0.15 + i) * 0.6;
        return (
          <mesh key={i} position={[x0 + sway, y, z0 + Math.cos(tt * 0.12 + i) * 0.4]} rotation={[tt * 0.2 + i, tt * 0.13, tt * 0.17]}>
            <planeGeometry args={[0.32, 0.18]} />
            <meshStandardMaterial color={CONF[i % CONF.length]} side={DoubleSide} roughness={0.6} emissive={CONF[i % CONF.length]} emissiveIntensity={0.25} />
          </mesh>
        );
      })}
    </group>
  );
};

const Energy: React.FC<{ e: FxSpec; t: number; p: V3; color: string; glow: string }> = ({ e, t, p, color, glow }) => {
  const len = e.until - e.at;
  const grow = clamp01(t / 10);
  const fade = clamp01((len - t) / 6);
  const k = grow * fade * (e.size ?? 1);
  const pulse = 1 + 0.12 * Math.sin(t * 0.9);
  return (
    <group position={p} scale={k}>
      <mesh scale={0.55 * pulse}>
        <sphereGeometry args={[1, 24, 16]} />
        <meshBasicMaterial color="#ffffff" />
      </mesh>
      <mesh scale={0.95 * pulse}>
        <sphereGeometry args={[1, 24, 16]} />
        <meshBasicMaterial color={color} transparent opacity={0.55} blending={AdditiveBlending} depthWrite={false} />
      </mesh>
      <mesh scale={1.5 * pulse}>
        <sphereGeometry args={[1, 24, 16]} />
        <meshBasicMaterial color={glow} transparent opacity={0.22} blending={AdditiveBlending} depthWrite={false} />
      </mesh>
      {[0, 1, 2].map((i) => (
        <mesh key={i} rotation={[t * 0.12 + i * 1.1, t * 0.09 + i * 2.1, i * 0.7]}>
          <torusGeometry args={[1.35 + i * 0.2, 0.04, 8, 48]} />
          <meshBasicMaterial color={glow} transparent opacity={0.8} blending={AdditiveBlending} depthWrite={false} />
        </mesh>
      ))}
      {Array.from({ length: e.count ?? 26 }).map((_, i) => {
        const ph = ((t * 0.04 + r(`ep${e.seed}${i}`)) % 1 + 1) % 1;
        const rad = 3.2 * (1 - ph);
        const a = r(`ea${e.seed}${i}`) * Math.PI * 2 + ph * 4;
        const b = (r(`eb${e.seed}${i}`) - 0.5) * Math.PI;
        return (
          <mesh key={`p${i}`} position={[Math.cos(a) * Math.cos(b) * rad, Math.sin(b) * rad, Math.sin(a) * Math.cos(b) * rad]} scale={0.09 + 0.06 * ph}>
            <octahedronGeometry args={[1, 0]} />
            <meshBasicMaterial color={i % 2 ? "#ffffff" : glow} transparent opacity={0.9} blending={AdditiveBlending} depthWrite={false} />
          </mesh>
        );
      })}
      <pointLight color={color} intensity={18 * k} distance={12} decay={1.6} />
    </group>
  );
};

/** Impacto de soco: estouro de raios + anel + estilhaços, ~14 frames. */
const Impact: React.FC<{ e: FxSpec; t: number; p: V3; cam: V3 }> = ({ e, t, p, cam }) => {
  const len = Math.max(6, e.until - e.at);
  const u = clamp01(t / len);
  const out = 1 - Math.pow(1 - u, 3);
  const s = e.size ?? 1;
  const col = e.color ?? "#fff3a0";
  return (
    <group position={p}>
      <Billboard cam={cam}>
        <mesh scale={(0.4 + 2.6 * out) * s}>
          <ringGeometry args={[0.82, 1, 48]} />
          <meshBasicMaterial color="#ffffff" transparent opacity={1 - u} side={DoubleSide} depthWrite={false} />
        </mesh>
        <mesh scale={(0.3 + 1.6 * out) * s} rotation={[0, 0, 0.3]}>
          <shapeGeometry args={[starShape]} />
          <meshBasicMaterial color={col} transparent opacity={Math.max(0, 1 - u * 1.6)} side={DoubleSide} depthWrite={false} />
        </mesh>
        {Array.from({ length: 12 }).map((_, i) => {
          const a = (i / 12) * Math.PI * 2 + r(`ia${e.seed}${i}`) * 0.3;
          const d = (0.5 + 2.4 * out) * s;
          const l = (0.9 + r(`il${e.seed}${i}`) * 0.9) * (1 - u) * s;
          return (
            <mesh key={i} position={[Math.cos(a) * d, Math.sin(a) * d, 0.02]} rotation={[0, 0, a]}>
              <planeGeometry args={[l, 0.1 * s]} />
              <meshBasicMaterial color={i % 2 ? "#ffffff" : col} transparent opacity={1 - u} side={DoubleSide} depthWrite={false} />
            </mesh>
          );
        })}
      </Billboard>
      {Array.from({ length: 10 }).map((_, i) => {
        const a = r(`ja${e.seed}${i}`) * Math.PI * 2;
        const b = (r(`jb${e.seed}${i}`) - 0.3) * 1.6;
        const d = 3.2 * out * s;
        return (
          <mesh key={`j${i}`} position={[Math.cos(a) * d, Math.sin(b) * d - u * u * 1.5, Math.sin(a) * d]} rotation={[t * 0.4, t * 0.3, i]} scale={0.14 * (1 - u * 0.7) * s}>
            <boxGeometry args={[1, 1, 1]} />
            <meshBasicMaterial color={i % 2 ? "#ffffff" : col} />
          </mesh>
        );
      })}
      <pointLight color="#fff2c0" intensity={25 * (1 - u)} distance={10} decay={1.5} />
    </group>
  );
};

const Floaters: React.FC<{ e: FxSpec; t: number; p: V3; cam: V3; kind: "hearts" | "stars" }> = ({ e, t, p, cam, kind }) => {
  const n = e.count ?? (kind === "hearts" ? 7 : 5);
  const len = e.until - e.at;
  const fade = Math.min(clamp01(t / 5), clamp01((len - t) / 8));
  return (
    <group position={p}>
      {Array.from({ length: n }).map((_, i) => {
        const pos: V3 =
          kind === "stars"
            ? [Math.cos(t * 0.18 + (i / n) * Math.PI * 2) * 1.0, 0.75 + 0.1 * Math.sin(t * 0.3 + i), Math.sin(t * 0.18 + (i / n) * Math.PI * 2) * 1.0]
            : [(r(`hx${e.seed}${i}`) - 0.5) * 2.2 + Math.sin(t * 0.1 + i) * 0.2, ((t * 0.05 + r(`hy${e.seed}${i}`) * 2) % 2.5), (r(`hz${e.seed}${i}`) - 0.5) * 1.2];
        return (
          <Billboard key={i} cam={cam} position={pos}>
            <mesh scale={(kind === "stars" ? 0.4 : 0.45) * fade * (e.size ?? 1)}>
              <shapeGeometry args={[kind === "stars" ? starShape : heartShape]} />
              <meshBasicMaterial color={e.color ?? (kind === "stars" ? "#ffe14d" : "#ff4f7a")} side={DoubleSide} transparent depthWrite={false} />
            </mesh>
          </Billboard>
        );
      })}
    </group>
  );
};

/** Altura/posição padrão de cada efeito em relação ao ator. */
const anchorFor = (type: FxSpec["type"], a: ActorPos[string]): V3 => {
  const f = (a.face * Math.PI) / 180;
  const fw = (d: number): [number, number] => [Math.sin(f) * d, Math.cos(f) * d];
  const s = a.scale;
  switch (type) {
    case "dust":
    case "smoke":
      return [a.x, a.y, a.z];
    case "impact": {
      const [dx, dz] = fw(1.9 * s);
      return [a.x + dx, a.y + 3.4 * s, a.z + dz];
    }
    case "energy_purple":
    case "energy_blue": {
      const [dx, dz] = fw(2.1 * s);
      return [a.x + dx, a.y + 3.3 * s, a.z + dz];
    }
    case "hearts":
    case "stars":
    case "sparkle":
      return [a.x, a.y + 4.8 * s, a.z];
    case "confetti":
      return [a.x, 0, a.z];
    default:
      return [a.x, a.y + 3 * s, a.z];
  }
};

export const FxLayer: React.FC<{ shot: Shot; local: number; actors: ActorPos; cam: V3 }> = ({ shot, local, actors, cam }) => {
  const list = useMemo(() => (shot.fx ?? []).filter((e) => e.type !== "speedlines"), [shot]);
  return (
    <>
      {list.map((e, i) => {
        if (local < e.at || local >= e.until) return null;
        const t = local - e.at;
        const a = e.on ? actors[e.on] : undefined;
        const base: V3 = a ? anchorFor(e.type, a) : e.pos ?? [0, 3, 0];
        const p: V3 = a && e.pos ? [base[0] + e.pos[0], base[1] + e.pos[1], base[2] + e.pos[2]] : base;
        const key = `${shot.id}-${i}`;
        switch (e.type) {
          case "dust":
            return <Dust key={key} e={e} t={t} p={p} />;
          case "smoke":
            return <Dust key={key} e={e} t={t} p={p} dark />;
          case "sparkle":
            return <Sparkle key={key} e={e} t={t} p={p} cam={cam} />;
          case "confetti":
            return <Confetti key={key} e={e} t={t} p={p} />;
          case "energy_purple":
            return <Energy key={key} e={e} t={t} p={p} color="#a33dff" glow="#d79bff" />;
          case "energy_blue":
            return <Energy key={key} e={e} t={t} p={p} color="#2f8dff" glow="#9fd8ff" />;
          case "impact":
            return <Impact key={key} e={e} t={t} p={p} cam={cam} />;
          case "hearts":
          case "stars":
            return <Floaters key={key} e={e} t={t} p={p} cam={cam} kind={e.type} />;
          default:
            return null;
        }
      })}
    </>
  );
};
