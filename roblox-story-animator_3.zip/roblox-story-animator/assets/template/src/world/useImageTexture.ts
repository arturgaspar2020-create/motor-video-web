import { useThree } from "@react-three/fiber";
import { useEffect, useState } from "react";
import { cancelRender, continueRender, delayRender, staticFile } from "remotion";
import { SRGBColorSpace, TextureLoader, type Texture } from "three";

// Carrega uma imagem de public/ como textura, segurando o render até carregar (e forçando o desenho).
const cache = new Map<string, Promise<Texture>>();
export const useImageTexture = (src?: string) => {
  const advance = useThree((s) => s.advance);
  const [tex, setTex] = useState<Texture | null>(null);
  const [handle] = useState(() => (src ? delayRender(`Carregando textura ${src}`) : null));
  useEffect(() => {
    if (!src) return;
    if (!cache.has(src)) {
      cache.set(src, new Promise((res, rej) => new TextureLoader().load(staticFile(src), (t) => { t.colorSpace = SRGBColorSpace; t.anisotropy = 4; res(t); }, undefined, rej)));
    }
    cache.get(src)!.then(setTex).catch((e) => cancelRender(new Error(`Falha ao carregar ${src}: ${e}`)));
  }, [src]);
  useEffect(() => {
    if (tex && handle !== null) {
      advance(performance.now());
      continueRender(handle);
    }
  }, [tex, handle, advance]);
  return tex;
};
