import { useThree } from "@react-three/fiber";
import { useLayoutEffect } from "react";
import { random } from "remotion";
import type { PerspectiveCamera } from "three";
import { HEAD_Y } from "../character/BlockyCharacter";
import type { ActorFrame } from "../character/actorState";
import type { CameraSpec, Shot, Vec3 } from "../types";

// Câmera "de diretor": cada corte (shot.cuts) escolhe um tipo de plano em relação a um ator
// e um movimento. Nunca fica parada (micro-deriva + tremor de mão), e os movimentos rápidos
// (punch, crash) dão a energia de edição dos vídeos de referência.

export type CamPose = { position: Vec3; target: Vec3; fov: number; roll: number };

const easeOut = (t: number) => 1 - Math.pow(1 - Math.min(1, Math.max(0, t)), 3);
const easeInOut = (t: number) => {
  const c = Math.min(1, Math.max(0, t));
  return c < 0.5 ? 4 * c * c * c : 1 - Math.pow(-2 * c + 2, 3) / 2;
};

/** Centro da cabeça no mundo (considera tombo, salto e escala). */
export const headOf = (a: ActorFrame, scale = 1): Vec3 => {
  // cabeça no referencial do tronco (pivô no quadril, y=2), depois tombo do corpo (rootX), escala e direção
  const tx = a.joints.torsoX;
  const neck = HEAD_Y - 2;
  const py = 2 + neck * Math.cos(tx);
  const pz = neck * Math.sin(tx);
  const rx = a.joints.rootX;
  const ly = (py * Math.cos(rx) - pz * Math.sin(rx) + a.joints.rootY) * scale;
  const lz = (py * Math.sin(rx) + pz * Math.cos(rx)) * scale;
  const s = Math.sin(a.faceRad);
  const c = Math.cos(a.faceRad);
  return [a.x + lz * s, a.y + ly, a.z + lz * c];
};

const FRAMING: Record<string, { d: number; dy: number; el: number; fov?: number }> = {
  extreme_close: { d: 3.3, dy: -0.05, el: 0, fov: 36 },
  close: { d: 5.6, dy: -0.45, el: 3 },
  medium: { d: 8.6, dy: -1.2, el: 5 },
  full: { d: 12, dy: -2.0, el: 7 },
  wide: { d: 21, dy: -2.2, el: 14 },
  establishing: { d: 34, dy: -2.5, el: 24 },
  low: { d: 5.6, dy: -0.4, el: -30 },
  high: { d: 10, dy: -1.5, el: 55 },
  top: { d: 15, dy: -3, el: 84 },
};

const sph = (t: Vec3, d: number, az: number, el: number): Vec3 => [
  t[0] + d * Math.sin(az) * Math.cos(el),
  t[1] + d * Math.sin(el),
  t[2] + d * Math.cos(az) * Math.cos(el),
];

export const cameraPose = (shot: Shot, local: number, actors: Record<string, { frame: ActorFrame; scale: number }>): CamPose => {
  const cuts = shot.cuts.length ? shot.cuts : [{ at: 0, camera: { type: "wide" } as CameraSpec }];
  let ci = 0;
  for (let i = 0; i < cuts.length; i++) if (cuts[i].at <= local) ci = i;
  const cut = cuts[ci];
  const cutEnd = ci + 1 < cuts.length ? cuts[ci + 1].at : shot.duration;
  const tf = local - cut.at;
  const p = tf / Math.max(1, cutEnd - cut.at);
  const spec = cut.camera;
  const first = Object.keys(actors)[0];
  const on = actors[spec.on ?? first];
  const other = spec.from ? actors[spec.from] : undefined;
  const fallback: Vec3 = [0, 3, 0];
  const head = on ? headOf(on.frame, on.scale) : fallback;
  const faceAz = on ? on.frame.faceRad : 0;
  const k = on ? on.scale : 1;
  // closes precisam mostrar o rosto: ângulo limitado a ±35° da frente do ator
  const faceShot = spec.type === "close" || spec.type === "extreme_close" || spec.type === "low";
  const angle = faceShot ? Math.max(-35, Math.min(35, spec.angle ?? 0)) : (spec.angle ?? 0);
  const az0 = faceAz + (angle * Math.PI) / 180;

  let position: Vec3;
  let target: Vec3;
  let fov = 40;

  if (spec.type === "pov_up") {
    position = [head[0], head[1] + 0.2, head[2]];
    target = [head[0] + Math.sin(az0) * 2, head[1] + 12, head[2] + Math.cos(az0) * 2 - 4];
    fov = 55;
  } else if (spec.type === "ots" && other) {
    const oh = headOf(other.frame, other.scale);
    const dx = head[0] - oh[0];
    const dz = head[2] - oh[2];
    const len = Math.hypot(dx, dz) || 1;
    const ux = dx / len;
    const uz = dz / len;
    // atrás do ombro de "from", deslocado para o lado, olhando para "on"
    position = [oh[0] - ux * 2.8 - uz * 1.3, oh[1] + 0.35, oh[2] - uz * 2.8 + ux * 1.3];
    target = [head[0], head[1] - 0.3, head[2]];
    fov = 38;
  } else if (spec.type === "two" && other) {
    const oh = headOf(other.frame, other.scale);
    const mid: Vec3 = [(head[0] + oh[0]) / 2, (head[1] + oh[1]) / 2 - 1.0, (head[2] + oh[2]) / 2];
    const sep = Math.hypot(head[0] - oh[0], head[2] - oh[2]);
    const lineAz = Math.atan2(oh[0] - head[0], oh[2] - head[2]);
    const az = lineAz + Math.PI / 2 + ((spec.angle ?? 0) * Math.PI) / 180;
    const d = Math.max(9, sep * 2.4);
    position = sph(mid, d, az, (8 * Math.PI) / 180);
    target = mid;
  } else {
    const F = FRAMING[spec.type] ?? FRAMING.medium;
    target = [head[0], head[1] + F.dy * k, head[2]];
    let d = F.d * k;
    let az = az0;
    let el = (F.el * Math.PI) / 180;
    fov = F.fov ?? 40;
    const mv = spec.move ?? "hold";
    if (mv === "push") d *= 1 - 0.24 * easeInOut(p);
    if (mv === "pull") d *= 0.78 + 0.3 * easeInOut(p);
    if (mv === "orbit") az += ((20 * Math.PI) / 180) * easeInOut(p);
    if (mv === "pan") az += ((10 * Math.PI) / 180) * (p - 0.5);
    if (mv === "tilt_up") {
      el = (-18 * Math.PI) / 180 + ((26 * Math.PI) / 180) * easeInOut(p);
      target = [target[0], target[1] + 3 * easeInOut(p), target[2]];
    }
    if (mv === "punch") d *= 1 + 0.6 * (1 - easeOut(tf / 6));
    if (mv === "crash") d *= 2.3 - 1.45 * easeOut(tf / 8);
    if (mv === "hold" || mv === "shake") {
      d *= 1 - 0.04 * p;
      az += ((3 * Math.PI) / 180) * p;
    }
    position = sph(target, d, az, el);
    if (mv === "dolly") {
      const side = 2.2 * (p - 0.5);
      position = [position[0] + Math.cos(az) * side, position[1], position[2] - Math.sin(az) * side];
    }
  }

  position = avoidCollisions(position, target, actors, shot.set, spec.type === "ots" ? spec.from : undefined);

  // tremor de mão sempre presente + tremor forte opcional (sustos, quedas, gritos)
  const amp = 0.025 + (spec.move === "shake" ? 0.22 : 0) + (spec.shake ?? 0) * 0.3;
  const n = (s: string) => Math.sin(local * 0.37 + random(s) * 10) * 0.6 + Math.sin(local * 1.13 + random(s + "b") * 10) * 0.4;
  const jitter = spec.move === "shake" || (spec.shake ?? 0) > 0 ? (random(`j${shot.id}${local}`) - 0.5) * amp * 1.6 : 0;
  position = [position[0] + n("x") * amp + jitter, position[1] + n("y") * amp, position[2] + n("z") * amp * 0.5];
  return { position, target, fov, roll: ((spec.dutch ?? 0) * Math.PI) / 180 };
};

// Limites internos dos cenários fechados (paredes): a câmera nunca sai da sala nem entra na parede.
const ROOM: Partial<Record<string, { x: number; zMin: number; yMax: number }>> = {
  bedroom: { x: 8.4, zMin: -7.4, yMax: 10.5 },
  livingroom: { x: 9.4, zMin: -8.4, yMax: 11.5 },
  classroom: { x: 10.4, zMin: -10.4, yMax: 10.5 },
};

/**
 * Evita a câmera dentro de outros personagens (aproxima do alvo até sair do corpo) e dentro das paredes.
 * `ignore` = ator por cima de cujo ombro a câmera olha (OTS).
 */
const avoidCollisions = (pos: Vec3, target: Vec3, actors: Record<string, { frame: ActorFrame; scale: number }>, set: string, ignore?: string): Vec3 => {
  let p: Vec3 = [...pos];
  const inside = (q: Vec3) =>
    Object.entries(actors).some(([id, a]) => {
      if (id === ignore) return false;
      const r = 1.75 * a.scale;
      const top = a.frame.y + (a.frame.joints.rootX < -1 ? 1.2 : 5.5 * a.scale);
      return Math.hypot(q[0] - a.frame.x, q[2] - a.frame.z) < r && q[1] < top + 0.3;
    });
  for (let i = 0; i < 24 && inside(p); i++) {
    // desliza para perto do alvo (não atravessa o próprio alvo: para a 1,6 u dele)
    const d = Math.hypot(p[0] - target[0], p[1] - target[1], p[2] - target[2]);
    if (d < 1.6) break;
    const k = Math.max(1.6, d - 0.45) / d;
    p = [target[0] + (p[0] - target[0]) * k, target[1] + (p[1] - target[1]) * k, target[2] + (p[2] - target[2]) * k];
  }
  const room = ROOM[set];
  if (room) {
    p = [Math.max(-room.x, Math.min(room.x, p[0])), Math.max(0.4, Math.min(room.yMax, p[1])), Math.max(room.zMin, p[2])];
  } else {
    p = [p[0], Math.max(0.35, p[1]), p[2]];
  }
  return p;
};

export const ApplyCamera: React.FC<{ pose: CamPose }> = ({ pose }) => {
  const camera = useThree((st) => st.camera) as PerspectiveCamera;
  useLayoutEffect(() => {
    camera.position.set(...pose.position);
    camera.fov = pose.fov;
    camera.near = 0.1;
    camera.far = 900;
    camera.up.set(0, 1, 0);
    camera.lookAt(...pose.target);
    if (pose.roll) camera.rotateZ(pose.roll);
    camera.updateProjectionMatrix();
  }, [camera, pose]);
  return null;
};
