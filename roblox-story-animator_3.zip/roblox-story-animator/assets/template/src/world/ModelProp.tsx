import type { PropSpec } from "../types";
import { GlbModel } from "./GlbModel";

// Modelo .glb parado no cenário (public/models/...). Licença obrigatória no story.json.
// Nunca use assets da Creator Store/Marketplace de terceiros sem permissão explícita do autor.
export const ModelProp: React.FC<{ spec: PropSpec }> = ({ spec }) => (
  <group position={[spec.x, spec.y ?? 0, spec.z]} rotation={[0, ((spec.rot ?? 0) * Math.PI) / 180, 0]} scale={spec.scale ?? 1}>
    <GlbModel spec={{ src: spec.src, height: spec.height, anchor: "base", parts: spec.parts, hideParts: spec.hideParts, tint: spec.tint }} />
  </group>
);
