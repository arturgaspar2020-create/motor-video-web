import { Audio } from "@remotion/media";
import { Sequence, staticFile } from "remotion";
import { TL } from "../timeline";

// Voz (prioridade), efeitos por plano e trilha que abaixa sob a voz (sidechain por volume).
// Só toca o que existe: falas com hasAudio; trilha se hasMusic (gerada por scripts/music_story.py).

const MUSIC = { base: 0.42, ducked: 0.14, ramp: 6 };
const voiceWindows = TL.shots.filter((s) => s.line?.hasAudio).map((s) => [s.start + s.line!.at, s.start + s.line!.at + s.line!.frames] as const);

const musicVolume = (f: number) => {
  let duck = 0;
  for (const [a, b] of voiceWindows) {
    const d = Math.min(Math.max(0, (f - (a - MUSIC.ramp)) / MUSIC.ramp), Math.max(0, (b + MUSIC.ramp * 2 - f) / (MUSIC.ramp * 2)), 1);
    duck = Math.max(duck, d);
  }
  const fadeOut = Math.min(1, Math.max(0, (TL.totalFrames - f) / 30));
  const fadeIn = Math.min(1, f / 8);
  return (MUSIC.base - (MUSIC.base - MUSIC.ducked) * duck) * fadeOut * fadeIn;
};

export const Soundtrack: React.FC = () => (
  <>
    {TL.hasMusic ? <Audio name="Trilha" src={staticFile("audio/music.wav")} volume={musicVolume} /> : null}
    {TL.shots.map((s) => (
      <Sequence key={s.id} name={`Áudio · ${s.id}`} from={s.start} layout="none">
        {s.line?.hasAudio ? (
          <Sequence from={s.line.at} layout="none" name={`voz · ${s.line.by}`}>
            <Audio src={staticFile(`audio/vo/${s.line.voKey}.wav`)} volume={1} />
          </Sequence>
        ) : null}
        {s.ambience ? (
          <Sequence durationInFrames={s.duration} layout="none" name={`ambiente · ${s.ambience.file}`}>
            <Audio src={staticFile(s.ambience.file)} loop volume={(f) => s.ambience!.volume * Math.min(1, f / 6, (s.duration - f) / 6)} />
          </Sequence>
        ) : null}
        {s.sfx.map((c, i) => (
          <Sequence key={i} from={Math.max(0, c.at)} layout="none" name={`sfx · ${c.name}`}>
            <Audio src={staticFile(c.file ?? `audio/sfx/${c.name}.wav`)} volume={c.volume} />
          </Sequence>
        ))}
      </Sequence>
    ))}
  </>
);
