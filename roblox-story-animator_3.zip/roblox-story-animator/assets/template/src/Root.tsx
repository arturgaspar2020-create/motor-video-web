import { Composition } from "remotion";
import { Main } from "./Main";
import { TL } from "./timeline";

export const RemotionRoot: React.FC = () => (
  <Composition id="RobloxStory" component={Main} durationInFrames={TL.totalFrames} fps={TL.fps} width={TL.width} height={TL.height} />
);
