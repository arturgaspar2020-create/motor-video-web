import lipsyncJson from "./data/lipsync.json";
import timelineJson from "./data/timeline.json";
import type { Shot, Timeline } from "./types";

// Fonte única de verdade do vídeo. timeline.json é gerado por scripts/build_timeline.py
// a partir de story.json + vo.json (voz real). lipsync.json vem de scripts/lipsync.py.

export const TL = timelineJson as unknown as Timeline;
const LIPSYNC = lipsyncJson as unknown as Record<string, number[]>;

// Verificação de integridade ao importar: planos contíguos começando em 0 e soma exata.
(() => {
  let cursor = 0;
  for (const s of TL.shots) {
    if (s.start !== cursor) throw new Error(`timeline: plano ${s.id} começa em ${s.start}, esperado ${cursor}`);
    if (!Number.isInteger(s.duration) || s.duration <= 0) throw new Error(`timeline: duração inválida em ${s.id}`);
    cursor += s.duration;
  }
  if (cursor !== TL.totalFrames) throw new Error(`timeline: soma ${cursor} != totalFrames ${TL.totalFrames}`);
})();

export const shotIndexAt = (frame: number) => {
  let lo = 0;
  let hi = TL.shots.length - 1;
  while (lo < hi) {
    const mid = (lo + hi + 1) >> 1;
    if (TL.shots[mid].start <= frame) lo = mid;
    else hi = mid - 1;
  }
  return lo;
};

export const shotAt = (frame: number): { shot: Shot; local: number; index: number } => {
  const index = shotIndexAt(frame);
  const shot = TL.shots[index];
  return { shot, local: frame - shot.start, index };
};

/** Abertura de boca 0–1 do ator `actorId` no frame local do plano (só se ele estiver falando). */
export const mouthOpen = (shot: Shot, actorId: string, local: number) => {
  const line = shot.line;
  if (!line || line.by !== actorId) return 0;
  const i = local - line.at;
  if (i < 0 || i >= line.frames) return 0;
  const env = LIPSYNC[line.voKey];
  if (env && env.length) return env[Math.min(env.length - 1, i)] ?? 0;
  // sem áudio medido (prévia): abre e fecha nas palavras
  const w = line.words.find((x) => i >= x.start && i < x.end);
  if (!w) return 0;
  const p = (i - w.start) / Math.max(1, w.end - w.start);
  return Math.sin(p * Math.PI) * 0.8;
};

export const isSpeaking = (shot: Shot, actorId: string, local: number) =>
  !!shot.line && shot.line.by === actorId && local >= shot.line.at && local < shot.line.at + shot.line.frames;
