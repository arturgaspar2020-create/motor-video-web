import { Config } from "@remotion/cli/config";

Config.setVideoImageFormat("jpeg");
Config.setOverwriteOutput(true);
// Three.js precisa de WebGL no Chrome headless: "angle" usa a GPU; em máquinas sem GPU use --gl=swangle.
Config.setChromiumOpenGlRenderer("angle");
