# Skins (camisa + calça)

`skins.json` lista cada par: id, gênero (F, M ou U = masculina e feminina), idade (adulto/crianca), tom de pele,
cor, profissão (`role`) e a cor de pele usada na cabeça (`skin_color`, medida na própria skin).
A camisa NN só é usada com a calça NN. Imagens reduzidas para 1024×1024 (camisa) e 1024×512 (calça), mesmo molde.

- 01–24, 25-infantil, 25-policial, 26–31: skins do usuário (nomes dos arquivos originais em `source_files`;
  o 25 tinha dois pares diferentes e virou `25-infantil` e `25-policial`).
- 01–08 e 12 (mulher adulta) são corpetes com decote (`style: "decote"`): o story_check bloqueia em histórias
  com crianças.
- 32–35: geradas pela skill (`scripts/make_modest_skins.py`) para mães/mulheres em histórias familiares —
  blusa + jeans ou vestido. Pode substituí-las por skins pintadas por você com os mesmos ids.

Para adicionar: coloque `NN/camisa.jpg` e `NN/calca.jpg` e uma entrada no `skins.json`.
