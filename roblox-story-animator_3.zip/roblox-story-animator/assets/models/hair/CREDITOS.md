# Cabelos 3D

- `ponytail.glb` — "Voluminous Long Ponytail (With Bones)" por zHairezt — https://sketchfab.com/3d-models/voluminous-long-ponytail-with-bones-026293212cd8408a929f6533ed39b5c9 — CC BY 4.0. Enviado pelo usuário. Crédito obrigatório na descrição do vídeo quando usado (`look.hair: "ponytail"`).

Os demais estilos (short, side, buzz, spiky, curly, afro, bob, long, bun, pigtails) são malhas geradas pelo motor (domo + mechas), sem licença de terceiros.
