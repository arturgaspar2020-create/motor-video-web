# Texturas

Enviadas pelo usuário (pasta `Downloads\texturas`, originais 4K) e reduzidas para 1024×1024 JPEG em 01/11/2026.
A maioria dos nomes coincide com texturas do Poly Haven (polyhaven.com, licença CC0), mas a origem de cada
arquivo não foi conferida pelo agente — confirme antes de publicar. `piso_de_madeira_cartoon_em_tons_quentes`
tem nome em português (provavelmente gerada/feita pelo usuário).

Uso no motor: `world/Textured.tsx` (`TexBox`, `TexGround`, `TexStrip`) e os pisos dos cenários em `world/Sets.tsx`.
