# Créditos dos sons incluídos na skill

Todos baixados do OpenGameArt.org (licença conferida na página de cada pacote em 01/11/2026), recortados (sem silêncio inicial) e normalizados.

## OpenGameArt "100 CC0 SFX" (rubberduck) — CC0
https://opengameart.org/content/100-cc0-sfx

aterrissagem_01, aterrissagem_02, chave_abrir_01, chave_abrir_02, estranho_01, estranho_02, estranho_03, explosao_01, ferramenta_01, ferramenta_02, gongo_01, gongo_02, interruptor_01, interruptor_02, louca_01, louca_02, madeira_batida_03, metal_batida_02, metal_batida_03, mola_01, mola_02, papel_01, papel_02, ploft_01, ploft_02, porta_abrir, porta_bater_01, porta_bater_02, porta_bater_03, pulo_01, pulo_02, pulo_03, queda_corpo_01, queda_corpo_02, queda_corpo_03, respingo_01, respingo_02, sino_01, sino_02, sino_03, soco_01, soco_02, soco_03, tiro_brinquedo_01, tiro_brinquedo_02, vidro_quebrar_01, vidro_quebrar_02

## OpenGameArt "100 CC0 SFX #2" (rubberduck) — CC0
https://opengameart.org/content/100-cc0-sfx-2

ambiente_agua, ambiente_dia_rua, ambiente_obra, aterrissagem_03, madeira_batida_01, madeira_batida_02, metal_batida_01, passo_agua_01, passo_agua_02, passo_agua_03, passo_concreto_02, passo_concreto_03, passo_madeira_04, passo_madeira_05, soco_04, soco_05, tapa_01, trovao_01, vidro_quebrar_03

## OpenGameArt "Different steps on wood, stone, leaves, gravel and mud" (TinyWorlds) — CC0
https://opengameart.org/content/different-steps-on-wood-stone-leaves-gravel-and-mud

passo_concreto_01, passo_grama_01, passo_grama_02, passo_madeira_01, passo_madeira_02, passo_madeira_03, passo_terra_01, passo_terra_02

## OpenGameArt "Footsteps on different surfaces", por congusbongus, derivado de gravações de swuing (freesound.org/people/swuing) — CC-BY 3.0 (crédito obrigatório)
https://opengameart.org/content/footsteps-on-different-surfaces

passo_asfalto_01, passo_asfalto_02, passo_asfalto_03, passo_asfalto_04, passo_asfalto_05, passo_concreto_04, passo_concreto_05, passo_grama_03, passo_grama_04, passo_grama_05, passo_metal_01, passo_metal_02, passo_metal_03, passo_piso_01, passo_piso_02, passo_piso_03, passo_piso_04, passo_piso_05, passo_terra_03, passo_terra_04, passo_terra_05

**CC-BY 3.0:** se usar os arquivos marcados como CC-BY num vídeo publicado, coloque na descrição:
"Sons de passos: congusbongus / swuing (CC-BY 3.0), OpenGameArt.org".
Os demais (CC0) não exigem crédito.