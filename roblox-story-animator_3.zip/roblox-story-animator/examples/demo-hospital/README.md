# Exemplo: "O Assalto da Vacina" (01/11/2026)

História original de ~33 s no hospital: mães (skins 32 e 34), crianças (14 e 21), médicos (28 e 29),
ladrão (27), policial (26) e o Gojo (modelo próprio). Testa skins, cabelos 3D, paleta de vozes, partículas
(sparkle, dust, energy_blue, impact + linhas de velocidade, stars, hearts, confetti), poses punch/land/jump,
textura de piso e sons da biblioteca (soco, queda_corpo, aterrissagem, porta_abrir, sino).

Renderizado com o pipeline completo (1080×1920, 30 fps). Este arquivo foi recomprimido (crf 30) para caber
na skill. Gojo com a venda (`"rig": {"hideUV": []}`) e a fala com a voz real do usuário (gerada no fish.audio e importada com `import_voice.py`).
