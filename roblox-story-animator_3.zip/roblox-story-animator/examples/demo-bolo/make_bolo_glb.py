"""Gera models/bolo.glb (bolo low-poly usado no exemplo; licença: própria, gerado por código).
Uso: python -m pip install trimesh && python make_bolo_glb.py"""
import numpy as np
import trimesh


def colored(m, rgb):
    m.visual.face_colors = np.array(list(rgb) + [255], dtype=np.uint8)
    return m


parts = [colored(trimesh.creation.cylinder(radius=1.5, height=0.15, sections=32), (240, 240, 250))]
for r, h, z, c in [(1.2, 0.7, 0.42, (140, 80, 50)), (1.25, 0.18, 0.85, (255, 250, 240)), (0.85, 0.55, 1.2, (255, 120, 170))]:
    m = colored(trimesh.creation.cylinder(radius=r, height=h, sections=32), c)
    m.apply_translation([0, 0, z])
    parts.append(m)
cherry = colored(trimesh.creation.icosphere(subdivisions=2, radius=0.22), (220, 30, 40))
cherry.apply_translation([0, 0, 1.65])
cake = trimesh.util.concatenate(parts + [cherry])
cake.apply_transform(trimesh.transformations.rotation_matrix(-np.pi / 2, [1, 0, 0]))  # z-up -> y-up (glTF)
cake.export("models/bolo.glb")
print("models/bolo.glb", cake.bounds.tolist())
