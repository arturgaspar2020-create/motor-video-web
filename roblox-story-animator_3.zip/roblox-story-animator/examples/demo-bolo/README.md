# Exemplo: "Quem comeu o bolo?" (teste do motor)

> Atualizado em 01/11/2026 para o formato com skins (camisa+calça do catálogo). O vídeo antigo foi removido; o exemplo renderizado atual é `examples/demo-hospital/`.

História curta original (~19 s) usada para testar todas as funções da skill em 30/10/2026:
4 vozes Edge diferentes (narrador, Téo, Duda, Vovó Nena), lip-sync, 11 expressões, 11 poses,
14 enquadramentos (média 1,34 s), câmeras wide/full/close/extreme_close/ots/two/high com
push/punch/crash/dolly/shake/orbit/pull, 12 efeitos, trilha com 5 climas, flash, prop .glb próprio
(`models/bolo.glb`, gerado por `make_bolo_glb.py`, licença própria).

Reproduzir:
```bash
python ../../scripts/setup_project.py ./bolo --story story.json
cd bolo && python scripts/cast_voiceover.py story.json && python scripts/prepare_vo.py && python scripts/lipsync.py \
  && python scripts/sfx_story.py && python scripts/build_timeline.py story.json && python scripts/music_story.py \
  && npx remotion render src/index.ts RobloxStory out/bolo-raw.mp4 --gl=angle --crf=18 \
  && python scripts/loudnorm.py out/bolo-raw.mp4 out/bolo.mp4
```
