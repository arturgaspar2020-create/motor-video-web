# Vozes

## Paleta pronta (assets/voices.json) — use o id em `"voice"`

48 vozes: português e inglês, 6 de cada tipo (homem, mulher, menina, menino). Testadas em 01/11/2026: todas
sintetizaram a frase de teste; F0 = tom médio medido (Hz). **Ninguém ouviu** — confira com `--preview-voices`.
Vozes de criança: só en-US-Ana e en-GB-Maisie são infantis de verdade; as outras são vozes adultas com tom
mais alto e, nos meninos, `shift` (semitons aplicados depois pelo ffmpeg, mesma duração, timbre mais jovem).
Vozes "Multilingual" lendo português podem ter sotaque. Duas personagens nunca com o mesmo id.

| id | voz Edge | rate | pitch | F0 | uso |
| --- | --- | --- | --- | --- | --- |
| `pt_homem_1` | pt-BR-AntonioNeural | +6% | +0Hz | 208 | homem adulto BR, neutro |
| `pt_homem_2` | pt-BR-AntonioNeural | -6% | -12Hz | 186 | homem adulto BR, grave e lento (pai, chefe, vilão) |
| `pt_homem_3` | pt-PT-DuarteNeural | +4% | +0Hz | 107 | homem adulto, sotaque de Portugal |
| `pt_homem_4` | en-US-AndrewMultilingualNeural | +6% | +0Hz | 105 | homem adulto, caloroso (leve sotaque) |
| `pt_homem_5` | en-US-BrianMultilingualNeural | +8% | -4Hz | 130 | homem adulto, descontraído (leve sotaque) |
| `pt_homem_6` | de-DE-FlorianMultilingualNeural | +4% | -6Hz | 157 | homem adulto, firme (sotaque estrangeiro) |
| `pt_mulher_1` | pt-BR-FranciscaNeural | +6% | +0Hz | 273 | mulher adulta BR, neutra |
| `pt_mulher_2` | pt-BR-FranciscaNeural | -4% | -14Hz | 248 | mulher adulta BR, madura e calma (mãe, médica) |
| `pt_mulher_3` | pt-PT-RaquelNeural | +4% | +0Hz | 207 | mulher adulta, sotaque de Portugal |
| `pt_mulher_4` | pt-BR-ThalitaMultilingualNeural | +6% | +0Hz | 214 | mulher adulta BR, jovem (às vezes falha: o script tenta de novo) |
| `pt_mulher_5` | en-US-AvaMultilingualNeural | +6% | +0Hz | 216 | mulher adulta, expressiva (leve sotaque) |
| `pt_mulher_6` | en-US-EmmaMultilingualNeural | +8% | +0Hz | 219 | mulher adulta, alegre (leve sotaque) |
| `pt_menina_1` | pt-BR-FranciscaNeural | +10% | +45Hz | 358 | menina BR |
| `pt_menina_2` | pt-BR-FranciscaNeural | +14% | +70Hz | 401 | menina BR pequena, bem aguda |
| `pt_menina_3` | pt-PT-RaquelNeural | +10% | +50Hz | 285 | menina, sotaque de Portugal |
| `pt_menina_4` | pt-BR-ThalitaMultilingualNeural | +10% | +45Hz | 284 | menina BR |
| `pt_menina_5` | en-US-EmmaMultilingualNeural | +12% | +50Hz | 290 | menina (leve sotaque) |
| `pt_menina_6` | fr-FR-VivienneMultilingualNeural | +10% | +85Hz | 269 | menina (sotaque estrangeiro) |
| `pt_menino_1` | pt-BR-AntonioNeural | +12% | +70Hz | 280 | menino BR |
| `pt_menino_2` | pt-BR-FranciscaNeural | +12% | +15Hz | 301 | menino BR pequeno (voz infantil neutra) |
| `pt_menino_3` | pt-PT-DuarteNeural | +12% | +20Hz · +9 st | 207 | menino, sotaque de Portugal |
| `pt_menino_4` | en-US-BrianMultilingualNeural | +12% | +20Hz · +7 st | 226 | menino (leve sotaque) |
| `pt_menino_5` | en-US-AndrewMultilingualNeural | +12% | +20Hz · +9 st | 213 | menino (leve sotaque) |
| `pt_menino_6` | pt-PT-RaquelNeural | +12% | +45Hz | 279 | menino pequeno, sotaque de Portugal |
| `en_man_1` | en-US-GuyNeural | +4% | +0Hz | 170 | adult man US, energetic |
| `en_man_2` | en-US-ChristopherNeural | -4% | -6Hz | 102 | adult man US, deep, authority |
| `en_man_3` | en-US-EricNeural | +4% | +0Hz | 109 | adult man US, calm |
| `en_man_4` | en-US-RogerNeural | +6% | +0Hz | 167 | adult man US, lively |
| `en_man_5` | en-GB-RyanNeural | +4% | +0Hz | 136 | adult man UK |
| `en_man_6` | en-AU-WilliamMultilingualNeural | +4% | +0Hz | 111 | adult man AU |
| `en_woman_1` | en-US-JennyNeural | +4% | +0Hz | 199 | adult woman US, friendly |
| `en_woman_2` | en-US-AriaNeural | +4% | +0Hz | 221 | adult woman US, confident |
| `en_woman_3` | en-US-MichelleNeural | +2% | -6Hz | 182 | adult woman US, warm (mom) |
| `en_woman_4` | en-GB-SoniaNeural | +4% | +0Hz | 223 | adult woman UK |
| `en_woman_5` | en-US-EmmaNeural | +4% | +0Hz | 171 | adult woman US, cheerful |
| `en_woman_6` | en-IE-EmilyNeural | +4% | +0Hz | 190 | adult woman Irish |
| `en_girl_1` | en-US-AnaNeural | +4% | +0Hz | 302 | girl US (native child voice) |
| `en_girl_2` | en-GB-MaisieNeural | +4% | +0Hz | 330 | girl UK (native child voice) |
| `en_girl_3` | en-US-AnaNeural | +10% | +25Hz | 353 | little girl US, very high |
| `en_girl_4` | en-US-JennyNeural | +10% | +50Hz | 260 | girl US |
| `en_girl_5` | en-GB-LibbyNeural | +10% | +50Hz | 276 | girl UK |
| `en_girl_6` | en-CA-ClaraNeural | +10% | +50Hz | 269 | girl CA |
| `en_boy_1` | en-US-AnaNeural | +6% | -25Hz | 251 | boy US (child voice, lowered) |
| `en_boy_2` | en-GB-MaisieNeural | +6% | -25Hz | 274 | boy UK (child voice, lowered) |
| `en_boy_3` | en-US-RogerNeural | +12% | +75Hz | 251 | boy US |
| `en_boy_4` | en-US-BrianNeural | +12% | +20Hz · +7 st | 227 | boy US |
| `en_boy_5` | en-GB-ThomasNeural | +12% | +20Hz · +7 st | 236 | boy UK |
| `en_boy_6` | en-CA-LiamNeural | +12% | +20Hz · +8 st | 209 | boy CA |

## Padrão gratuito: Edge TTS (`edge-tts`)

Testado nesta skill em 30/10/2026: síntese + tempos por palavra (`WordBoundary`) funcionaram com
`pt-BR-AntonioNeural`, `pt-BR-FranciscaNeural`, `pt-PT-DuarteNeural`, `en-US-AndrewMultilingualNeural`,
`en-US-EmmaMultilingualNeural` e `fr-FR-RemyMultilingualNeural` (com `pitch`). `pt-BR-ThalitaMultilingualNeural`
respondeu "No audio was received" no teste — evite ou tenha alternativa.
O agente **não ouve** o resultado: sotaque e naturalidade das vozes multilíngues em português não foram
avaliados por ouvido. Ofereça `--preview-voices` para o usuário escutar e escolher.

Vozes nativas pt-BR são poucas, então cada personagem se diferencia por **voz + pitch + rate**:

| Papel | voice | rate | pitch | Observação |
| --- | --- | --- | --- | --- |
| Narrador | pt-BR-AntonioNeural | +6% | +0Hz | mais natural para narração |
| Menino / criança | pt-BR-AntonioNeural | +14% | +40Hz | infantilizado |
| Menina / criança | pt-BR-FranciscaNeural | +10% | +30Hz | |
| Mulher adulta | pt-BR-FranciscaNeural | +2% | +0Hz | |
| Idosa | pt-BR-FranciscaNeural | −6% | −28Hz | lenta e grave |
| Homem grave / vilão | pt-BR-AntonioNeural | −8% | −30Hz | |
| Robô / estranho | pt-PT-DuarteNeural | +0% | −20Hz | sotaque europeu = "estrangeiro" |
| Alternativas | en-US-AndrewMultilingualNeural, en-US-BrianMultilingualNeural, en-US-EmmaMultilingualNeural, en-US-AvaMultilingualNeural, fr-FR-RemyMultilingualNeural, de-DE-FlorianMultilingualNeural, it-IT-GiuseppeMultilingualNeural | | | multilíngues: leem português, possivelmente com sotaque |

Regras: nunca repetir a mesma combinação voice+rate+pitch (o `story_check` bloqueia); pitch entre −35Hz
e +45Hz para não robotizar; encurte o texto em vez de acelerar além de ~+18%.

Ambiente com proxy corporativo: `cast_voiceover.py` respeita `SSL_CERT_FILE` (sem desligar verificação).

## Opcional: ElevenLabs (pago)

Só com pedido e autorização explícita do usuário (custo). Precisa de `ELEVENLABS_API_KEY` no `.env` da raiz
do projeto (nunca imprima a chave) e `eleven_voice` (voice_id) em cada membro do cast. Rodar com
`--provider elevenlabs`; membros sem `eleven_voice` caem no Edge (avisado). Não use vozes clonadas de
pessoas reais nem imitações de vozes de criadores.

## Fala gravada/gerada pelo usuário (arquivo)

Sem chave de API, o usuário pode gerar a fala no site do fish.audio (ou gravar) e mandar o arquivo:
`python scripts/import_voice.py story.json s07 fala.mp3` — corta o silêncio, salva como a voz do plano, calcula
o tempo das palavras pelo trecho com voz e tira a marca de PRÉVIA. Depois: prepare_vo → lipsync → build_timeline
→ music_story → render. Testado em 01/11/2026 com a fala do Gojo do exemplo do hospital.

## Voz própria por personagem: fish.audio

Configuração do preset `gojo` (characters/gojo.json): serviço fish.audio · modelo `s2.1-pro-free` ·
`reference_id` `96a2c896ed7846848cdd83e484b23eb3` · idioma `pt-BR` · saída MP3 128 kbps.

1. **Chave:** `FISH_API_KEY` no `.env` da raiz do projeto (o `setup_project.py` cria o `.env` vazio a partir de
   `.env.example`) ou variável de ambiente. Nunca no código nem no chat; os scripts nunca imprimem o valor.
2. **Verificação sem custo:** `python scripts/fish_check.py` → chave presente?, voz (GET /model/{id}: tts,
   trained, pt, sem DMCA), saldo (GET /wallet/self/api-credit). Nenhum desses gera áudio.
3. **Teste curto (1 frase, modelo grátis):** `python scripts/fish_check.py --tts-test` → salva
   `out/fish_teste.mp3` e compara o saldo antes/depois (avisa se houve cobrança).
4. **Geração:** `cast_voiceover.py` usa `POST /v1/tts/stream/with-timestamp` com cabeçalho `model: s2.1-pro-free`
   e distribui as palavras nos trechos com tempo da API (erro medido ~30–50 ms; sem trechos, pelas pausas:
   média 30–170 ms, máx ~0,4 s). A boca usa o volume real (lipsync).
5. **Alternativa grátis automática:** sem chave ou se a API falhar (rede, 401, 402, 404, 429, 503), a fala sai com
   a voz Edge do preset, marcada PRÉVIA; o `build_timeline` avisa. Erros de conta (401/402/404) desligam o
   fish no resto do lote. `--strict-fish` faz parar em vez de usar o Edge.
6. **Custo:** a API usa o `s2.1-pro` (PAGO) se o cabeçalho `model` vier vazio/desconhecido. Os scripts só
   aceitam `s2.1-pro-free`; outro modelo exige `--allow-paid` (só com autorização do usuário). Para
   personagens fixos, voz e modelo vêm do preset e não podem ser trocados pelo story.

Só use vozes do próprio usuário ou de quem autorizou; nunca clone dubladores/atores sem autorização.
Testado em 31/10/2026 com servidor simulado (sucesso, 402, sem chave, cobrança, modelo pago) e com a API real
(consulta da voz sem chave; chave inválida → 401 tratado). Geração real com chave válida: ainda não executada.
