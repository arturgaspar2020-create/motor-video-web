# Modelos da Roblox (Toolbox / Creator Store): o que dá e o que não dá

Pesquisa feita em 30/10/2026. Não é aconselhamento jurídico.

## O que a documentação oficial diz

- O export **glTF do Roblox Studio** exige permissão: exporta assets enviados pela sua conta/grupo e
  mesh/imagens compartilhados explicitamente com você. **Não exporta** "Avatar Marketplace assets",
  "Acquired Creator Store assets" nem assets públicos (Open Use) não compartilhados explicitamente.
  Fonte: https://create.roblox.com/docs/art/modeling/gltf-export
- Visão geral da Creator Store: https://create.roblox.com/docs/production/creator-store
- No fórum de desenvolvedores, a orientação recorrente (de membros da comunidade, não da equipe Roblox)
  é que publicar na Creator Store dá permissão de uso **dentro de experiências Roblox/Studio**; para usar
  fora da Roblox, peça autorização ao autor.
  Fonte: https://devforum.roblox.com/t/can-free-roblox-marketplace-assets-be-used-outside-roblox/3315235

## Política desta skill

1. **Padrão:** personagens e cenários procedurais originais do motor (bonecos de blocos genéricos). Sem
   logotipo, nome ou interface da Roblox no vídeo.
2. **Modelos importados (`props`)**: só `.glb/.gltf` em `public/models/` com `license` declarada:
   - `own` — criado pelo usuário (inclusive exportado do Studio a partir de criações próprias);
   - `CC0` — domínio público (ex.: Kenney, Quaternius, Poly Pizza CC0);
   - `CC-BY:<autor>` — exige crédito na descrição do vídeo;
   - `permission:<quem>` — autorização escrita do autor.
   O `story_check` rejeita props sem licença. Nunca baixe/extraia assets da Creator Store por ferramentas
   de terceiros ("asset downloaders") para contornar o bloqueio de exportação.
3. **Alternativa dentro da Roblox:** gravar a animação no próprio Roblox Studio (onde os assets da
   Creator Store são permitidos) é outro fluxo — fora do escopo deste motor; se o usuário quiser, explique
   que ele grava no Studio e esta skill pode cuidar de roteiro, vozes, legendas e edição.

## Como importar um modelo próprio

1. No Roblox Studio: selecione o modelo seu → botão direito → "Export Selection" → `.glb`
   (ou exporte do Blender). Prefira < 5 MB, poucas texturas.
2. Copie para `public/models/<nome>.glb` e use como prop (`"height"` para escalar automaticamente)
   ou como acessório preso ao personagem — campos e receitas em `story-format.md` ("Modelos .glb").
3. Formato: baixe sempre **GLB** (o original se for glb; senão o "GLB convertido", textura 1k).
   FBX/USDZ/glTF solto não são lidos. Texturas no formato antigo `KHR_materials_pbrSpecularGlossiness`
   (comum no Sketchfab) são convertidas automaticamente pelo `GlbModel`.

## Personagens e marcas de terceiros

CC-BY do uploader cobre o modelo 3D, **não** o personagem/marca representado (ex.: anime, Halo, Ben 10,
RWBY). Para canal monetizado, avise o usuário do risco de reivindicação e prefira modelos originais/CC0.
