# Padrão de qualidade — análise do vídeo de referência

Fonte: vídeo enviado pelo usuário ("animação roblox", 125 s). Análise feita em 30/10/2026 a partir de
quadros extraídos com FFmpeg (1 quadro a cada 2,5 s, closes em resolução maior, rajada de 5 fps), detecção
automática de cortes (`select='gt(scene,0.3)'`) e medição de loudness. **O áudio não foi ouvido** (o agente
não escuta): o que se diz sobre falas vem das legendas na tela e das medições.

Use isto como **régua de qualidade e ritmo**, nunca como fonte de história, falas, nomes ou personagens.

## Medições

| Item | Valor medido |
| --- | --- |
| Formato | 1080×1920, 60 fps, H.264 + AAC |
| Duração | 125,3 s |
| Cortes detectados | ~78 → **plano médio ≈ 1,6 s** (vários com 0,7–1,2 s nas punchlines) |
| Loudness integrado | ≈ −17 LUFS; trilha contínua (sem silêncios > 0,25 s abaixo de −35 dB) |

Nesta skill: 30 fps (render 2× mais rápido) e enquadramento médio alvo de 1,2–2,2 s.

## Personagens e rostos (o ponto mais importante)

- Bonecos de blocos com proporções R6: pernas e braços retangulares, tronco largo, cabeça cilíndrica
  arredondada. Corpo rígido; **a atuação está no rosto e na postura**.
- **Rostos são decalques 2D sobre a cabeça 3D**, trocados de forma brusca e exagerada a cada beat:
  - risada com boca enorme aberta (dentes brancos em cima, língua vermelha), olhos fechados em "^";
  - olhos esbugalhados brancos com pupila pequena (choque), boca em "o";
  - sobrancelhas grossas inclinadas (raiva/desconfiança);
  - choro com lágrimas em cascata azul e boca aberta de lamento;
  - sorriso de canto, pálpebra caída ("sonso"/convencido);
  - óculos desenhados no rosto.
- A boca **abre e fecha seguindo a fala** (na rajada de 5 fps, a boca muda quadro a quadro durante a frase).
- Exageros de escala: closes extremos em que a cabeça ocupa a tela; chapéus de aba enorme como marca visual.

## Corpo e animação

- Poses legíveis em silhueta: apontar, mãos no rosto, braços abertos, agachar/esconder, subir escada,
  cair deitado no chão, olhar para o céu, aceno.
- Movimentos curtos e secos, entrada rápida na pose (sem muita antecipação), pequenas oscilações de
  respiração; ninguém fica totalmente congelado.

## Câmera e edição

- Alternância constante: close extremo do rosto → plano médio → plano geral do cenário → plongée
  (de cima, personagem pequeno) → contra-plongée (de baixo, céu ao fundo) → ponto de vista olhando o céu.
- Cortes no ritmo da fala: quase toda frase tem 2+ enquadramentos; a punchline cai num corte novo.
- Planos de "respiro" sem personagem (relógio, céu estrelado, fachada) para marcar tempo/lugar.
- Inserts gráficos simples (relógio grande, lua) como transição de tempo.

## Cenários e luz

- Low-poly saturado de brinquedo: corredor de casas coloridas com rua, interiores com escada, quartos
  lilás, terraço com céu estrelado e lua; poucos objetos, cores chapadas, sombras suaves.
- Dia claro azul-pastel; noite azul-marinho com estrelas e lua em crescente.

## Legendas e fala

- 1–3 palavras por vez, centralizadas no meio da tela, branco com contorno escuro, fonte arredondada,
  trocadas palavra a palavra em sincronia com a voz.
- Narração em 3ª pessoa intercalada com falas curtas dos personagens (inferido pelas legendas
  "ele subiu", "perguntou", "você é a minha favorita").

## Como esta skill traduz isso (checklist de direção)

1. Enquadramento médio 1,2–2,2 s; nenhum plano estático > 2 s (a câmera sempre deriva).
2. Toda fala de personagem: close/OTS de quem fala, boca sincronizada (lipsync.json).
3. Cada punchline/susto: troca de careta (com "pop" de cabeça) + `punch`/`crash` + efeito + às vezes `flash`.
4. ≥ 8 expressões distintas por vídeo de 60 s; pelo menos 1 choro, 1 risada, 1 choque.
5. Pelo menos 1 plano geral do cenário, 1 plongée/`high` e 1 `low` ou `pov_up` por história.
6. Planos de respiro (`hold` sem fala) para sustos e viradas.
7. Legendas de até 3 palavras, cor do falante, palavra atual em destaque.
8. Trilha contínua que abaixa sob a voz; clima muda com a cena (`mood`).
