# Pipeline da Fase 2 (comandos testados)

Rode a partir da raiz do projeto criado por `setup_project.py`. `python` = Python ≥ 3.10.

```bash
python <skill>/scripts/setup_project.py ./meu-video --story ./story.json --models <pasta modelos>   # template + scripts + personagens fixos + npm install
# o setup também copia a biblioteca da skill: skins -> public/skins, texturas -> public/textures, sons -> public/audio/sfx,
# cabelo .glb -> public/models/hair, paleta de vozes -> public/voices.json (os seus sons/texturas por cima, com --sounds/--textures)
# personagem com voz fish.audio? cole FISH_API_KEY=... no meu-video/.env e rode:
python scripts/fish_check.py              # chave, voz e saldo — custo zero
python scripts/fish_check.py --tts-test   # 1 frase no modelo grátis -> out/fish_teste.mp3
cd meu-video
python -m pip install edge-tts numpy scipy soundfile pillow                 # se o setup avisar

python scripts/story_check.py story.json        # valida (precisa dar OK)
python scripts/cast_voiceover.py story.json     # vozes Edge por personagem (+ fish.audio p/ quem tiver) -> public/audio/vo/*.mp3
python scripts/prepare_vo.py                    # normaliza, apara silêncio -> *.wav + src/data/vo.json
python scripts/lipsync.py                       # boca por frame -> src/data/lipsync.json
python scripts/sfx_story.py                     # 22 efeitos sintetizados -> public/audio/sfx
python scripts/build_timeline.py story.json     # cortes derivados da voz real -> src/data/timeline.json
python scripts/music_story.py                   # trilha por clima -> public/audio/music.wav (+ hasMusic)
npx tsc --noEmit

node scripts/stills.mjs 15 60 120 ...           # GL=swangle sem GPU; SCALE=0.5 padrão
python scripts/sheet.py out/sheet.png           # folha de contato -> OLHAR
npx remotion render src/index.ts RobloxStory out/video-raw.mp4 --gl=angle --crf=18
python scripts/loudnorm.py out/video-raw.mp4 out/video.mp4   # -14 LUFS / -1,5 dBTP
python scripts/audiocheck.py out/video.mp4
ffprobe -v error -show_entries stream=codec_name,width,height,r_frame_rate -show_entries format=duration out/video.mp4
```

Prévia sem voz: `python scripts/build_timeline.py story.json --estimate` + `npx remotion studio`.
Regerar uma fala: `cast_voiceover.py story.json --only s07` → `prepare_vo.py` → `lipsync.py` →
`build_timeline.py` → `music_story.py` (a trilha acompanha os novos cortes).

## Frames para conferir

Depois do `build_timeline`, pegue o meio de cada enquadramento:

```bash
python -c "import json;t=json.load(open('src/data/timeline.json'));print(' '.join(str(s['start']+(a+b)//2) for s in t['shots'] for a,b in zip([c['at'] for c in s['cuts']],[c['at'] for c in s['cuts']][1:]+[s['duration']])))"
```

## Desempenho medido

Máquina de teste sem GPU (2 vCPU, `--gl=swangle --concurrency=2`): ~1,3 frame/s →
um vídeo de 60 s (1800 frames) leva ~25 min. Com GPU (`--gl=angle`) costuma ser bem mais rápido.
Para iterar: stills e `--frames=0-299` antes do render completo.

## Problemas conhecidos

| Sintoma | Causa / correção |
| --- | --- |
| Tela preta / erro WebGL | use `--gl=angle` (GPU) ou `--gl=swangle` (CPU) |
| `CERTIFICATE_VERIFY_FAILED` no edge-tts | proxy corporativo: exporte `SSL_CERT_FILE=<ca.pem>` |
| "No audio was received" | instabilidade do serviço ou voz indisponível: o script repete 5×; troque a voz |
| Legenda com fonte serifada | `public/fonts/` ausente — a fonte é local (Lilita One, OFL) |
| Close mostra nuca/perfil | ângulo é limitado a ±35°; verifique `face` do ator e quem é `on` |
| Personagem atravessa móvel | mova `x/z` (posições úteis em story-format.md) |
| `timeline: soma ... != totalFrames` | rode de novo `build_timeline.py` (não edite timeline.json à mão) |
