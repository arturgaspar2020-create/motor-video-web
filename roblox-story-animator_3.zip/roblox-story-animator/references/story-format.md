# Formato do `story.json`

O `story.json` é o roteiro executável. `scripts/story_check.py` valida; `scripts/build_timeline.py` o
converte em `src/data/timeline.json` (frames) usando a duração REAL de cada fala. Exemplo completo:
`examples/demo-bolo/story.json`.

## Raiz

```json
{
  "title": "Título do vídeo",
  "theme": "tema dado pelo usuário",
  "language": "pt-BR",
  "fps": 30,
  "target_seconds": 60,
  "cast": { "<id>": CastMember, ... },
  "shots": [ Shot, ... ]
}
```

## CastMember

```json
"duda": {
  "name": "Duda", "voice": "pt_menina_1", "color": "#ff8ad8",
  "gender": "F", "age": "crianca", "skin": "14",
  "look": { "hair": "pigtails", "hairColor": "#5a2e1a", "accessoryColor": "#ff4f9a", "hat": "none", "glasses": false }
}
```

- **Roupa = skin (obrigatório)**: todo personagem que aparece usa `"skin": "<id>"` do catálogo
  `assets/skins/skins.json` (par camisa+calça: a camisa 05 só vai com a calça 05 — o motor junta sozinho, e a
  cor da cabeça/pele vem da skin). Roupa lisa de uma cor não é mais usada (`story_check` dá erro sem `skin`).
  Exceção: personagens com modelo próprio (`rig`, ex.: Gojo).
- `gender` ("F"/"M") e `age` ("adulto"/"crianca") são obrigatórios e conferidos com a skin: skin feminina só
  em mulher/menina, masculina só em homem/menino, "U" (masculina e feminina) em ambos; skin infantil só em
  criança (escala 0,8 automática). Uma skin por personagem.
- Catálogo (ids): **mulher adulta** 01–08, 12 (corpete com decote — `style: "decote"`; bloqueadas em histórias
  com crianças) e 32–35 (discretas: blusa+jeans / vestido, para mães, professoras, etc.); **menina** 09, 10, 11,
  13, 14, 15, 16, 25-infantil; **menino** 17–24; **homem adulto** 31 (padrão); **profissões (homem ou
  mulher)**: 25-policial e 26 (policial), 27 (ladrão), 28 e 29 (médico), 30 (vilão). Pele branca/negra está em
  `tone`; cor da roupa em `color`.
- `voice`: um id da paleta `assets/voices.json` (pt_homem_1..6, pt_mulher_1..6, pt_menina_1..6, pt_menino_1..6,
  en_man_1..6, en_woman_1..6, en_girl_1..6, en_boy_1..6) ou uma voz Edge com `rate`/`pitch` (ver voices.md).
- `narrator` não precisa de `look`/`skin` (não aparece). `color` = cor da legenda de quem fala.
- `hat`: none, cap, wide (aba larga), beanie, tophat, crown, party, flower (coroa de flores)
- `hair` (cabelos 3D esculpidos, nunca "capacete" de bloco): short (mechas na testa), side (topete de lado),
  buzz (raspado), spiky (espetado), curly (cacheado), afro, bob (chanel), long (liso comprido), ponytail
  (rabo de cavalo — modelo .glb do usuário, CC-BY zHairezt), bun (coque), pigtails (maria-chiquinha; a cor do
  elástico vem de `accessoryColor`). Sempre dê um cabelo (o check avisa se faltar). `hairColor` tinge.
- `accessory`: none, backpack, cape, bow · `scale`: criança 0.8, adulto 1, gigante 1.6
- `shirtTexture` / `pantsTexture`: roupa com estampa (PNG em `public/`, ex.: `textures/camisa-ninja.png`) feita
  nos moldes `assets/moldes/molde-camisa.png` (1024×1024: tronco + braços) e `molde-calca.png` (1024×512: pernas).
  Com calça estampada o sapato preto some (desenhe o tênis no molde) — salvo se `shoes` for informado.
- `accessories`: acessórios **.glb importados** presos ao corpo (ver "Modelos .glb" abaixo). Ao usar
  cabelo importado, ponha `"hair": "none"`.
- Pele clássica amarela `#f6d03b`; variar tons é permitido. Cores saturadas, contraste entre personagens.

## Shot (um plano = no máximo uma fala)

```json
{
  "id": "s05",                       // único; vira o nome do áudio (public/audio/vo/s05.wav)
  "set": "street", "time": "night", "mood": "tension",
  "line": { "by": "duda", "text": "Téo! O que você tá fazendo?!" },   // ou omitido para plano sem fala
  "hold": 1.2,                       // s extras (sem fala: duração total do plano; padrão 1,0)
  "lead": 0.12, "tail": 0.18,        // respiros antes/depois da fala (padrões)
  "actors": [ Actor, ... ],
  "camera": Camera,                   // enquadramento inicial
  "cuts": [ { "at": "w3", "camera": Camera }, ... ],   // cortes internos
  "sfx": [ { "name": "boing", "at": "w6", "volume": 0.5 } ],
  "flash": [0, "w4"],                // flash branco de impacto
  "title": { "text": "3 DIAS DEPOIS...", "at": 0, "until": "end" },
  "props": [ { "src": "models/bolo.glb", "x": 2, "z": -1, "height": 1.2, "rot": 0, "license": "own" } ]
}
```

### Marcas de tempo (`at`, `move`, `until`)

| Forma | Significado |
| --- | --- |
| `1.5` | segundos desde o início do plano |
| `"w3"` / `"w3e"` | início / fim da 4ª palavra da fala (índice começa em 0) |
| `"line"` / `"lineEnd"` | início / fim da fala |
| `"start"` / `"end"` | primeiro / último frame do plano |
| `"w3+0.2"`, `"end-0.5"` | deslocamento em segundos |

Palavras = texto separado por espaços (pontuação fica grudada). Amarre caretas, cortes e efeitos às
palavras: o tempo continua certo quando a voz real for gerada.

### Actor

```json
{ "id": "teo", "x": 1, "z": 1, "y": 0, "face": -60, "pose": "idle", "expr": "shock", "gaze": "front",
  "to": [4, 1], "move": ["w2", "lineEnd"],
  "keys": [ { "at": "w2", "pose": "facepalm", "expr": "sad", "face": 0, "gaze": "down" } ] }
```

- Coordenadas em unidades do mundo (boneco ≈ 5,25 u de altura, 2 u de largura). Origem = centro do
  cenário; câmera "padrão" em +z olhando para −z. `face` em graus: 0 = de frente para +z, 90 = para +x,
  −90 = para −x, 180 = de costas. Dois personagens conversando: ~4 u de distância, `face` apontando um
  para o outro (ex.: A em x=−2 com face 60, B em x=2 com face −60).
- `to` + `move`: anda em linha reta (pose vira `walk` sozinha se for idle/talk; use `run`/`sneak` para
  outros jeitos de andar) e o corpo vira na direção do movimento.
- Quem fala e está em `idle` gesticula sozinho (`talk`) e mexe a boca pelo envelope da voz.
- `keys` trocam pose/expressão/direção/olhar num instante (transição de 6 frames; careta nova "salta").

**Poses:** idle, talk, walk, run, point, wave, cheer, shrug, facepalm, cry, scared, think, sit (assento
~1 u), lie, fall (tomba e fica deitado), jump (pulos), lookup, angry, dance, sneak, climb, laugh, dizzy,
hands_hips, reach (alcançar o alto), bow, **punch** (soco de direita: prepara 0–5, impacto no frame ~7, fica
em guarda), **kick** (chute, impacto ~8), **power** (carregando energia, mãos à frente), **land** (aterrissagem
de herói), **carry** (carregando algo). `jump` agora tem antecipação (agacha), voo com braços para cima e
amortecimento na queda (ciclo de 34 frames).

**Expressões:** neutral, happy, laugh, smug, shock, scared, angry, sad, cry (cascata de lágrimas), sleepy,
confused, determined, love (olhos de coração), evil (sorriso maligno), dizzy (espirais), wink, disgust,
starstruck (olhos de estrela).

**Olhar (`gaze`):** camera, front, up, down, left, right.

### Camera

```json
{ "type": "close", "on": "teo", "from": "duda", "angle": -20, "move": "push", "dutch": 6, "shake": 0.5 }
```

| `type` | Uso |
| --- | --- |
| `extreme_close` | cabeça enche a tela — caretas, punchlines |
| `close` | cabeça + ombros — falas |
| `medium` | cintura para cima — gestos |
| `full` | corpo inteiro — ações, andar |
| `wide` / `establishing` | cenário, localização, respiro |
| `low` | contra-plongée (de baixo, imponente/ameaçador) |
| `high` / `top` | plongée (pequeno, derrotado) / vista de cima |
| `ots` | por cima do ombro de `from` olhando `on` — diálogos |
| `two` | dois personagens (`on` + `from`) no quadro |
| `pov_up` | olhar de `on` para o céu |

`angle` gira em torno do ator (0 = de frente; em close/extreme_close/low é limitado a ±35° para mostrar
o rosto). `move`: hold (deriva leve), push, pull, orbit, pan, dolly, tilt_up, shake (tremor forte),
punch (zoom-soco de entrada), crash (zoom rápido de longe). `dutch`: inclinação em graus.

### Cenários (`set`) e horários (`time`)

street (rua de asfalto texturizado, calçadas de bloquete, casas coloridas e de tijolo, postes),
hospital (piso granilite, recepção, 2 leitos com cortina, cadeiras de espera, cruz vermelha), bedroom (quarto: cama, janela, prateleira, escrivaninha),
rooftop (terraço com casinha de escada, caixa d'água e cidade abaixo), park (árvores, banco, flores),
classroom (lousa, carteiras), livingroom (sala com escada, sofá, TV), void (fundo neutro).
`time`: day, sunset (sol grande no horizonte), night (estrelas + lua nos externos; janelas/postes acesos).
Céu nos externos: nuvens de blocos andando devagar (dia/pôr do sol; `"clouds": false` desliga).
Clima por plano: `"weather": "rain"` (gotas 3D, céu cinza, neblina leve) ou `"fog"`; `"fog": 0.0–1.0` controla
a neblina em qualquer plano (ex.: 0.7 = mistério).

**Texturas (assets/textures → public/textures):** os pisos já usam: asfalto (clean_asphalt), calçada
(brick_pavement_03), grama (grass_ground), madeira (oak_wood_planks, piso_de_madeira_cartoon_em_tons_quentes),
escola (old_linoleum_flooring_01), terraço (herringbone_concrete_tile_03), hospital (terrazzo_tiles),
caminho do parque (dry_river_pebbles). Também disponíveis: asphalt_pit_lane, decrepit_wallpaper,
interior_tiles, lacquered_cherry_wood, red_brick (fachadas), rock_wall_17, rocky_terrain_02,
walnut_veneer_02, worn_tile_floor — para usar em cenários novos (`TexBox`/`TexGround` em world/Textured.tsx).

### Partículas e efeitos (`fx`)

```json
"fx": [ { "type": "impact", "on": "gojo", "at": "w3" },
        { "type": "energy_purple", "on": "gojo", "at": 0, "until": "end" },
        { "type": "confetti", "at": "w2", "until": "end", "pos": [0, 0, 1] } ]
```

| type | O que é | Posição padrão com `on` |
| --- | --- | --- |
| dust | nuvem de poeira no chão (pulo, queda, freada) | pés |
| smoke | fumaça escura subindo | pés |
| sparkle | brilhos/estrelinhas piscando | cabeça |
| confetti | confete colorido caindo | em volta do ator / `pos` |
| energy_purple / energy_blue | esfera de energia com anéis, partículas sugadas e luz colorida | à frente das mãos |
| impact | estouro de soco: anel, raios, estilhaços, luz + linhas de velocidade na tela | à frente do punho |
| speedlines | linhas de velocidade estilo anime (2D) | tela toda |
| hearts / stars | corações subindo / estrelinhas girando (tontura) | cabeça |

`at`/`until` aceitam as mesmas marcas de tempo; sem `until` cada efeito tem duração padrão (impact 14 frames).
`pos` desloca (com `on`) ou posiciona (sem `on`). `color`, `size`, `count` são opcionais.
**Soco com impacto:** pose `punch` no atacante + `fx impact` no atacante ~0,23 s depois de começar o soco +
`sfx soco` + `flash` no mesmo instante + câmera `punch`/`shake` + a vítima com `fall` logo depois.
Posições úteis: sofá em (3, −6.5); cama em (−6.2, −4.3); banco do parque em (3.5, −4); porta do
terraço em (−5.5, −5.4); escada da sala sobe ao longo de x≈−8.3 de z=5 até z=−8.

### Mood (trilha)

calm, funny (oompah cômico), tension (pulso grave), sad (piano lento), epic, mystery.

### Efeitos (`sfx.name`)

whoosh, whoosh_fast, pop, boing, thud, fall (assobio + baque), ding, sting (dun-dun-DUN), hit, sparkle,
sad_trombone, footsteps, door, slap, scratch (disco arranhado), heartbeat, crickets (silêncio constrangedor),
bell (sinal da escola), tada, suspense, gulp, zoom. `volume` 0–1 (padrão 0,6; voz é prioridade).
Também valem todos os sons da biblioteca da skill (`assets/sons`, ver `references/sons.md`): soco, tapa,
queda_corpo, aterrissagem, pulo, mola, porta_abrir, porta_bater, vidro_quebrar, explosao, trovao, sino, gongo...

## Modelos .glb (props no cenário e acessórios nos personagens)

Arquivos em `public/models/` (a biblioteca do usuário vai para `public/models/lib/` com
`setup_project.py --models <pasta>`). `license` é obrigatória: `own`, `CC0`, `CC-BY:<autor>` ou
`permission:<quem>` (os .glb do Sketchfab trazem autor/licença nos metadados `asset.extras`).

Campos comuns:

| Campo | Efeito |
| --- | --- |
| `height` / `width` | tamanho final em u (boneco 5,25 de altura; cabeça 1,24 de largura; braço 1). Sem eles, escala original do arquivo |
| `parts` / `hideParts` | mostra só / esconde malhas cujo nome (ou de ancestral) contém o trecho — ex.: `"parts": ["hair"]`, `"hideParts": ["Plane"]` |
| `tint` | multiplica a cor (cabelos em tons de cinza feitos para receber cor) |

**Prop no cenário** (no plano): `{ "src", "x", "z", "y"?, "rot"? (graus), "scale"?, "height"? }` —
apoiado no chão, centrado em x/z.

**Acessório** (em `cast.<id>.look.accessories`):
`{ "src", "attach": "head|back|torso|handR|handL", "anchor": "center|top|base", "offset": [x,y,z], "rot": [graus x,y,z], "width"|"height", "license" }`.
Acompanha poses, cabeça e o "pulo" das caretas. Pontos: `head` = centro da cabeça (topo em y=+0,6),
`back` = costas, `torso` = peito, `handR/handL` = ponta da mão.

Receitas testadas (31/10/2026, conferidas de frente, lado e costas):

```json
{ "src": "models/lib/voluminous_long_ponytail_with_bones.glb", "attach": "head", "width": 1.8, "anchor": "top",
  "offset": [0, 0.86, -0.5], "tint": "#5a2e1a", "license": "CC-BY:zHairezt" }
{ "src": "models/lib/gojo_roblox_gfx.glb", "attach": "head", "parts": ["hair"], "width": 1.5,
  "offset": [0, 0.5, -0.05], "license": "CC-BY:certifiedastro" }
{ "src": "models/lib/roblox_omnitrix.glb", "attach": "handL", "width": 1.8, "offset": [0, 0.15, 0],
  "rot": [0, 180, 0], "license": "CC-BY:TacticalNerd1963" }
{ "src": "models/lib/cheezburger_roblox.glb", "attach": "handR", "height": 0.7, "offset": [0, -0.3, 0.2], "license": "CC-BY:SamelCookies" }
```

Não use a malha `face` do gojo_roblox_gfx: é uma cabeça inteira com rosto pintado e esconde as caretas.

Regra de ouro: cabelo comprido → `width` ≈ 1,8 + `anchor: "top"` + `offset` y ≈ 0,85 e z ≈ −0,5 (a cauda
desloca o centro); cabelo curto/espetado → `width` ≈ 1,5, `offset` y ≈ 0,5; relógio/manopla →
`width` ≈ 1,8 em `handL/handR` (menor afunda no braço quadrado), gire `rot` y 180 se o mostrador ficar atrás; objeto na mão → `height` 0,5–1 com `offset` z ≈ 0,2. Sempre confira em
stills de frente e de costas antes do render. Modelos com ossos (skins) funcionam parados (pose de
repouso), não animam. Modelos de personagem inteiros entram só como estátuas (`props`).

## Personagens fixos (`characters/*.json`)

Personagens recorrentes com nome, visual, personalidade e voz própria. No story:
`"cast": { "gojo": { "preset": "gojo" } }`. O preset fornece nome, voz e visual; o story só pode mudar
`look` e `color`. Com `reserved_voice: true`, o `story_check` barra qualquer outro personagem com a mesma
voz e qualquer personagem novo com o mesmo nome. Leia o campo `personality` antes de escrever as falas.

Voz pelo fish.audio no cast/preset: `"provider": "fish", "fish_voice": "<reference_id>", "fish_model": "s2.1-pro-free"`
(+ `voice/rate/pitch` do edge só para prévia com `--fallback-edge`).

### Personagem com modelo próprio (`rig`)

Um membro do cast com `rig` é desenhado pelo `.glb` dele, animado (`RiggedCharacter.tsx`), no lugar do boneco
de blocos. Exige esqueleto padrão Roblox (Lower/Upper Torso, Head, Left/Right Upper/Lower Arm e Leg) — o
motor endireita a pose de "GFX" medindo a malha, gira cada membro em torno do ombro/quadril e aceita TODAS
as poses e expressões. Campos: `src`, `height` (altura do corpo sem cabelo), `facing` (graus para olhar +z),
`hideUV` (esconde triângulos por área da textura, ex.: a venda do Gojo), `face` (região do rosto no atlas
redesenhada a cada frame: `region`, `skin`, `eyes` recorte dos olhos, `flipY`, `eyeY`, `mouthY`).
Gojo com a venda numa cena: `"gojo": {"preset": "gojo", "rig": {"hideUV": []}}` (sem a venda → olhos e
sobrancelhas aparecem; com a venda só a boca fica visível).

## Sons da biblioteca do usuário

`setup_project.py --sounds <pasta>` copia os sons (subpastas ok) para `public/audio/sfx/` com nomes em
minúsculas. Num plano:
- `"sfx": [{"name": "soco", "at": "w3"}]` — usa `soco.wav|mp3|ogg` ou sorteia uma variação `soco_01`, `soco_02`…
  (sorteio fixo por plano: o vídeo sai igual se renderizar de novo).
- `"ambience": "ambiente_noite"` (ou `{"name": ..., "volume": 0.22}`) — loop durante o plano, com fade.
- Passos automáticos: atores com `to` (andando/correndo/sneak) ganham `passo_<piso>` a cada pisada; piso
  padrão por cenário: street=asfalto, park=grama, bedroom/livingroom=madeira, classroom=piso,
  rooftop/void=concreto. Troque com `"floor": "terra"`; desligue com `"footsteps": false`. Sem os
  arquivos `passo_<piso>_NN`, os passos são simplesmente omitidos.
Lista de nomes sugeridos: `references/sons.md`.
