# Biblioteca de sons — o que mandar e como nomear

Formato: **WAV ou MP3** (OGG/M4A também), 44,1 ou 48 kHz. Efeitos curtos começam **sem silêncio no início**.
Ambientes: loops de **20 a 60 s**, de preferência sem emenda audível. Variações: mesmo nome com `_01`, `_02`,
`_03`… (3 a 5 variações nos sons que repetem muito: passos, socos, risadas). Nome em minúsculas, sem acento,
espaço vira `_`. Pode organizar em subpastas — o setup achata tudo.

## Já incluídos na skill (assets/sons, 95 arquivos, CC0 + passos CC-BY — ver assets/sons/CREDITOS-SONS.md)
passo_asfalto/grama/madeira/piso/concreto/terra/metal/agua (_01..05), soco_01..05, tapa_01, queda_corpo_01..03,
aterrissagem_01..03, pulo_01..03, mola_01..02, metal_batida, madeira_batida, vidro_quebrar, porta_abrir,
porta_bater_01..03, explosao_01, trovao_01, sino, gongo, tiro_brinquedo, interruptor, chave_abrir, respingo,
ploft, louca, papel, ferramenta, estranho, ambiente_dia_rua, ambiente_obra, ambiente_agua.
Os passos são usados sozinhos (piso de cada cenário). Seus arquivos com o mesmo nome substituem estes.
O agente não ouviu os sons: os nomes vêm das categorias dos pacotes, não de audição.

## Passos (usados automaticamente quando alguém anda/corre)
passo_asfalto_01..05 · passo_grama_01..05 · passo_madeira_01..05 · passo_piso_01..05 (cerâmica/escola)
passo_concreto_01..05 · passo_terra_01..05 (opcional) · passo_agua_01..03 (opcional)

## Ambientes (loop por cena)
ambiente_noite (vento leve + grilos) · ambiente_dia_rua (carros ao longe, pássaros) · ambiente_sala_aula (burburinho)
ambiente_casa (relógio, geladeira) · ambiente_parque (pássaros, folhas) · ambiente_chuva · ambiente_vento (terraço)
ambiente_multidao · ambiente_tensao (drone grave) · ambiente_misterio

## Impacto e ação
soco_01..05 · tapa_01..03 · queda_corpo_01..03 · pulo_01..03 · aterrissagem_01..03 · whoosh_rapido_01..05
porta_abrir · porta_bater · vidro_quebrar · explosao_01..03 · teleporte_01..03 · corrida_vento

## Poderes (Gojo e afins)
poder_carregando · poder_disparo_roxo · poder_disparo_azul · poder_explosao · barreira_infinito · energia_zumbido

## Comédia e reação
risada_plateia_01..03 · aww_plateia · uau_plateia · grilos_silencio · ba_dum_tss · buzina_comica · plim_01..03
camera_flash · notificacao_celular · estomago_roncando · peido_comico (se o tom permitir)

## Já existem (sintetizados, não precisa mandar)
whoosh, whoosh_fast, pop, boing, thud, fall, ding, sting, hit, sparkle, sad_trombone, footsteps, door, slap, scratch,
heartbeat, crickets, bell, tada, suspense, gulp, zoom. Se você mandar um arquivo com o mesmo nome, o seu tem prioridade.

## Licença
Anote de onde veio cada som (site + autor + licença) num `CREDITOS-SONS.md` na pasta. Prefira CC0 ou licenças
que permitem uso comercial sem crédito; CC-BY exige crédito na descrição; evite "NC" (não comercial) em canal monetizado.
